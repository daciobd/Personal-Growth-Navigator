# Painel Admin — Guia de Instalação

## Arquivos desta atualização

```
server/
  middleware/adminAuth.js     ← Novo middleware de autenticação admin
  routes/admin.js             ← Novas rotas do painel
  add-admin-column.js         ← Script de migração do banco
  index.js                    ← SUBSTITUI o existente (adiciona rota /api/admin)

client/src/
  adminApi.js                 ← Novo arquivo de API do admin
  App.jsx                     ← SUBSTITUI o existente (adiciona rota /admin)
  pages/
    AdminPage.jsx             ← Novo componente do painel
    Admin.module.css          ← Estilos do painel (tema escuro)
```

---

## Passo a Passo

### 1. Copiar os arquivos

No Replit, adicione / substitua os arquivos listados acima.

### 2. Migrar o banco de dados

No Shell do Replit, rode:
```bash
node server/add-admin-column.js
```

Isso adiciona a coluna `is_admin` à tabela `users`.

### 3. Tornar seu usuário admin

```bash
node server/add-admin-column.js seu@email.com
```

Substitua pelo email com que você se cadastrou no app.

### 4. Reiniciar o servidor

```bash
npm run dev
```

### 5. Acessar o painel

Acesse `/admin` na URL do seu Replit.
O painel tem 4 seções:

---

## Seções do Painel

### Dashboard
- Total de usuários, planos gerados, check-ins, intervenções cadastradas
- Tabela dos últimos 10 planos com adjetivos selecionados

### Biblioteca
- Visualiza todas as 9 abordagens com contagem de intervenções
- Filtra por categoria dentro de cada abordagem
- **Adicionar** nova intervenção (campo + Enter ou botão)
- **Editar** intervenção existente inline
- **Remover** intervenção
- **Criar** nova categoria dentro de uma abordagem
- **Criar** nova abordagem completa

### Simulador
- Sliders para configurar qualquer perfil Big Five (0-100% por dimensão)
- Clique "Simular seleção" para ver:
  - Quais abordagens seriam ativadas
  - Por que (lógica aplicada linha a linha)
  - Quais intervenções seriam incluídas no prompt
- Ideal para testar e calibrar o mapeamento antes de ajustá-lo

### Usuários
- Lista todos os usuários cadastrados
- Promover ou rebaixar usuário admin com um clique
- Você não pode alterar seu próprio status (segurança)

---

## Segurança

- Todas as rotas `/api/admin/*` exigem token JWT + `is_admin = true` no banco
- A verificação frontend é apenas visual — a segurança real está no middleware `adminAuth.js`
- Nunca exponha a URL do admin publicamente — use uma URL path longa ou adicione senha extra se necessário

---

## Expandindo o mapeamento Big Five

Para ajustar quais abordagens são ativadas por quais perfis,
edite `server/data/big5-to-therapy.json` direto no Replit.

Estrutura de uma regra:
```json
{
  "dimension": "N",
  "label": "Neuroticismo",
  "thresholds": {
    "high": {
      "min": 60,
      "approaches": ["CFT", "DBT", "ACT"],
      "rationale": "Descrição da lógica clínica"
    }
  }
}
```

Use o **Simulador** no painel para testar suas mudanças em tempo real.
