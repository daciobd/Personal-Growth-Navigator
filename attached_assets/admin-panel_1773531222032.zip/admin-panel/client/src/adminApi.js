// client/src/adminApi.js
// Funções de API para o painel admin

function getToken() {
  return localStorage.getItem('jornada_token');
}

async function adminRequest(path, options = {}) {
  const token = getToken();
  const res = await fetch(`/api/admin${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Erro inesperado');
  return data;
}

export const adminApi = {
  // Stats
  getStats: () => adminRequest('/stats'),

  // Biblioteca
  getBiblioteca:   ()           => adminRequest('/biblioteca'),
  saveBiblioteca:  (data)       => adminRequest('/biblioteca', { method: 'PUT', body: JSON.stringify({ data }) }),
  addIntervencao:  (ap, cat, texto) =>
    adminRequest(`/biblioteca/${ap}/categoria/${encodeURIComponent(cat)}/intervencao`, {
      method: 'POST', body: JSON.stringify({ texto }),
    }),
  deleteIntervencao: (ap, cat, idx) =>
    adminRequest(`/biblioteca/${ap}/categoria/${encodeURIComponent(cat)}/intervencao/${idx}`, { method: 'DELETE' }),
  addCategoria:    (ap, nome)   =>
    adminRequest(`/biblioteca/${ap}/categoria`, { method: 'POST', body: JSON.stringify({ nome }) }),
  addAbordagem:    (key, nome)  =>
    adminRequest('/biblioteca/abordagem', { method: 'POST', body: JSON.stringify({ key, nome }) }),

  // Mapeamento
  getMapping:  ()      => adminRequest('/mapping'),
  saveMapping: (data)  => adminRequest('/mapping', { method: 'PUT', body: JSON.stringify({ data }) }),

  // Simulador
  simulate: (pct, facetPct) =>
    adminRequest('/simulate', { method: 'POST', body: JSON.stringify({ pct, facetPct }) }),

  // Usuários
  getUsers:   ()               => adminRequest('/users'),
  setAdmin:   (id, is_admin)   =>
    adminRequest(`/users/${id}/admin`, { method: 'PUT', body: JSON.stringify({ is_admin }) }),
};
