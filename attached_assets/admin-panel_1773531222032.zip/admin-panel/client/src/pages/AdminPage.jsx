import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { adminApi } from '../adminApi';
import styles from './Admin.module.css';

// ── Sub-components ──────────────────────────────────────────

function StatCard({ label, value, accent }) {
  return (
    <div className={styles.statCard}>
      <span className={styles.statLabel}>{label}</span>
      <span className={styles.statValue} style={accent ? { color: accent } : {}}>{value}</span>
    </div>
  );
}

function Toast({ msg, type, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 3000); return () => clearTimeout(t); }, [onClose]);
  return (
    <div className={styles.toast + ' ' + (type === 'error' ? styles.toastError : styles.toastOk)}>
      {msg}
    </div>
  );
}

// ── Tab: Dashboard ──────────────────────────────────────────
function TabDashboard({ notify }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminApi.getStats()
      .then(setStats)
      .catch(() => notify('Erro ao carregar estatísticas', 'error'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className={styles.loading}><span className={styles.spinner} /></div>;
  if (!stats) return null;

  return (
    <div>
      <div className={styles.statsGrid}>
        <StatCard label="Usuários cadastrados" value={stats.users} accent="#7BAA6A" />
        <StatCard label="Planos gerados" value={stats.plans} accent="#C4622D" />
        <StatCard label="Check-ins realizados" value={stats.checkins} />
        <StatCard label="Abordagens na biblioteca" value={stats.approaches} />
        <StatCard label="Micro-intervenções" value={stats.interventions} accent="#3A5A8C" />
      </div>

      <h3 className={styles.sectionTitle}>Últimos 10 planos gerados</h3>
      <div className={styles.table}>
        <div className={styles.tableHead}>
          <span>Usuário</span><span>Data</span><span>Eu hoje</span><span>Eu futuro</span>
        </div>
        {stats.recentPlans.map(p => (
          <div key={p.id} className={styles.tableRow}>
            <span><strong>{p.name}</strong><br /><small>{p.email}</small></span>
            <span>{new Date(p.created_at).toLocaleDateString('pt-BR')}</span>
            <span className={styles.chipList}>
              {(p.adjetivos_atual || []).slice(0, 3).map(a => (
                <span key={a} className={styles.chipA}>{a}</span>
              ))}
            </span>
            <span className={styles.chipList}>
              {(p.adjetivos_futuro || []).slice(0, 3).map(a => (
                <span key={a} className={styles.chipF}>{a}</span>
              ))}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Tab: Biblioteca ─────────────────────────────────────────
function TabBiblioteca({ notify }) {
  const [biblioteca, setBiblioteca] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeAp, setActiveAp] = useState(null);
  const [activeCat, setActiveCat] = useState(null);
  const [newTexto, setNewTexto] = useState('');
  const [newCatNome, setNewCatNome] = useState('');
  const [newApKey, setNewApKey] = useState('');
  const [newApNome, setNewApNome] = useState('');
  const [saving, setSaving] = useState(false);
  const [editingIdx, setEditingIdx] = useState(null);
  const [editText, setEditText] = useState('');

  const load = useCallback(() => {
    setLoading(true);
    adminApi.getBiblioteca()
      .then(d => { setBiblioteca(d); if (!activeAp) setActiveAp(Object.keys(d).filter(k => !k.startsWith('_'))[0]); })
      .catch(() => notify('Erro ao carregar biblioteca', 'error'))
      .finally(() => setLoading(false));
  }, [activeAp]);

  useEffect(() => { load(); }, []);

  const approaches = biblioteca ? Object.keys(biblioteca).filter(k => !k.startsWith('_')) : [];
  const currentAp = biblioteca?.[activeAp];
  const cats = currentAp ? Object.keys(currentAp.categorias || {}) : [];

  async function addIntervencao() {
    if (!newTexto.trim()) return;
    setSaving(true);
    try {
      await adminApi.addIntervencao(activeAp, activeCat || cats[0], newTexto.trim());
      setNewTexto('');
      notify('Intervenção adicionada!');
      load();
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  async function deleteIntervencao(cat, idx) {
    if (!confirm('Remover esta intervenção?')) return;
    try {
      await adminApi.deleteIntervencao(activeAp, cat, idx);
      notify('Intervenção removida');
      load();
    } catch (e) { notify(e.message, 'error'); }
  }

  async function saveEdit(cat, idx) {
    const data = JSON.parse(JSON.stringify(biblioteca));
    data[activeAp].categorias[cat][idx] = editText;
    setSaving(true);
    try {
      await adminApi.saveBiblioteca(data);
      setBiblioteca(data);
      setEditingIdx(null);
      notify('Intervenção atualizada!');
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  async function addCategoria() {
    if (!newCatNome.trim()) return;
    setSaving(true);
    try {
      await adminApi.addCategoria(activeAp, newCatNome.trim());
      setNewCatNome('');
      notify('Categoria criada!');
      load();
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  async function addAbordagem() {
    if (!newApKey.trim() || !newApNome.trim()) return;
    setSaving(true);
    try {
      await adminApi.addAbordagem(newApKey.trim().toUpperCase(), newApNome.trim());
      setNewApKey(''); setNewApNome('');
      notify('Abordagem criada!');
      load();
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  const totalCurrent = cats.reduce((s, c) => s + (currentAp?.categorias[c]?.length || 0), 0);

  if (loading) return <div className={styles.loading}><span className={styles.spinner} /></div>;

  return (
    <div className={styles.bibWrap}>
      {/* Sidebar abordagens */}
      <div className={styles.bibSidebar}>
        <p className={styles.sidebarTitle}>Abordagens</p>
        {approaches.map(ap => (
          <button key={ap}
            className={styles.apBtn + (activeAp === ap ? ' ' + styles.apBtnActive : '')}
            onClick={() => { setActiveAp(ap); setActiveCat(null); }}>
            <span className={styles.apKey}>{ap}</span>
            <span className={styles.apCount}>
              {Object.values(biblioteca[ap]?.categorias || {}).reduce((s, c) => s + c.length, 0)}
            </span>
          </button>
        ))}
        <div className={styles.addApForm}>
          <input className={styles.inp} placeholder="Chave (ex: CFT2)"
            value={newApKey} onChange={e => setNewApKey(e.target.value)} />
          <input className={styles.inp} placeholder="Nome completo"
            value={newApNome} onChange={e => setNewApNome(e.target.value)} />
          <button className={styles.btnSm} onClick={addAbordagem} disabled={saving}>+ Abordagem</button>
        </div>
      </div>

      {/* Main */}
      {currentAp && (
        <div className={styles.bibMain}>
          <div className={styles.bibHeader}>
            <div>
              <h3 className={styles.apTitle}>{currentAp.nome}</h3>
              <span className={styles.apMeta}>{totalCurrent} intervenções · {cats.length} categorias</span>
            </div>
          </div>

          {/* Tabs categorias */}
          <div className={styles.catTabs}>
            {cats.map(cat => (
              <button key={cat}
                className={styles.catTab + (activeCat === cat ? ' ' + styles.catTabActive : '')}
                onClick={() => setActiveCat(cat)}>
                {cat}
                <span className={styles.catCount}>{currentAp.categorias[cat].length}</span>
              </button>
            ))}
            <div className={styles.addCatInline}>
              <input className={styles.inpSm} placeholder="Nova categoria…"
                value={newCatNome} onChange={e => setNewCatNome(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addCategoria()} />
              <button className={styles.btnXs} onClick={addCategoria} disabled={saving}>+</button>
            </div>
          </div>

          {/* Lista intervenções */}
          {(activeCat ? [activeCat] : cats).map(cat => (
            <div key={cat} className={styles.catSection}>
              {!activeCat && <p className={styles.catLabel}>{cat}</p>}
              {(currentAp.categorias[cat] || []).map((txt, idx) => {
                const eKey = `${cat}-${idx}`;
                return (
                  <div key={idx} className={styles.invRow}>
                    {editingIdx === eKey ? (
                      <div className={styles.editRow}>
                        <textarea className={styles.editArea} value={editText}
                          onChange={e => setEditText(e.target.value)} rows={2} />
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button className={styles.btnSm} onClick={() => saveEdit(cat, idx)} disabled={saving}>Salvar</button>
                          <button className={styles.btnSmGhost} onClick={() => setEditingIdx(null)}>Cancelar</button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <span className={styles.invText}>{txt}</span>
                        <div className={styles.invActions}>
                          <button className={styles.iconBtn} title="Editar"
                            onClick={() => { setEditingIdx(eKey); setEditText(txt); }}>✏</button>
                          <button className={styles.iconBtnDanger} title="Remover"
                            onClick={() => deleteIntervencao(cat, idx)}>×</button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
              <div className={styles.addInvRow}>
                <input className={styles.inp}
                  placeholder={`Nova intervenção em ${activeCat || cat}…`}
                  value={activeCat === cat || !activeCat ? newTexto : ''}
                  onChange={e => setNewTexto(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addIntervencao()}
                />
                <button className={styles.btnSm} onClick={addIntervencao} disabled={saving}>+ Adicionar</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Tab: Simulador ──────────────────────────────────────────
function TabSimulador({ notify }) {
  const [pct, setPct] = useState({ N: 65, E: 40, O: 70, A: 55, C: 45 });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const DIM = { N: 'Neuroticismo', E: 'Extroversão', O: 'Abertura', A: 'Amabilidade', C: 'Conscienciosidade' };
  const DIM_COLORS = { N: '#C4622D', E: '#2D5016', O: '#3A5A8C', A: '#854F0B', C: '#1D9E75' };

  async function simulate() {
    setLoading(true);
    try {
      const r = await adminApi.simulate(pct, {});
      setResult(r);
    } catch (e) { notify(e.message, 'error'); } finally { setLoading(false); }
  }

  return (
    <div className={styles.simWrap}>
      <div className={styles.simControls}>
        <h3 className={styles.sectionTitle}>Configure um perfil Big Five</h3>
        {Object.entries(DIM).map(([key, label]) => (
          <div key={key} className={styles.sliderRow}>
            <div className={styles.sliderLabelRow}>
              <span className={styles.sliderLabel} style={{ color: DIM_COLORS[key] }}>{label}</span>
              <span className={styles.sliderVal}>{pct[key]}%</span>
            </div>
            <input type="range" min="0" max="100" step="1"
              value={pct[key]}
              onChange={e => setPct(p => ({ ...p, [key]: parseInt(e.target.value) }))}
              style={{ accentColor: DIM_COLORS[key] }}
            />
            <div className={styles.sliderMarks}>
              <span>Baixo</span><span>Moderado</span><span>Alto</span>
            </div>
          </div>
        ))}
        <button className={styles.btnPrimary} onClick={simulate} disabled={loading}>
          {loading ? 'Simulando…' : 'Simular seleção →'}
        </button>
      </div>

      {result && (
        <div className={styles.simResult}>
          <h3 className={styles.sectionTitle}>Abordagens selecionadas</h3>
          <div className={styles.apResultRow}>
            {result.approaches.map(ap => (
              <div key={ap} className={styles.apResultCard}>
                <span className={styles.apResultKey}>{ap}</span>
              </div>
            ))}
          </div>

          <h3 className={styles.sectionTitle} style={{ marginTop: 24 }}>Lógica aplicada</h3>
          <div className={styles.rationaleBox}>
            {result.rationale.split('\n').filter(Boolean).map((line, i) => (
              <p key={i} className={styles.rationaleLine}>▸ {line}</p>
            ))}
          </div>

          <h3 className={styles.sectionTitle} style={{ marginTop: 24 }}>Intervenções selecionadas</h3>
          {Object.entries(result.interventions).map(([ap, items]) => (
            <div key={ap} className={styles.invResultSection}>
              <p className={styles.invResultAp}>{ap}</p>
              {items.map((item, i) => <p key={i} className={styles.invResultItem}>• {item}</p>)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Tab: Usuários ───────────────────────────────────────────
function TabUsuarios({ notify, currentUser }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    adminApi.getUsers()
      .then(setUsers)
      .catch(() => notify('Erro ao carregar usuários', 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  async function toggleAdmin(user) {
    try {
      await adminApi.setAdmin(user.id, !user.is_admin);
      notify(user.is_admin ? 'Admin removido' : 'Usuário promovido a admin');
      load();
    } catch (e) { notify(e.message, 'error'); }
  }

  if (loading) return <div className={styles.loading}><span className={styles.spinner} /></div>;

  return (
    <div>
      <div className={styles.table}>
        <div className={styles.tableHead}>
          <span>Nome</span><span>Email</span><span>Cadastro</span><span>Admin</span>
        </div>
        {users.map(u => (
          <div key={u.id} className={styles.tableRow}>
            <span><strong>{u.name}</strong></span>
            <span style={{ color: '#AAA', fontSize: 13 }}>{u.email}</span>
            <span style={{ fontSize: 12, color: '#BBB' }}>
              {new Date(u.created_at).toLocaleDateString('pt-BR')}
            </span>
            <span>
              {u.id === currentUser?.id ? (
                <span className={styles.youBadge}>você</span>
              ) : (
                <button
                  className={u.is_admin ? styles.adminBadgeOn : styles.adminBadgeOff}
                  onClick={() => toggleAdmin(u)}>
                  {u.is_admin ? 'Admin ✓' : 'Comum'}
                </button>
              )}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main AdminPage ──────────────────────────────────────────
const TABS = [
  { key: 'dashboard',  label: 'Dashboard' },
  { key: 'biblioteca', label: 'Biblioteca' },
  { key: 'simulador',  label: 'Simulador' },
  { key: 'usuarios',   label: 'Usuários' },
];

export default function AdminPage() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('dashboard');
  const [toast, setToast] = useState(null);

  const notify = useCallback((msg, type = 'ok') => {
    setToast({ msg, type, key: Date.now() });
  }, []);

  return (
    <div className={styles.page}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarLogo}>
          <span className={styles.logoMark}>J</span>
          <span className={styles.logoText}>Admin</span>
        </div>

        <nav className={styles.nav}>
          {TABS.map(t => (
            <button key={t.key}
              className={styles.navItem + (tab === t.key ? ' ' + styles.navItemActive : '')}
              onClick={() => setTab(t.key)}>
              {t.label}
            </button>
          ))}
        </nav>

        <div className={styles.sidebarFooter}>
          <p className={styles.footerName}>{user?.name}</p>
          <div className={styles.footerLinks}>
            <Link to="/" className={styles.footerLink}>← App</Link>
            <button className={styles.footerLink} onClick={logout}>Sair</button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className={styles.main}>
        <div className={styles.topBar}>
          <h2 className={styles.pageTitle}>
            {TABS.find(t => t.key === tab)?.label}
          </h2>
        </div>

        <div className={styles.content}>
          {tab === 'dashboard'  && <TabDashboard  notify={notify} />}
          {tab === 'biblioteca' && <TabBiblioteca notify={notify} />}
          {tab === 'simulador'  && <TabSimulador  notify={notify} />}
          {tab === 'usuarios'   && <TabUsuarios   notify={notify} currentUser={user} />}
        </div>
      </main>

      {toast && (
        <Toast key={toast.key} msg={toast.msg} type={toast.type}
          onClose={() => setToast(null)} />
      )}
    </div>
  );
}
