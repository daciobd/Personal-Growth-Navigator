/**
 * Rode este script UMA VEZ no Shell do Replit para adicionar
 * a coluna is_admin à tabela users:
 *
 *   node server/add-admin-column.js
 *
 * Depois, para tornar um usuário admin:
 *   node server/add-admin-column.js seu@email.com
 */
require('dotenv').config();
const pool = require('./db');

async function run() {
  const emailArg = process.argv[2];
  const client = await pool.connect();
  try {
    // Adiciona coluna se não existir
    await client.query(`
      ALTER TABLE users
      ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;
    `);
    console.log('✅ Coluna is_admin garantida na tabela users');

    if (emailArg) {
      const result = await client.query(
        'UPDATE users SET is_admin = true WHERE email = $1 RETURNING name, email',
        [emailArg]
      );
      if (result.rows.length === 0) {
        console.log(`❌ Usuário com email "${emailArg}" não encontrado`);
      } else {
        console.log(`✅ Usuário ${result.rows[0].name} (${result.rows[0].email}) agora é admin`);
      }
    } else {
      console.log('\nPara tornar um usuário admin, passe o email como argumento:');
      console.log('  node server/add-admin-column.js seu@email.com');
    }
  } finally {
    client.release();
    pool.end();
  }
}

run().catch(console.error);
