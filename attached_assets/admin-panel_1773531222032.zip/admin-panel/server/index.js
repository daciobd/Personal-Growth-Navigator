require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const authRoutes      = require('./routes/auth');
const plansRoutes     = require('./routes/plans');
const anthropicRoutes = require('./routes/anthropic');
const adminRoutes     = require('./routes/admin');      // ← NOVO

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? process.env.FRONTEND_URL || true
    : 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());

app.use('/api/auth',      authRoutes);
app.use('/api/plans',     plansRoutes);
app.use('/api/anthropic', anthropicRoutes);
app.use('/api/admin',     adminRoutes);               // ← NOVO

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist/index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`🌿 Servidor Jornada rodando na porta ${PORT}`);
  console.log(`   Admin: /admin`);
});
