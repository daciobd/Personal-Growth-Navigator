const jwt = require('jsonwebtoken');
const pool = require('../db');

/**
 * Middleware que verifica:
 * 1. Token JWT válido
 * 2. Usuário tem is_admin = true no banco
 *
 * Para tornar um usuário admin, rode no SQL:
 *   UPDATE users SET is_admin = true WHERE email = 'seu@email.com';
 */
module.exports = async function adminAuth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token não fornecido' });
  }
  const token = header.split(' ')[1];
  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return res.status(401).json({ error: 'Token inválido ou expirado' });
  }

  try {
    const result = await pool.query(
      'SELECT id, name, email, is_admin FROM users WHERE id = $1',
      [decoded.id]
    );
    if (!result.rows.length || !result.rows[0].is_admin) {
      return res.status(403).json({ error: 'Acesso restrito a administradores' });
    }
    req.user = result.rows[0];
    next();
  } catch (err) {
    console.error('Erro no adminAuth:', err.message);
    res.status(500).json({ error: 'Erro interno' });
  }
};
