/**
 * server/routes/admin.js
 *
 * Rotas do painel de administração.
 * Todas protegidas por adminAuth.
 *
 * Endpoints:
 *   GET  /api/admin/stats           — estatísticas gerais
 *   GET  /api/admin/biblioteca      — lê biblioteca.json completa
 *   PUT  /api/admin/biblioteca      — salva biblioteca.json inteira
 *   POST /api/admin/biblioteca/:approach/categoria — adiciona categoria
 *   POST /api/admin/biblioteca/:approach/categoria/:cat/intervencao — adiciona intervenção
 *   DELETE /api/admin/biblioteca/:approach/categoria/:cat/intervencao/:idx — remove intervenção
 *   GET  /api/admin/mapping         — lê big5-to-therapy.json
 *   PUT  /api/admin/mapping         — salva big5-to-therapy.json inteiro
 *   POST /api/admin/simulate        — simula seleção para um perfil Big Five
 *   GET  /api/admin/users           — lista usuários
 *   PUT  /api/admin/users/:id/admin — promove/rebaixa admin
 */

const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const adminAuth = require('../middleware/adminAuth');
const pool = require('../db');
const { selectInterventions } = require('../data/selectInterventions');

const router = express.Router();
router.use(adminAuth);

const BIBLIOTECA_PATH = path.join(__dirname, '../data/biblioteca.json');
const MAPPING_PATH    = path.join(__dirname, '../data/big5-to-therapy.json');

// Helpers
async function readJSON(filepath) {
  const raw = await fs.readFile(filepath, 'utf8');
  return JSON.parse(raw);
}
async function writeJSON(filepath, data) {
  await fs.writeFile(filepath, JSON.stringify(data, null, 2), 'utf8');
}

// ──────────────────────────────────────────────
// STATS
// ──────────────────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const [usersR, plansR, checkinsR, recentR] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM users'),
      pool.query('SELECT COUNT(*) FROM plans'),
      pool.query('SELECT COUNT(*) FROM checkins'),
      pool.query(`
        SELECT p.id, p.created_at, u.name, u.email,
               s.adjetivos_atual, s.adjetivos_futuro
        FROM plans p
        JOIN users u ON u.id = p.user_id
        JOIN sessions s ON s.id = p.session_id
        ORDER BY p.created_at DESC LIMIT 10
      `),
    ]);

    const biblioteca = await readJSON(BIBLIOTECA_PATH);
    const totalInterventions = Object.values(biblioteca).reduce((sum, ap) => {
      if (!ap.categorias) return sum;
      return sum + Object.values(ap.categorias).reduce((s, c) => s + c.length, 0);
    }, 0);

    res.json({
      users:    parseInt(usersR.rows[0].count),
      plans:    parseInt(plansR.rows[0].count),
      checkins: parseInt(checkinsR.rows[0].count),
      approaches: Object.keys(biblioteca).filter(k => !k.startsWith('_')).length,
      interventions: totalInterventions,
      recentPlans: recentR.rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar estatísticas' });
  }
});

// ──────────────────────────────────────────────
// BIBLIOTECA — leitura e escrita completa
// ──────────────────────────────────────────────
router.get('/biblioteca', async (req, res) => {
  try {
    const data = await readJSON(BIBLIOTECA_PATH);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao ler biblioteca' });
  }
});

router.put('/biblioteca', async (req, res) => {
  try {
    const { data } = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ error: 'Dados inválidos' });
    }
    await writeJSON(BIBLIOTECA_PATH, data);
    res.json({ message: 'Biblioteca salva com sucesso' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao salvar biblioteca' });
  }
});

// Adicionar intervenção em approach/categoria
router.post('/biblioteca/:approach/categoria/:cat/intervencao', async (req, res) => {
  try {
    const { approach, cat } = req.params;
    const { texto } = req.body;
    if (!texto?.trim()) return res.status(400).json({ error: 'Texto obrigatório' });

    const data = await readJSON(BIBLIOTECA_PATH);
    if (!data[approach]) return res.status(404).json({ error: 'Abordagem não encontrada' });
    if (!data[approach].categorias[cat]) {
      data[approach].categorias[cat] = [];
    }
    data[approach].categorias[cat].push(texto.trim());
    await writeJSON(BIBLIOTECA_PATH, data);
    res.json({ message: 'Intervenção adicionada', total: data[approach].categorias[cat].length });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao adicionar intervenção' });
  }
});

// Remover intervenção
router.delete('/biblioteca/:approach/categoria/:cat/intervencao/:idx', async (req, res) => {
  try {
    const { approach, cat, idx } = req.params;
    const data = await readJSON(BIBLIOTECA_PATH);
    const arr = data[approach]?.categorias?.[cat];
    if (!arr) return res.status(404).json({ error: 'Não encontrado' });

    const i = parseInt(idx);
    if (i < 0 || i >= arr.length) return res.status(400).json({ error: 'Índice inválido' });
    arr.splice(i, 1);
    await writeJSON(BIBLIOTECA_PATH, data);
    res.json({ message: 'Intervenção removida' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao remover intervenção' });
  }
});

// Adicionar nova categoria a uma abordagem
router.post('/biblioteca/:approach/categoria', async (req, res) => {
  try {
    const { approach } = req.params;
    const { nome } = req.body;
    if (!nome?.trim()) return res.status(400).json({ error: 'Nome obrigatório' });

    const data = await readJSON(BIBLIOTECA_PATH);
    if (!data[approach]) return res.status(404).json({ error: 'Abordagem não encontrada' });
    if (data[approach].categorias[nome.trim()]) {
      return res.status(409).json({ error: 'Categoria já existe' });
    }
    data[approach].categorias[nome.trim()] = [];
    await writeJSON(BIBLIOTECA_PATH, data);
    res.json({ message: 'Categoria criada' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao criar categoria' });
  }
});

// Adicionar nova abordagem
router.post('/biblioteca/abordagem', async (req, res) => {
  try {
    const { key, nome } = req.body;
    if (!key?.trim() || !nome?.trim()) return res.status(400).json({ error: 'Chave e nome obrigatórios' });

    const data = await readJSON(BIBLIOTECA_PATH);
    if (data[key]) return res.status(409).json({ error: 'Abordagem já existe' });
    data[key] = { nome: nome.trim(), categorias: {} };
    await writeJSON(BIBLIOTECA_PATH, data);
    res.json({ message: 'Abordagem criada' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao criar abordagem' });
  }
});

// ──────────────────────────────────────────────
// MAPEAMENTO Big Five → Abordagens
// ──────────────────────────────────────────────
router.get('/mapping', async (req, res) => {
  try {
    const data = await readJSON(MAPPING_PATH);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao ler mapeamento' });
  }
});

router.put('/mapping', async (req, res) => {
  try {
    const { data } = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ error: 'Dados inválidos' });
    }
    await writeJSON(MAPPING_PATH, data);
    res.json({ message: 'Mapeamento salvo com sucesso' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao salvar mapeamento' });
  }
});

// ──────────────────────────────────────────────
// SIMULADOR — testa seleção para um perfil
// ──────────────────────────────────────────────
router.post('/simulate', async (req, res) => {
  try {
    const { pct, facetPct } = req.body;
    if (!pct) return res.status(400).json({ error: 'pct obrigatório' });

    const result = selectInterventions(pct, facetPct || {});
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro na simulação' });
  }
});

// ──────────────────────────────────────────────
// USUÁRIOS
// ──────────────────────────────────────────────
router.get('/users', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, email, is_admin, created_at FROM users ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar usuários' });
  }
});

router.put('/users/:id/admin', async (req, res) => {
  try {
    const { is_admin } = req.body;
    if (parseInt(req.params.id) === req.user.id) {
      return res.status(400).json({ error: 'Você não pode alterar seu próprio status' });
    }
    await pool.query('UPDATE users SET is_admin = $1 WHERE id = $2', [!!is_admin, req.params.id]);
    res.json({ message: is_admin ? 'Usuário promovido a admin' : 'Admin removido' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao atualizar usuário' });
  }
});

module.exports = router;
