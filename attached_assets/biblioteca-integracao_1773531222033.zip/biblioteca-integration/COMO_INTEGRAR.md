# 📚 Integração da Biblioteca Clínica — Guia Passo a Passo

## O que esta atualização faz

Antes, a IA recebia apenas o perfil Big Five e os adjetivos de futuro.
Agora, ela recebe também **30 micro-intervenções clínicas** selecionadas
automaticamente com base no perfil, tiradas da biblioteca de 9 abordagens.

Resultado: planos terapêuticos muito mais precisos, clinicamente
fundamentados e com linguagem terapêutica real.

---

## Arquivos que você está adicionando

```
server/
  data/
    biblioteca.json          ← Biblioteca de micro-intervenções (9 abordagens)
    big5-to-therapy.json     ← Mapeamento Big Five → abordagens
    selectInterventions.js   ← Motor de seleção
  routes/
    anthropic.js             ← SUBSTITUI o arquivo existente
```

---

## Passo a passo no Replit

### 1. Adicionar os 3 novos arquivos

No painel de arquivos do Replit:
- Crie a pasta `server/data/` (se não existir)
- Faça upload ou crie manualmente:
  - `server/data/biblioteca.json`
  - `server/data/big5-to-therapy.json`
  - `server/data/selectInterventions.js`

### 2. Substituir o anthropic.js

- Abra `server/routes/anthropic.js`
- Substitua TODO o conteúdo pelo arquivo `anthropic.js` desta pasta

### 3. Atualizar o frontend (JornadaPage.jsx)

Procure a chamada `api.generate(...)` e atualize para enviar os scores:

```javascript
// ANTES
const { text } = await api.generate({
  adjetivosAtual: getLabels(atualSel),
  adjetivosFuturo: getLabels(futuroSel),
});

// DEPOIS — inclui o big5Scores
const { text, approaches } = await api.generate({
  adjetivosAtual: getLabels(atualSel),
  adjetivosFuturo: getLabels(futuroSel),
  big5Scores: state.scores,  // { pct: {...}, facetPct: {...} }
});

// Opcional: salvar as approaches para exibir no plano
if (approaches) setState(prev => ({ ...prev, planApproaches: approaches }));
```

### 4. Atualizar o api.js (se necessário)

O arquivo `client/src/api.js` já suporta qualquer corpo JSON — não precisa alterar.

### 5. Testar

```bash
# No Shell do Replit
npm run dev
```

Faça o teste completo: Big Five → visão de futuro → gerar plano.
O plano deve agora citar as abordagens corretas para o perfil.

---

## Como funciona a seleção

O motor `selectInterventions.js` aplica regras em dois níveis:

**Nível 1 — Dimensões:**
| Perfil | Abordagens ativadas |
|--------|---------------------|
| Neuroticismo alto (≥60%) | CFT + DBT + ACT |
| Neuroticismo muito alto (≥80%) | + EMDR |
| Extroversão baixa (≤35%) | Psicodinâmica + Junguiana |
| Abertura alta (≥60%) | Junguiana + Gestalt + ACT |
| Amabilidade baixa (≤40%) | TIP + Psicodinâmica |
| Conscienciosidade baixa (≤40%) | TCC + DBT |

**Nível 2 — Facetas:**
Ajustes finos por facetas específicas
(ex: Hostilidade alta → TCC + TIP; Sentimentos altos → Gestalt + CFT)

**Resultado:** 3 abordagens + 10 intervenções/abordagem = 30 intervenções no prompt.

---

## Expandindo a biblioteca

Para adicionar mais intervenções, edite `servidor/data/biblioteca.json`.
Estrutura de uma abordagem:

```json
"NOME_ABORDAGEM": {
  "nome": "Nome completo",
  "categorias": {
    "Nome da categoria": [
      "Intervenção 1",
      "Intervenção 2"
    ]
  }
}
```

Para adicionar uma nova abordagem ao mapeamento, edite
`big5-to-therapy.json` e adicione regras nas seções
`dimensionRules` ou `facetRules`.

---

## Próximos passos sugeridos

- [ ] Adicionar tabela `interventions` no banco para logar quais
      intervenções foram usadas em cada plano (análise futura)
- [ ] Criar endpoint `GET /api/library/:approach` para o
      terapeuta consultar a biblioteca pelo painel admin
- [ ] Versão pgvector: armazenar embeddings das intervenções
      para busca semântica ainda mais precisa
