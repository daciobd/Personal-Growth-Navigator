/**
 * selectInterventions.js
 *
 * Motor de seleção de intervenções terapêuticas baseado no perfil Big Five.
 * 
 * Uso:
 *   const { approaches, interventions, rationale } = selectInterventions(pct, facetPct);
 *
 * Retorna:
 *   - approaches: array de abordagens selecionadas (ex: ["CFT", "DBT", "ACT"])
 *   - interventions: objeto { abordagem: [lista de intervenções selecionadas] }
 *   - rationale: texto explicando por que essas abordagens foram escolhidas
 *   - promptBlock: bloco formatado pronto para inserir no prompt da Anthropic API
 */

const mapping = require('./big5-to-therapy.json');
const biblioteca = require('./biblioteca.json');

const MAX_APPROACHES = 3;       // Máximo de abordagens por usuário
const INTERVENTIONS_PER_APPROACH = 10; // Intervenções por abordagem no prompt

function selectInterventions(pct, facetPct) {
  const selectedApproaches = new Set();
  const rationaleLines = [];

  // 1. Aplicar regras por dimensão
  for (const rule of mapping.dimensionRules) {
    const score = pct[rule.dimension];
    const { thresholds } = rule;

    if (thresholds.veryHigh && score >= thresholds.veryHigh.min) {
      thresholds.veryHigh.approaches.forEach(a => selectedApproaches.add(a));
      rationaleLines.push(`${rule.label} muito alto (${score}%): ${thresholds.veryHigh.rationale}`);
    } else if (thresholds.high && score >= thresholds.high.min) {
      thresholds.high.approaches.forEach(a => selectedApproaches.add(a));
      rationaleLines.push(`${rule.label} alto (${score}%): ${thresholds.high.rationale}`);
    } else if (thresholds.low && score <= thresholds.low.max) {
      thresholds.low.approaches.forEach(a => selectedApproaches.add(a));
      rationaleLines.push(`${rule.label} baixo (${score}%): ${thresholds.low.rationale}`);
    }
  }

  // 2. Refinar com regras por faceta
  if (facetPct) {
    for (const facetRule of mapping.facetRules) {
      const score = facetPct[facetRule.facet];
      if (score === undefined) continue;

      if (facetRule.high && score >= facetRule.high.min) {
        facetRule.high.add.forEach(a => selectedApproaches.add(a));
        rationaleLines.push(`Faceta ${facetRule.label} elevada (${score}%): acrescenta ${facetRule.high.add.join(', ')}`);
      }
      if (facetRule.low && score <= facetRule.low.max) {
        facetRule.low.add.forEach(a => selectedApproaches.add(a));
        rationaleLines.push(`Faceta ${facetRule.label} baixa (${score}%): acrescenta ${facetRule.low.add.join(', ')}`);
      }
    }
  }

  // 3. Garantir abordagens padrão se nada foi selecionado
  if (selectedApproaches.size === 0) {
    mapping.defaultApproaches.forEach(a => selectedApproaches.add(a));
    rationaleLines.push('Perfil equilibrado: aplicando abordagens padrão TCC + ACT.');
  }

  // 4. Limitar ao máximo de abordagens — prioriza as que aparecem mais nas regras
  const approachCount = {};
  rationaleLines.forEach(line => {
    Object.keys(biblioteca).forEach(ap => {
      if (line.includes(ap)) approachCount[ap] = (approachCount[ap] || 0) + 1;
    });
  });

  const sortedApproaches = [...selectedApproaches].sort(
    (a, b) => (approachCount[b] || 0) - (approachCount[a] || 0)
  ).slice(0, MAX_APPROACHES);

  // 5. Coletar intervenções de cada abordagem selecionada
  const interventions = {};

  for (const approach of sortedApproaches) {
    const lib = biblioteca[approach];
    if (!lib) continue;

    const allInterventions = [];
    for (const [categoria, items] of Object.entries(lib.categorias)) {
      items.forEach(item => allInterventions.push({ categoria, texto: item }));
    }

    // Distribuir uniformemente pelas categorias disponíveis
    const categoriasDisponiveis = Object.keys(lib.categorias);
    const selected = [];
    const perCategory = Math.ceil(INTERVENTIONS_PER_APPROACH / categoriasDisponiveis.length);

    for (const cat of categoriasDisponiveis) {
      const catItems = lib.categorias[cat].slice(0, perCategory);
      selected.push(...catItems.map(t => `[${cat}] ${t}`));
    }

    interventions[approach] = selected.slice(0, INTERVENTIONS_PER_APPROACH);
  }

  // 6. Montar bloco formatado para o prompt
  const promptBlock = buildPromptBlock(sortedApproaches, interventions, rationaleLines);

  return {
    approaches: sortedApproaches,
    interventions,
    rationale: rationaleLines.join('\n'),
    promptBlock,
  };
}

function buildPromptBlock(approaches, interventions, rationaleLines) {
  const lines = [];

  lines.push('=== BIBLIOTECA CLÍNICA DE INTERVENÇÕES ===');
  lines.push('');
  lines.push('Com base no perfil Big Five deste cliente, as seguintes abordagens foram identificadas como mais relevantes:');
  lines.push('');

  approaches.forEach(ap => {
    const info = biblioteca[ap];
    if (!info) return;
    const desc = require('./big5-to-therapy.json').approachDescriptions[ap] || '';
    lines.push(`▸ ${ap} — ${info.nome}`);
    if (desc) lines.push(`  ${desc}`);
  });

  lines.push('');
  lines.push('MICRO-INTERVENÇÕES SELECIONADAS PARA ESTE PERFIL:');
  lines.push('(Use estas intervenções como base e inspiração para as práticas do plano)');
  lines.push('');

  approaches.forEach(ap => {
    const invs = interventions[ap];
    if (!invs || invs.length === 0) return;

    lines.push(`--- ${ap} ---`);
    invs.forEach(inv => lines.push(`• ${inv}`));
    lines.push('');
  });

  lines.push('=== FIM DA BIBLIOTECA ===');

  return lines.join('\n');
}

module.exports = { selectInterventions };
