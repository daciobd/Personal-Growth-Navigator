/**
 * server/routes/anthropic.js  — VERSÃO COM BIBLIOTECA CLÍNICA
 *
 * Substitua o arquivo original por este.
 * A diferença principal: antes de chamar a API, chama selectInterventions()
 * para enriquecer o prompt com micro-intervenções relevantes ao perfil Big Five.
 */

const express = require('express');
const auth = require('../middleware/auth');
const { selectInterventions } = require('../data/selectInterventions');

const router = express.Router();

// POST /api/anthropic/generate
router.post('/generate', auth, async (req, res) => {
  const { adjetivosAtual, adjetivosFuturo, big5Scores } = req.body;

  // big5Scores = { pct: {N,E,O,A,C}, facetPct: {N1..C6} }
  // adjetivosAtual: opcional — pode vir vazio se estiver usando só Big Five
  // adjetivosFuturo: obrigatório

  if (!adjetivosFuturo?.length) {
    return res.status(400).json({ error: 'Visão de futuro é obrigatória' });
  }
  if (!big5Scores?.pct) {
    return res.status(400).json({ error: 'Perfil Big Five é obrigatório' });
  }

  // ---- 1. Selecionar intervenções baseadas no perfil ----
  const { approaches, promptBlock, rationale } = selectInterventions(
    big5Scores.pct,
    big5Scores.facetPct
  );

  // ---- 2. Montar descrição do perfil Big Five ----
  const DIM_NAMES = { N:'Neuroticismo', E:'Extroversão', O:'Abertura', A:'Amabilidade', C:'Conscienciosidade' };
  const DIM_LEVELS = p => p < 30 ? 'Baixo' : p < 50 ? 'Moderado-baixo' : p < 70 ? 'Moderado' : p < 85 ? 'Alto' : 'Muito alto';

  const FACET_NAMES = {
    N1:'Ansiedade', N2:'Hostilidade', N3:'Depressão', N4:'Autoconsciência', N5:'Impulsividade', N6:'Vulnerabilidade',
    E1:'Cordialidade', E2:'Gregarismo', E3:'Assertividade', E4:'Atividade', E5:'Busca de excitação', E6:'Emoções positivas',
    O1:'Fantasia', O2:'Estética', O3:'Sentimentos', O4:'Ações', O5:'Ideias', O6:'Valores',
    A1:'Confiança', A2:'Franqueza', A3:'Altruísmo', A4:'Complacência', A5:'Modéstia', A6:'Sensibilidade',
    C1:'Competência', C2:'Ordem', C3:'Senso de dever', C4:'Busca por realização', C5:'Autodisciplina', C6:'Deliberação',
  };

  const dimProfile = Object.entries(big5Scores.pct)
    .map(([d, p]) => {
      // Top 2 facetas da dimensão
      const facetsOfDim = Object.entries(big5Scores.facetPct || {})
        .filter(([k]) => k.startsWith(d))
        .sort((a, b) => b[1] - a[1])
        .slice(0, 2)
        .map(([k, v]) => `${FACET_NAMES[k] || k}:${v}%`)
        .join(', ');
      return `${DIM_NAMES[d]}: ${p}% (${DIM_LEVELS(p)}) | Facetas em destaque: ${facetsOfDim}`;
    })
    .join('\n');

  // ---- 3. Montar o prompt enriquecido ----
  const prompt = `Você é um psicólogo clínico especialista em psicoterapia integrativa, com formação avançada em múltiplas abordagens terapêuticas baseadas em evidências.

Você realizou uma avaliação completa de personalidade Big Five (IPIP-NEO-120) e agora deve criar um plano terapêutico personalizado e clinicamente fundamentado.

=== PERFIL DE PERSONALIDADE (IPIP-NEO-120) ===
${dimProfile}

=== VISÃO DE FUTURO DO CLIENTE ===
O cliente deseja se tornar: ${adjetivosFuturo.join(', ')}
${adjetivosAtual?.length ? `Perfil atual percebido: ${adjetivosAtual.join(', ')}` : ''}

=== ABORDAGENS INDICADAS PARA ESTE PERFIL ===
Com base na análise do perfil, as abordagens mais indicadas são: ${approaches.join(', ')}

${promptBlock}

=== INSTRUÇÕES PARA O PLANO ===
Use as micro-intervenções acima como BASE CLÍNICA para fundamentar as práticas. Cada prática deve estar ancorada na abordagem indicada e conectada diretamente ao perfil Big Five do cliente.

Crie o plano usando EXATAMENTE este formato (não inclua nenhum texto antes de SÍNTESE):

SÍNTESE:
[2-3 frases clínicas e acolhedoras que conectem o perfil Big Five ao desejo de mudança. Mencione dimensões específicas.]

PRÁTICA 1:
Nome: [nome clínico da técnica — ex: "Reestruturação Cognitiva", "Autocompaixão em Ação"]
Abordagem: [${approaches[0] || 'TCC'}]
Por que para você: [1-2 frases conectando ao perfil Big Five específico deste cliente]
Como fazer: [3-4 passos numerados, concretos, com linguagem acessível]
Frequência: [sugestão prática e realista]

PRÁTICA 2:
Nome: [técnica DIFERENTE]
Abordagem: [${approaches[1] || 'ACT'} ou outra indicada]
Por que para você: [1-2 frases]
Como fazer: [3-4 passos]
Frequência: [sugestão]

PRÁTICA 3:
Nome: [técnica DIFERENTE das anteriores]
Abordagem: [${approaches[2] || approaches[0] || 'DBT'} ou outra indicada]
Por que para você: [1-2 frases]
Como fazer: [3-4 passos]
Frequência: [sugestão]

INTENÇÃO:
[Uma frase poderosa na primeira pessoa que capture a essência desta jornada de transformação]

Responda inteiramente em português brasileiro. Seja clinicamente preciso, acolhedor e prático.`;

  // ---- 4. Chamar a API da Anthropic ----
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('Erro Anthropic API:', err);
      return res.status(502).json({ error: 'Erro ao contatar a IA. Tente novamente.' });
    }

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    if (!text) throw new Error('Resposta vazia da API');

    // Retorna o plano + as abordagens usadas (útil para exibir no frontend)
    res.json({ text, approaches, rationale });

  } catch (err) {
    console.error('Erro ao chamar Anthropic:', err.message);
    res.status(500).json({ error: 'Erro interno ao gerar plano' });
  }
});

module.exports = router;
