# 🌿 Jornada — App de Transformação Pessoal

App fullstack de crescimento pessoal com IA. O usuário seleciona adjetivos que o descrevem hoje e como deseja se tornar no futuro. A IA gera um plano personalizado com práticas terapêuticas baseadas em TCC, ACT, Psicologia Positiva e Mindfulness/DBT.

---

## 🚀 Como rodar no Replit

### 1. Crie o projeto no Replit
- Acesse [replit.com](https://replit.com) → **Create Repl** → **Import from GitHub** ou **Node.js**
- Faça upload de todos os arquivos deste projeto

### 2. Configure o banco de dados
- No Replit, vá na aba lateral **Database** → clique em **PostgreSQL**
- Copie a `DATABASE_URL` gerada

### 3. Configure os Secrets (variáveis de ambiente)
Na aba **Secrets** do Replit, adicione:

| Chave | Valor |
|-------|-------|
| `ANTHROPIC_API_KEY` | Sua chave em [console.anthropic.com](https://console.anthropic.com) |
| `DATABASE_URL` | URL do PostgreSQL gerada no passo 2 |
| `JWT_SECRET` | Qualquer string longa e aleatória (ex: `minha-chave-super-secreta-2024`) |
| `NODE_ENV` | `production` |

### 4. Instale dependências e crie as tabelas
No Shell do Replit:
```bash
npm install
npm install --prefix client
node server/db-setup.js
```

### 5. Rode o app
```bash
npm run dev
```

O Replit vai abrir automaticamente a URL pública do seu app. 🎉

---

## 📁 Estrutura do projeto

```
jornada/
├── server/
│   ├── index.js          # Servidor Express
│   ├── db.js             # Conexão com PostgreSQL
│   ├── db-setup.js       # Cria as tabelas no banco
│   ├── middleware/
│   │   └── auth.js       # Verificação de JWT
│   └── routes/
│       ├── auth.js       # Login e registro
│       ├── plans.js      # Salvar e buscar planos
│       └── anthropic.js  # Proxy seguro da API
├── client/
│   ├── src/
│   │   ├── App.jsx       # Rotas principais
│   │   ├── api.js        # Helper de requisições
│   │   ├── contexts/
│   │   │   └── AuthContext.jsx
│   │   ├── data/
│   │   │   └── adjetivos.js
│   │   └── pages/
│   │       ├── LoginPage.jsx
│   │       ├── RegisterPage.jsx
│   │       ├── JornadaPage.jsx   # Fluxo principal
│   │       └── HistoricoPage.jsx # Histórico de planos
│   └── index.html
├── .env.example
├── .replit
└── package.json
```

---

## 🗃️ Banco de dados (tabelas criadas automaticamente)

| Tabela | Descrição |
|--------|-----------|
| `users` | Usuários cadastrados |
| `sessions` | Cada sessão de seleção de adjetivos |
| `plans` | Planos gerados pela IA |
| `checkins` | Check-ins semanais de progresso (1–5) |

---

## 🔒 Segurança

- A chave da Anthropic API **nunca é exposta** no frontend — todas as chamadas passam pelo proxy `/api/anthropic/generate`
- Senhas são armazenadas com **bcrypt** (salt 12)
- Autenticação via **JWT** com expiração de 30 dias
- CORS configurado para aceitar apenas a origem do frontend em produção

---

## 🛣️ Próximas funcionalidades sugeridas

- [ ] Check-ins semanais com gráfico de progresso
- [ ] Notificações por e-mail (lembrete das práticas)
- [ ] Exportar plano em PDF
- [ ] Dashboard com evolução dos adjetivos ao longo do tempo
- [ ] Modo terapeuta (visualizar histórico de pacientes)
