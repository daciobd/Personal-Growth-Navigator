const BASE = '/api';

function getToken() {
  return localStorage.getItem('jornada_token');
}

async function request(path, options = {}) {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Erro inesperado');
  return data;
}

export const api = {
  // Auth
  register: (body) => request('/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  login:    (body) => request('/auth/login',    { method: 'POST', body: JSON.stringify(body) }),
  me:       ()     => request('/auth/me'),

  // Geração do plano (via proxy seguro)
  generate: (body) => request('/anthropic/generate', { method: 'POST', body: JSON.stringify(body) }),

  // Planos
  savePlan:  (body) => request('/plans',              { method: 'POST', body: JSON.stringify(body) }),
  getPlans:  ()     => request('/plans'),
  getPlan:   (id)   => request(`/plans/${id}`),
  checkin:   (id, body) => request(`/plans/${id}/checkin`, { method: 'POST', body: JSON.stringify(body) }),
};
