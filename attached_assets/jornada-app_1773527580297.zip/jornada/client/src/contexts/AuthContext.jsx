import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('jornada_token');
    const saved = localStorage.getItem('jornada_user');
    if (token && saved) {
      try {
        setUser(JSON.parse(saved));
      } catch { localStorage.clear(); }
    }
    setLoading(false);
  }, []);

  const login = (token, userData) => {
    localStorage.setItem('jornada_token', token);
    localStorage.setItem('jornada_user', JSON.stringify(userData));
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('jornada_token');
    localStorage.removeItem('jornada_user');
    setUser(null);
  };

  const getToken = () => localStorage.getItem('jornada_token');

  return (
    <AuthContext.Provider value={{ user, login, logout, getToken, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
