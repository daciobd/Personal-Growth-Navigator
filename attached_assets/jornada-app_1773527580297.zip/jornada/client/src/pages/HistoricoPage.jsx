import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import styles from './Historico.module.css';

export default function HistoricoPage() {
  const { user, logout } = useAuth();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getPlans()
      .then(setPlans)
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  function formatDate(iso) {
    return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  }

  return (
    <div className={styles.app}>
      <header className={styles.header}>
        <div className={styles.headerInner}>
          <Link to="/" className={styles.logo}>Jornada</Link>
          <div className={styles.headerRight}>
            <Link to="/" className={styles.navLink}>Nova jornada</Link>
            <button className={styles.navLink} onClick={logout}>Sair</button>
          </div>
        </div>
      </header>

      <main className={styles.main}>
        <p className={styles.eyebrow + ' fade-up'}>Olá, {user?.name?.split(' ')[0]}</p>
        <h1 className={styles.title + ' fade-up-1'}>Seu histórico de jornadas</h1>

        {loading && (
          <div className={styles.centered}><div className="spinner" /></div>
        )}
        {error && <div className={styles.error}>{error}</div>}

        {!loading && plans.length === 0 && (
          <div className={styles.empty + ' fade-up-2'}>
            <p>Você ainda não tem planos salvos.</p>
            <Link to="/" className={styles.btnPrimary} style={{ display:'inline-block', marginTop:20 }}>
              Começar primeira jornada →
            </Link>
          </div>
        )}

        <div className={styles.grid}>
          {plans.map((plan, i) => (
            <div key={plan.id} className={styles.card + ' fade-up'} style={{ animationDelay: `${i * 0.06}s` }}>
              <p className={styles.cardDate}>{formatDate(plan.created_at)}</p>
              <div className={styles.cardProfile}>
                <div className={styles.cardRow}>
                  <span className={styles.cardLabel}>Hoje</span>
                  <div className={styles.chipRow}>
                    {(plan.adjetivos_atual || []).slice(0,4).map(l => (
                      <span key={l} className={styles.pcAtual}>{l}</span>
                    ))}
                    {(plan.adjetivos_atual || []).length > 4 && <span className={styles.more}>+{plan.adjetivos_atual.length - 4}</span>}
                  </div>
                </div>
                <div className={styles.divider} />
                <div className={styles.cardRow}>
                  <span className={styles.cardLabel}>Futuro</span>
                  <div className={styles.chipRow}>
                    {(plan.adjetivos_futuro || []).slice(0,4).map(l => (
                      <span key={l} className={styles.pcFuturo}>{l}</span>
                    ))}
                    {(plan.adjetivos_futuro || []).length > 4 && <span className={styles.more}>+{plan.adjetivos_futuro.length - 4}</span>}
                  </div>
                </div>
              </div>
              {plan.sintese && (
                <p className={styles.cardSintese}>"{plan.sintese.substring(0, 140)}{plan.sintese.length > 140 ? '…' : ''}"</p>
              )}
              {plan.intencao && (
                <p className={styles.cardIntencao}>{plan.intencao}</p>
              )}
              <div className={styles.cardPraticas}>
                {(plan.praticas || []).map((pr, j) => (
                  <span key={j} className={styles.praticaTag}>{pr.nome}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
