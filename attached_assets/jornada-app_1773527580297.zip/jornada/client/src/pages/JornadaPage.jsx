import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { ADJETIVOS, CATEGORIAS } from '../data/adjetivos';
import styles from './Jornada.module.css';

function parsePlan(text) {
  const getBlock = (start, end) => {
    const pattern = end
      ? new RegExp(`${start}:\\s*([\\s\\S]*?)(?=${end}:|$)`, 'i')
      : new RegExp(`${start}:\\s*([\\s\\S]*)$`, 'i');
    const m = text.match(pattern);
    return m ? m[1].trim() : '';
  };
  const parsePratica = (block) => {
    if (!block) return null;
    const field = key => { const m = block.match(new RegExp(`${key}:\\s*([^\\n]+)`, 'i')); return m ? m[1].trim() : ''; };
    const comoM = block.match(/Como fazer:\s*([\s\S]*?)(?=Frequência:|$)/i);
    return { nome: field('Nome'), abordagem: field('Abordagem'), porque: field('Por que para você'), como: comoM ? comoM[1].trim() : '', frequencia: field('Frequência') };
  };
  return {
    sintese: getBlock('SÍNTESE', 'PRÁTICA 1'),
    praticas: [
      parsePratica(getBlock('PRÁTICA 1', 'PRÁTICA 2')),
      parsePratica(getBlock('PRÁTICA 2', 'PRÁTICA 3')),
      parsePratica(getBlock('PRÁTICA 3', 'INTENÇÃO')),
    ].filter(p => p && p.nome),
    intencao: getBlock('INTENÇÃO', null),
    raw: text,
  };
}

function badgeClass(ab) {
  if (!ab) return styles.badgeDef;
  const u = ab.toUpperCase();
  if (u.includes('TCC')) return styles.badgeTcc;
  if (u.includes('ACT')) return styles.badgeAct;
  if (u.includes('POSITIVA')) return styles.badgePos;
  if (u.includes('MINDFUL') || u.includes('DBT')) return styles.badgeMind;
  return styles.badgeDef;
}

export default function JornadaPage() {
  const { user, logout } = useAuth();
  const [step, setStep] = useState(0);
  const [atualSel, setAtualSel] = useState(new Set());
  const [futuroSel, setFuturoSel] = useState(new Set());
  const [catFilter, setCatFilter] = useState('Todos');
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState(null);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  const toggle = (which, id) => {
    const setter = which === 'atual' ? setAtualSel : setFuturoSel;
    setter(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const getLabels = sel => [...sel].map(id => ADJETIVOS.find(a => a.id === id)?.l).filter(Boolean);

  async function generate() {
    setLoading(true); setError('');
    try {
      const { text } = await api.generate({
        adjetivosAtual: getLabels(atualSel),
        adjetivosFuturo: getLabels(futuroSel),
      });
      const parsed = parsePlan(text);
      setPlan(parsed);
      setStep(3);
      // Salva automaticamente após gerar
      try {
        await api.savePlan({
          adjetivosAtual: getLabels(atualSel),
          adjetivosFuturo: getLabels(futuroSel),
          ...parsed,
          rawResponse: text,
        });
        setSaved(true);
      } catch { /* falha silenciosa no save */ }
    } catch (err) {
      setError(err.message || 'Erro ao gerar plano. Tente novamente.');
    } finally {
      setLoading(false);
    }
  }

  function restart() {
    setStep(0); setAtualSel(new Set()); setFuturoSel(new Set());
    setCatFilter('Todos'); setPlan(null); setError(''); setSaved(false);
  }

  const filtered = catFilter === 'Todos' ? ADJETIVOS : ADJETIVOS.filter(a => a.c === catFilter);
  const pct = ['0%', '33%', '66%', '100%'][step] || '0%';

  if (loading) return (
    <div className={styles.loadingWrap}>
      <div className="spinner" />
      <p className={styles.loadingTitle}>Criando seu plano personalizado…</p>
      <p className={styles.loadingSub}>Analisando seu perfil com IA terapêutica</p>
    </div>
  );

  return (
    <div className={styles.app}>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.headerInner}>
          <span className={styles.logo}>Jornada</span>
          <div className={styles.progressWrap}>
            <div className={styles.progressBar} style={{ width: pct }} />
          </div>
          <div className={styles.headerRight}>
            <Link to="/historico" className={styles.navLink}>Histórico</Link>
            <button className={styles.navLink} onClick={logout}>Sair</button>
          </div>
        </div>
      </header>

      <main className={styles.main}>
        {/* STEP 0 — Welcome */}
        {step === 0 && (
          <div>
            <p className={styles.eyebrow + ' fade-up'}>Olá, {user?.name?.split(' ')[0]} 👋</p>
            <h1 className={styles.welcomeTitle + ' fade-up-1'}>
              Quem você é.<br /><em>Quem você pode ser.</em>
            </h1>
            <p className={styles.welcomeSub + ' fade-up-2'}>
              Uma jornada guiada por TCC, ACT, Psicologia Positiva e Mindfulness para criar seu plano personalizado de crescimento.
            </p>
            <div className={styles.pillRow + ' fade-up-2'}>
              {['🧠 TCC', '🌿 ACT', '✨ Psicologia Positiva', '🧘 Mindfulness · DBT'].map(p => (
                <span key={p} className={styles.pill}>{p}</span>
              ))}
            </div>
            <button className={styles.btnPrimary + ' fade-up-3'} onClick={() => setStep(1)}>
              Começar minha jornada →
            </button>
          </div>
        )}

        {/* STEP 1 & 2 — Seleção de adjetivos */}
        {(step === 1 || step === 2) && (() => {
          const isAtual = step === 1;
          const sel = isAtual ? atualSel : futuroSel;
          const canNext = sel.size >= 3;
          return (
            <div>
              <h2 className={styles.selTitle + ' fade-up'}>
                {isAtual ? 'Como você se vê hoje?' : 'Quem você deseja se tornar?'}
              </h2>
              <p className={styles.selSub + ' fade-up-1'}>
                {isAtual
                  ? 'Selecione ao menos 3 adjetivos que te descrevem agora.'
                  : 'Escolha ao menos 3 adjetivos que representam seu eu futuro.'}
              </p>
              <div className={styles.catBar + ' fade-up-1'}>
                {CATEGORIAS.map(c => (
                  <button key={c}
                    className={styles.catBtn + (catFilter === c ? ' ' + styles.catBtnActive : '')}
                    onClick={() => setCatFilter(c)}>{c}</button>
                ))}
              </div>
              <div className={styles.chips + ' fade-up-2'}>
                {filtered.map(a => (
                  <button key={a.id}
                    className={styles.chip + (sel.has(a.id) ? ' ' + styles.chipSel : '')}
                    onClick={() => toggle(isAtual ? 'atual' : 'futuro', a.id)}>
                    {a.l}
                  </button>
                ))}
              </div>
              <p className={styles.counter}>
                {sel.size} selecionado{sel.size !== 1 ? 's' : ''}
                {sel.size > 0 && sel.size < 3 && <span style={{ color: '#C4622D' }}> · selecione ao menos 3</span>}
              </p>
              {sel.size > 0 && (
                <div className={styles.preview}>
                  {[...sel].map(id => {
                    const a = ADJETIVOS.find(x => x.id === id);
                    return <span key={id} className={styles.previewChip + ' ' + (isAtual ? styles.pcAtual : styles.pcFuturo)}>{a?.l}</span>;
                  })}
                </div>
              )}
              {error && <div className={styles.errorBox}>{error}</div>}
              <div className={styles.actions}>
                {step === 2 && <button className={styles.btnSecondary} onClick={() => { setStep(1); setError(''); }}>← Voltar</button>}
                <button className={styles.btnPrimary} disabled={!canNext}
                  onClick={() => isAtual ? setStep(2) : generate()}>
                  {isAtual ? 'Próximo →' : 'Gerar meu plano →'}
                </button>
              </div>
            </div>
          );
        })()}

        {/* STEP 3 — Plano */}
        {step === 3 && plan && (
          <div>
            <p className={styles.eyebrow + ' fade-up'}>
              {saved ? '✓ Plano salvo no seu histórico' : 'Seu plano personalizado'}
            </p>
            <h2 className={styles.planTitle + ' fade-up-1'}>Sua jornada de transformação</h2>

            {/* Perfil */}
            <div className={styles.profileCard + ' fade-up-2'}>
              <div className={styles.profileRow}>
                <span className={styles.profileLabel}>Hoje</span>
                <div className={styles.profileChips}>
                  {getLabels(atualSel).map(l => <span key={l} className={styles.pcAtual}>{l}</span>)}
                </div>
              </div>
              <div className={styles.profileDivider} />
              <div className={styles.profileRow}>
                <span className={styles.profileLabel}>Futuro</span>
                <div className={styles.profileChips}>
                  {getLabels(futuroSel).map(l => <span key={l} className={styles.pcFuturo}>{l}</span>)}
                </div>
              </div>
            </div>

            {/* Síntese */}
            {plan.sintese && (
              <div className={styles.sinteseCard + ' fade-up-2'}>
                <p className={styles.sinteseLabel}>Síntese da sua jornada</p>
                <p className={styles.sinteseText}>{plan.sintese}</p>
              </div>
            )}

            {/* Práticas */}
            {plan.praticas.map((pr, i) => (
              <div key={i} className={styles.praticaCard + ' fade-up-2'}>
                <div className={styles.praticaHeader}>
                  <span className={styles.praticaNum}>Prática {i + 1}</span>
                  {pr.abordagem && <span className={styles.badge + ' ' + badgeClass(pr.abordagem)}>{pr.abordagem}</span>}
                </div>
                {pr.nome && <h3 className={styles.praticaNome}>{pr.nome}</h3>}
                {pr.porque && <p className={styles.praticaPorque}>{pr.porque}</p>}
                {pr.como && (
                  <div className={styles.praticaComo}>
                    <p className={styles.praticaComoLabel}>Como praticar</p>
                    <p className={styles.praticaComoText}>{pr.como}</p>
                  </div>
                )}
                {pr.frequencia && <p className={styles.praticaFreq}>🗓️ {pr.frequencia}</p>}
              </div>
            ))}

            {/* Intenção */}
            {plan.intencao && (
              <div className={styles.intencaoCard + ' fade-up-3'}>
                <p className={styles.intencaoLabel}>Sua Intenção</p>
                <p className={styles.intencaoText}>"{plan.intencao}"</p>
              </div>
            )}

            <div className={styles.actions}>
              <button className={styles.btnSecondary} onClick={() => { setStep(2); setPlan(null); }}>← Ajustar seleção</button>
              <button className={styles.btnPrimary} onClick={restart}>Nova jornada</button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
