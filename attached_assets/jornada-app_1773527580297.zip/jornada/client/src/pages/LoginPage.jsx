import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import styles from './Auth.module.css';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const data = await api.login({ email, password });
      login(data.token, data.user);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={styles.page}>
      <div className={styles.card + ' fade-up'}>
        <h1 className={styles.logo}>Jornada</h1>
        <p className={styles.sub}>Entre para continuar sua transformação</p>
        {error && <div className={styles.error}>{error}</div>}
        <form onSubmit={handleSubmit} className={styles.form}>
          <label className={styles.label}>E-mail
            <input className={styles.input} type="email" value={email}
              onChange={e => setEmail(e.target.value)} required autoFocus />
          </label>
          <label className={styles.label}>Senha
            <input className={styles.input} type="password" value={password}
              onChange={e => setPassword(e.target.value)} required />
          </label>
          <button className={styles.btn} disabled={loading}>
            {loading ? 'Entrando…' : 'Entrar →'}
          </button>
        </form>
        <p className={styles.foot}>
          Ainda não tem conta? <Link to="/register">Criar conta</Link>
        </p>
      </div>
    </div>
  );
}
