require('dotenv').config();
const pool = require('./db');

async function setupDatabase() {
  const client = await pool.connect();
  try {
    console.log('🔧 Criando tabelas...');

    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id          SERIAL PRIMARY KEY,
        name        VARCHAR(100) NOT NULL,
        email       VARCHAR(255) UNIQUE NOT NULL,
        password    VARCHAR(255) NOT NULL,
        created_at  TIMESTAMP DEFAULT NOW()
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS sessions (
        id              SERIAL PRIMARY KEY,
        user_id         INTEGER REFERENCES users(id) ON DELETE CASCADE,
        adjetivos_atual TEXT[]  NOT NULL,
        adjetivos_futuro TEXT[] NOT NULL,
        created_at      TIMESTAMP DEFAULT NOW()
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS plans (
        id          SERIAL PRIMARY KEY,
        session_id  INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
        user_id     INTEGER REFERENCES users(id) ON DELETE CASCADE,
        sintese     TEXT,
        praticas    JSONB,
        intencao    TEXT,
        raw_response TEXT,
        created_at  TIMESTAMP DEFAULT NOW()
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS checkins (
        id          SERIAL PRIMARY KEY,
        user_id     INTEGER REFERENCES users(id) ON DELETE CASCADE,
        plan_id     INTEGER REFERENCES plans(id) ON DELETE CASCADE,
        nota        INTEGER CHECK (nota >= 1 AND nota <= 5),
        observacao  TEXT,
        created_at  TIMESTAMP DEFAULT NOW()
      );
    `);

    console.log('✅ Tabelas criadas com sucesso!');
    console.log('   - users');
    console.log('   - sessions');
    console.log('   - plans');
    console.log('   - checkins');
  } catch (err) {
    console.error('❌ Erro ao criar tabelas:', err.message);
    throw err;
  } finally {
    client.release();
    pool.end();
  }
}

setupDatabase();
