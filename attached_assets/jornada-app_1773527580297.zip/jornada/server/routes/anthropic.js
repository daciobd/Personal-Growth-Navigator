const express = require('express');
const auth = require('../middleware/auth');
const router = express.Router();

// POST /api/anthropic/generate
// Proxy seguro — a chave da API nunca vai ao frontend
router.post('/generate', auth, async (req, res) => {
  const { adjetivosAtual, adjetivosFuturo } = req.body;
  if (!adjetivosAtual?.length || !adjetivosFuturo?.length) {
    return res.status(400).json({ error: 'Adjetivos são obrigatórios' });
  }

  const prompt = `Você é um especialista em psicologia clínica integrativa, especializado em TCC (Terapia Cognitivo-Comportamental), ACT (Terapia de Aceitação e Compromisso), Psicologia Positiva e Mindfulness/DBT.

Um cliente completou uma avaliação de autoconhecimento:

COMO SE VÊ HOJE: ${adjetivosAtual.join(', ')}
COMO DESEJA SE TORNAR: ${adjetivosFuturo.join(', ')}

Crie um Plano de Intervenção Personalizado usando EXATAMENTE este formato:

SÍNTESE:
[2-3 frases acolhedoras que nomeiem os temas centrais desta jornada pessoal]

PRÁTICA 1:
Nome: [nome da técnica terapêutica]
Abordagem: [TCC ou ACT ou Psicologia Positiva ou Mindfulness/DBT]
Por que para você: [1-2 frases conectando ao perfil específico do cliente]
Como fazer: [3-4 passos numerados, concretos e em linguagem acessível]
Frequência: [sugestão prática]

PRÁTICA 2:
Nome: [técnica DIFERENTE da prática 1]
Abordagem: [abordagem DIFERENTE da prática 1]
Por que para você: [1-2 frases]
Como fazer: [3-4 passos numerados]
Frequência: [sugestão]

PRÁTICA 3:
Nome: [técnica DIFERENTE das anteriores]
Abordagem: [abordagem DIFERENTE das anteriores]
Por que para você: [1-2 frases]
Como fazer: [3-4 passos numerados]
Frequência: [sugestão]

INTENÇÃO:
[Uma frase poderosa na primeira pessoa, pessoal e inspiradora]

Responda inteiramente em português. Seja acolhedor, específico e prático.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('Erro da Anthropic API:', err);
      return res.status(502).json({ error: 'Erro ao contatar a IA. Tente novamente.' });
    }

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    res.json({ text });
  } catch (err) {
    console.error('Erro ao chamar Anthropic:', err.message);
    res.status(500).json({ error: 'Erro interno ao gerar plano' });
  }
});

module.exports = router;
