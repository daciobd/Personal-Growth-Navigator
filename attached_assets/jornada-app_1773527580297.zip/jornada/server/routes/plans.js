const express = require('express');
const pool = require('../db');
const auth = require('../middleware/auth');
const router = express.Router();

// POST /api/plans — salva sessão + plano gerado
router.post('/', auth, async (req, res) => {
  const { adjetivosAtual, adjetivosFuturo, sintese, praticas, intencao, rawResponse } = req.body;
  if (!adjetivosAtual?.length || !adjetivosFuturo?.length) {
    return res.status(400).json({ error: 'Adjetivos são obrigatórios' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const sessionResult = await client.query(
      'INSERT INTO sessions (user_id, adjetivos_atual, adjetivos_futuro) VALUES ($1, $2, $3) RETURNING id',
      [req.user.id, adjetivosAtual, adjetivosFuturo]
    );
    const sessionId = sessionResult.rows[0].id;
    const planResult = await client.query(
      `INSERT INTO plans (session_id, user_id, sintese, praticas, intencao, raw_response)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
      [sessionId, req.user.id, sintese, JSON.stringify(praticas), intencao, rawResponse]
    );
    await client.query('COMMIT');
    res.status(201).json({ planId: planResult.rows[0].id, sessionId });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Erro ao salvar plano:', err.message);
    res.status(500).json({ error: 'Erro ao salvar plano' });
  } finally {
    client.release();
  }
});

// GET /api/plans — histórico do usuário
router.get('/', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.id, p.sintese, p.praticas, p.intencao, p.created_at,
              s.adjetivos_atual, s.adjetivos_futuro
       FROM plans p
       JOIN sessions s ON s.id = p.session_id
       WHERE p.user_id = $1
       ORDER BY p.created_at DESC
       LIMIT 20`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar planos:', err.message);
    res.status(500).json({ error: 'Erro ao buscar histórico' });
  }
});

// GET /api/plans/:id — detalhes de um plano
router.get('/:id', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, s.adjetivos_atual, s.adjetivos_futuro
       FROM plans p JOIN sessions s ON s.id = p.session_id
       WHERE p.id = $1 AND p.user_id = $2`,
      [req.params.id, req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Plano não encontrado' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar plano' });
  }
});

// POST /api/plans/:id/checkin — registra check-in semanal
router.post('/:id/checkin', auth, async (req, res) => {
  const { nota, observacao } = req.body;
  if (!nota || nota < 1 || nota > 5) {
    return res.status(400).json({ error: 'Nota deve ser entre 1 e 5' });
  }
  try {
    await pool.query(
      'INSERT INTO checkins (user_id, plan_id, nota, observacao) VALUES ($1, $2, $3, $4)',
      [req.user.id, req.params.id, nota, observacao || null]
    );
    res.status(201).json({ message: 'Check-in registrado!' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao registrar check-in' });
  }
});

module.exports = router;
