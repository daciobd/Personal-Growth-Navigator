# MeuEu Admin — Guia de Instalação

## O que este pacote adiciona

Um painel de administração web (`artifacts/admin/`) com 4 abas:
- **Dashboard** — estatísticas de uso e top adjetivos selecionados
- **Histórico** — cada plano gerado, com adjetivos e práticas
- **Intervenções** — visualiza as intervenções pré-construídas do app
- **Testar IA** — gera planos de teste com Claude Haiku sem salvar no banco

---

## Arquivos e onde colocar cada um

### Novos arquivos (criar)

| Arquivo deste ZIP | Destino no projeto |
|---|---|
| `lib/db/src/schema/plan-logs.ts` | `lib/db/src/schema/plan-logs.ts` |
| `lib/db/src/schema/index.ts` | **Substitui** `lib/db/src/schema/index.ts` |
| `artifacts/api-server/src/routes/admin.ts` | `artifacts/api-server/src/routes/admin.ts` |
| `artifacts/api-server/src/routes/index.ts` | **Substitui** `artifacts/api-server/src/routes/index.ts` |
| `artifacts/api-server/src/routes/plan.ts` | **Substitui** `artifacts/api-server/src/routes/plan.ts` |
| `artifacts/admin/` (pasta inteira) | `artifacts/admin/` (nova pasta) |
| `migrations/0001_add_plan_logs.sql` | Executar no banco (ver abaixo) |

---

## Passo a passo

### 1. Copiar os arquivos (conforme tabela acima)

### 2. Criar a tabela no banco de dados

Opção A — Drizzle push (recomendado):
```bash
pnpm --filter @workspace/db db:push
```

Opção B — SQL manual (aba Database no Replit):
```sql
CREATE TABLE IF NOT EXISTS plan_logs (
  id               SERIAL PRIMARY KEY,
  current_adjectives TEXT[] NOT NULL,
  future_adjectives  TEXT[] NOT NULL,
  plan             JSONB,
  created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);
```

### 3. Instalar dependências do admin

```bash
pnpm install
```

### 4. Iniciar o admin

```bash
pnpm --filter @workspace/admin dev
```

O painel abre em uma URL separada do app Expo.

---

## Importante: import dos dados do Expo no api-server

O arquivo `admin.ts` importa de:
```typescript
import { INTERVENTIONS } from "../../meueu/data/interventions.js";
import { CURRENT_ADJECTIVES, FUTURE_ADJECTIVES, CATEGORIES } from "../../meueu/data/adjectives.js";
```

Isso assume que `artifacts/api-server/` e `artifacts/meueu/` estão no mesmo nível.
Se o Replit Agent tiver criado uma estrutura diferente, ajuste os caminhos relativos.

**Alternativa segura** — se os imports acima causarem erro de path,
peça ao Replit Agent para criar uma lib compartilhada:
```
lib/content/
  src/
    interventions.ts   (mova de artifacts/meueu/data/)
    adjectives.ts      (mova de artifacts/meueu/data/)
```

E importe de `@workspace/content` em ambos api-server e meueu.

---

## Proxy do Vite

O `vite.config.ts` do admin faz proxy de `/api` para `localhost:3000`.
Se o api-server rodar em outra porta, ajuste `API_SERVER_PORT`:
```bash
API_SERVER_PORT=3001 pnpm --filter @workspace/admin dev
```
