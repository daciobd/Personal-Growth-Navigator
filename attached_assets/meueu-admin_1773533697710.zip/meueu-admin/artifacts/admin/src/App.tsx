import React, { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  BarChart2, Clock, Layers, FlaskConical,
  TrendingUp, Users, Zap, BookOpen,
  ChevronDown, ChevronUp, RefreshCw, Play
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────
type Stats = {
  totalPlans: number;
  plansToday: number;
  plansThisWeek: number;
  interventionsCount: number;
  currentAdjectivesCount: number;
  futureAdjectivesCount: number;
  topCurrentAdjectives: { label: string; count: number }[];
  topFutureAdjectives:  { label: string; count: number }[];
};

type PlanLog = {
  id: number;
  currentAdjectives: string[];
  futureAdjectives: string[];
  plan: Record<string, unknown> | null;
  createdAt: string;
};

type Intervention = {
  id: string;
  therapy: string;
  title: string;
  description: string;
  steps: string[];
  duration: string;
  fromAdjectives: string[];
  toAdjectives: string[];
  icon: string;
};

// ── API helpers ───────────────────────────────────────────
async function apiFetch<T>(path: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(`/api/admin${path}`, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as { error?: string }).error ?? "Erro desconhecido");
  }
  return res.json() as Promise<T>;
}

// ── Color constants ───────────────────────────────────────
const C = {
  primary:  "#1B6B5A",
  accent:   "#E8A838",
  bg:       "#0F1A17",
  surface:  "#172219",
  border:   "#243028",
  text:     "#E8F0ED",
  muted:    "#6B8F7E",
  therapy: {
    TCC:                  { bg: "#1A2F4A", text: "#7BB3E8" },
    ACT:                  { bg: "#2A1F14", text: "#E8A838" },
    "Psicologia Positiva":{ bg: "#1A2F1A", text: "#7BDC8A" },
    Mindfulness:          { bg: "#2A1A2A", text: "#C87BE8" },
    "Terapia Narrativa":  { bg: "#2A2A14", text: "#E8E07B" },
    "Focada em Compaixão":{ bg: "#2A1A1A", text: "#E87B7B" },
  } as Record<string, { bg: string; text: string }>,
};

// ── Shared components ─────────────────────────────────────
function Spinner() {
  return (
    <div style={{ display: "flex", justifyContent: "center", padding: "48px" }}>
      <div style={{
        width: 32, height: 32,
        border: `3px solid ${C.border}`,
        borderTopColor: C.primary,
        borderRadius: "50%",
        animation: "spin 0.7s linear infinite",
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, accent }: {
  icon: React.FC<{ size?: number; color?: string }>;
  label: string;
  value: number | string;
  accent?: string;
}) {
  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`,
      borderRadius: 12, padding: "18px 20px",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <Icon size={16} color={accent ?? C.muted} />
        <span style={{ fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: ".08em", color: C.muted }}>
          {label}
        </span>
      </div>
      <span style={{ fontSize: 32, fontWeight: 700, color: accent ?? C.text }}>{value}</span>
    </div>
  );
}

function Chip({ label, small }: { label: string; small?: boolean }) {
  return (
    <span style={{
      display: "inline-block",
      padding: small ? "2px 8px" : "4px 10px",
      borderRadius: 20,
      background: "#1A2D27",
      color: "#7DC4A8",
      fontSize: small ? 10 : 11,
      fontWeight: 600,
      marginRight: 4,
      marginBottom: 4,
    }}>{label}</span>
  );
}

function TherapyBadge({ therapy }: { therapy: string }) {
  const style = C.therapy[therapy] ?? { bg: "#222", text: "#AAA" };
  return (
    <span style={{
      padding: "3px 10px", borderRadius: 20, fontSize: 10,
      fontWeight: 700, textTransform: "uppercase", letterSpacing: ".06em",
      background: style.bg, color: style.text,
    }}>{therapy}</span>
  );
}

// ── Tab: Dashboard ────────────────────────────────────────
function TabDashboard() {
  const { data: stats, isLoading, error, refetch } = useQuery<Stats>({
    queryKey: ["admin-stats"],
    queryFn: () => apiFetch<Stats>("/stats"),
  });

  if (isLoading) return <Spinner />;
  if (error || !stats) return (
    <p style={{ color: "#E87B7B", padding: 24 }}>
      Erro ao carregar estatísticas. Certifique-se que o api-server está rodando.
    </p>
  );

  const maxCurrent = Math.max(...stats.topCurrentAdjectives.map(a => a.count), 1);
  const maxFuture  = Math.max(...stats.topFutureAdjectives.map(a => a.count), 1);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <button onClick={() => refetch()} style={{
          display: "flex", alignItems: "center", gap: 6,
          background: "transparent", border: `1px solid ${C.border}`,
          borderRadius: 8, padding: "7px 14px", color: C.muted,
          fontSize: 12, cursor: "pointer",
        }}>
          <RefreshCw size={13} />
          Atualizar
        </button>
      </div>

      {/* Stats grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 12 }}>
        <StatCard icon={Zap}    label="Planos gerados"    value={stats.totalPlans}             accent={C.primary} />
        <StatCard icon={Clock}  label="Hoje"              value={stats.plansToday}              accent={C.accent} />
        <StatCard icon={TrendingUp} label="Esta semana"   value={stats.plansThisWeek} />
        <StatCard icon={Layers} label="Intervenções"      value={stats.interventionsCount} />
        <StatCard icon={Users}  label="Adjetivos (atual)" value={stats.currentAdjectivesCount} />
        <StatCard icon={BookOpen} label="Adjetivos (futuro)" value={stats.futureAdjectivesCount} />
      </div>

      {/* Top adjectives */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {[
          { title: "Eu Hoje — mais selecionados", data: stats.topCurrentAdjectives, max: maxCurrent },
          { title: "Eu Futuro — mais desejados",  data: stats.topFutureAdjectives,  max: maxFuture },
        ].map(({ title, data, max }) => (
          <div key={title} style={{
            background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "18px 20px",
          }}>
            <p style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", color: C.muted, marginBottom: 16 }}>
              {title}
            </p>
            {data.map(({ label, count }) => (
              <div key={label} style={{ marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 13, color: C.text }}>{label}</span>
                  <span style={{ fontSize: 12, color: C.muted }}>{count}</span>
                </div>
                <div style={{ height: 4, background: C.border, borderRadius: 2, overflow: "hidden" }}>
                  <div style={{
                    height: "100%", borderRadius: 2,
                    width: `${(count / max) * 100}%`,
                    background: C.primary,
                    transition: "width .4s ease",
                  }} />
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Tab: Histórico ────────────────────────────────────────
function TabHistorico() {
  const [expanded, setExpanded] = useState<number | null>(null);
  const { data, isLoading, error } = useQuery<{ logs: PlanLog[]; total: number }>({
    queryKey: ["admin-plan-logs"],
    queryFn: () => apiFetch<{ logs: PlanLog[]; total: number }>("/plan-logs?limit=30"),
  });

  if (isLoading) return <Spinner />;
  if (error || !data) return <p style={{ color: "#E87B7B", padding: 24 }}>Erro ao carregar histórico.</p>;

  const { logs, total } = data;

  return (
    <div>
      <p style={{ fontSize: 12, color: C.muted, marginBottom: 16 }}>
        {total} planos gerados no total · exibindo os 30 mais recentes
      </p>
      {logs.length === 0 && (
        <div style={{
          textAlign: "center", padding: 48,
          background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12,
        }}>
          <p style={{ color: C.muted }}>Nenhum plano gerado ainda.</p>
          <p style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>
            Os planos aparecerão aqui assim que usuários completarem o onboarding.
          </p>
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {logs.map(log => {
          const isOpen = expanded === log.id;
          const plan = log.plan as Record<string, unknown> | null;
          return (
            <div key={log.id} style={{
              background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12,
              overflow: "hidden",
            }}>
              <button
                onClick={() => setExpanded(isOpen ? null : log.id)}
                style={{
                  width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "14px 18px", background: "transparent", border: "none", cursor: "pointer",
                  color: C.text, textAlign: "left",
                }}
              >
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start", flex: 1 }}>
                  <div>
                    <p style={{ fontSize: 11, color: C.muted, marginBottom: 6 }}>
                      #{log.id} · {new Date(log.createdAt).toLocaleString("pt-BR")}
                    </p>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                      {log.currentAdjectives.slice(0, 5).map(a => (
                        <span key={a} style={{
                          padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 600,
                          background: "#1A2420", color: "#6B8F7E",
                        }}>{a}</span>
                      ))}
                      <span style={{ color: C.muted, fontSize: 11, alignSelf: "center" }}>→</span>
                      {log.futureAdjectives.slice(0, 5).map(a => (
                        <span key={a} style={{
                          padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 600,
                          background: "#1A2D1A", color: "#7BDC8A",
                        }}>{a}</span>
                      ))}
                    </div>
                  </div>
                </div>
                {isOpen ? <ChevronUp size={16} color={C.muted} /> : <ChevronDown size={16} color={C.muted} />}
              </button>

              {isOpen && plan && !("parseError" in plan) && (
                <div style={{ padding: "0 18px 18px", borderTop: `1px solid ${C.border}` }}>
                  {typeof plan.sintese === "string" && (
                    <p style={{ fontSize: 13, color: "#A8C8BC", lineHeight: 1.7, margin: "14px 0 12px" }}>
                      {plan.sintese}
                    </p>
                  )}
                  {typeof plan.fraseIntencao === "string" && (
                    <p style={{
                      fontSize: 13, color: C.accent, fontStyle: "italic",
                      borderLeft: `2px solid ${C.accent}`, paddingLeft: 12, marginBottom: 14,
                    }}>
                      "{plan.fraseIntencao}"
                    </p>
                  )}
                  {Array.isArray(plan.praticas) && plan.praticas.map((p: Record<string, unknown>, i: number) => (
                    <div key={i} style={{
                      background: C.bg, borderRadius: 8, padding: "12px 14px", marginBottom: 8,
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                        <TherapyBadge therapy={String(p.abordagem ?? "")} />
                        <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{String(p.nome ?? "")}</span>
                      </div>
                      <p style={{ fontSize: 12, color: C.muted }}>{String(p.justificativa ?? "")}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Tab: Intervenções ─────────────────────────────────────
function TabIntervencoes() {
  const [filter, setFilter] = useState("Todas");
  const [expanded, setExpanded] = useState<string | null>(null);

  const { data, isLoading, error } = useQuery<{ interventions: Intervention[]; therapies: string[] }>({
    queryKey: ["admin-interventions"],
    queryFn: () => apiFetch<{ interventions: Intervention[]; therapies: string[] }>("/interventions"),
  });

  if (isLoading) return <Spinner />;
  if (error || !data) return <p style={{ color: "#E87B7B", padding: 24 }}>Erro ao carregar intervenções.</p>;

  const { interventions, therapies } = data;
  const filtered = filter === "Todas" ? interventions : interventions.filter(i => i.therapy === filter);

  return (
    <div>
      {/* Filter tabs */}
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 20 }}>
        {["Todas", ...therapies].map(t => (
          <button key={t} onClick={() => setFilter(t)} style={{
            padding: "6px 14px", borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: "pointer",
            border: `1px solid ${filter === t ? C.primary : C.border}`,
            background: filter === t ? "#1A2D27" : "transparent",
            color: filter === t ? "#7DC4A8" : C.muted,
          }}>{t}</button>
        ))}
      </div>

      <p style={{ fontSize: 12, color: C.muted, marginBottom: 14 }}>
        {filtered.length} intervenção{filtered.length !== 1 ? "ções" : ""} · edite em{" "}
        <code style={{ background: C.surface, padding: "1px 6px", borderRadius: 4, fontSize: 11 }}>
          artifacts/meueu/data/interventions.ts
        </code>
      </p>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {filtered.map(inv => {
          const isOpen = expanded === inv.id;
          return (
            <div key={inv.id} style={{
              background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, overflow: "hidden",
            }}>
              <button onClick={() => setExpanded(isOpen ? null : inv.id)} style={{
                width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "14px 18px", background: "transparent", border: "none", cursor: "pointer",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <TherapyBadge therapy={inv.therapy} />
                  <span style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{inv.title}</span>
                  <span style={{ fontSize: 11, color: C.muted }}>{inv.duration}</span>
                </div>
                {isOpen ? <ChevronUp size={16} color={C.muted} /> : <ChevronDown size={16} color={C.muted} />}
              </button>

              {isOpen && (
                <div style={{ padding: "0 18px 18px", borderTop: `1px solid ${C.border}` }}>
                  <p style={{ fontSize: 13, color: "#A8C8BC", lineHeight: 1.7, margin: "12px 0" }}>
                    {inv.description}
                  </p>
                  <div style={{ display: "flex", gap: 16, marginBottom: 14, flexWrap: "wrap" }}>
                    <div>
                      <p style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", color: C.muted, marginBottom: 6 }}>De</p>
                      <div>{inv.fromAdjectives.map(a => <Chip key={a} label={a} small />)}</div>
                    </div>
                    <div>
                      <p style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", color: "#5A8A6A", marginBottom: 6 }}>Para</p>
                      <div>{inv.toAdjectives.map(a => <Chip key={a} label={a} small />)}</div>
                    </div>
                  </div>
                  <ol style={{ paddingLeft: 18, display: "flex", flexDirection: "column", gap: 6 }}>
                    {inv.steps.map((step, i) => (
                      <li key={i} style={{ fontSize: 13, color: C.muted, lineHeight: 1.6 }}>{step}</li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Tab: Testar IA ────────────────────────────────────────
function TabTestarIA() {
  const [currentInput, setCurrentInput] = useState("ansioso, inseguro, procrastinador");
  const [futureInput,  setFutureInput]  = useState("calmo, confiante, focado");
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [tokens, setTokens] = useState<Record<string, number> | null>(null);
  const [elapsed, setElapsed] = useState<number | null>(null);

  const mutation = useMutation({
    mutationFn: async () => {
      const currentAdjectives = currentInput.split(",").map(s => s.trim()).filter(Boolean);
      const futureAdjectives  = futureInput.split(",").map(s => s.trim()).filter(Boolean);
      const t0 = performance.now();
      const res = await apiFetch<{ success: boolean; plan: Record<string, unknown>; tokensUsed: Record<string, number> }>(
        "/test-generate",
        { method: "POST", body: JSON.stringify({ currentAdjectives, futureAdjectives }) }
      );
      setElapsed(Math.round(performance.now() - t0));
      return res;
    },
    onSuccess: (data) => {
      setResult(data.plan);
      setTokens(data.tokensUsed);
    },
  });

  const plan = result;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20, alignItems: "start" }}>
      {/* Controls */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "20px" }}>
        <p style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", color: C.muted, marginBottom: 14 }}>
          Configurar teste
        </p>

        <label style={{ display: "block", marginBottom: 14 }}>
          <p style={{ fontSize: 12, fontWeight: 600, color: C.muted, marginBottom: 6 }}>Eu Hoje (separados por vírgula)</p>
          <textarea
            value={currentInput}
            onChange={e => setCurrentInput(e.target.value)}
            rows={3}
            style={{
              width: "100%", background: C.bg, border: `1px solid ${C.border}`,
              borderRadius: 8, padding: "8px 12px", color: C.text, fontSize: 13,
              fontFamily: "Inter, sans-serif", resize: "vertical", outline: "none",
            }}
          />
        </label>

        <label style={{ display: "block", marginBottom: 20 }}>
          <p style={{ fontSize: 12, fontWeight: 600, color: "#5A8A6A", marginBottom: 6 }}>Eu Futuro (separados por vírgula)</p>
          <textarea
            value={futureInput}
            onChange={e => setFutureInput(e.target.value)}
            rows={3}
            style={{
              width: "100%", background: C.bg, border: `1px solid ${C.border}`,
              borderRadius: 8, padding: "8px 12px", color: C.text, fontSize: 13,
              fontFamily: "Inter, sans-serif", resize: "vertical", outline: "none",
            }}
          />
        </label>

        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending}
          style={{
            width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            background: C.primary, color: "#fff", border: "none", borderRadius: 50,
            padding: "12px 0", fontSize: 14, fontWeight: 700, cursor: "pointer",
            opacity: mutation.isPending ? 0.7 : 1,
          }}
        >
          {mutation.isPending ? <><RefreshCw size={14} style={{ animation: "spin .7s linear infinite" }} /> Gerando…</> : <><Play size={14} /> Gerar plano</>}
        </button>

        {mutation.isError && (
          <p style={{ fontSize: 12, color: "#E87B7B", marginTop: 10 }}>
            {(mutation.error as Error).message}
          </p>
        )}

        {tokens && elapsed && (
          <div style={{ marginTop: 14, padding: "10px 12px", background: C.bg, borderRadius: 8 }}>
            <p style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>Tokens usados</p>
            <p style={{ fontSize: 12, color: C.text }}>
              Input: {tokens.input_tokens} · Output: {tokens.output_tokens} · {elapsed}ms
            </p>
          </div>
        )}
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>

      {/* Result */}
      <div>
        {!plan && !mutation.isPending && (
          <div style={{
            textAlign: "center", padding: 48,
            background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12,
          }}>
            <FlaskConical size={32} color={C.muted} style={{ marginBottom: 12 }} />
            <p style={{ color: C.muted }}>Configure os adjetivos e clique em "Gerar plano"</p>
            <p style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>
              Este teste usa Claude Haiku mas não salva o resultado no banco.
            </p>
          </div>
        )}

        {mutation.isPending && <Spinner />}

        {plan && !mutation.isPending && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {/* Síntese */}
            {typeof plan.sintese === "string" && (
              <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "18px 20px" }}>
                <p style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", color: C.muted, marginBottom: 10 }}>Síntese</p>
                <p style={{ fontSize: 14, color: "#A8C8BC", lineHeight: 1.75 }}>{plan.sintese}</p>
              </div>
            )}

            {/* Frase de intenção */}
            {typeof plan.fraseIntencao === "string" && (
              <div style={{
                border: `1px solid ${C.accent}`, borderRadius: 12, padding: "16px 20px",
                background: "#1A1600",
              }}>
                <p style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", color: C.accent, marginBottom: 8 }}>Intenção</p>
                <p style={{ fontSize: 15, color: C.accent, fontStyle: "italic", lineHeight: 1.6 }}>
                  "{plan.fraseIntencao}"
                </p>
              </div>
            )}

            {/* Práticas */}
            {Array.isArray(plan.praticas) && plan.praticas.map((p: Record<string, unknown>, i: number) => (
              <div key={i} style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "18px 20px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.muted }}>Prática {i + 1}</span>
                  <TherapyBadge therapy={String(p.abordagem ?? "")} />
                  <span style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{String(p.nome ?? "")}</span>
                </div>
                <p style={{ fontSize: 13, color: "#7DC4A8", fontStyle: "italic", marginBottom: 12, lineHeight: 1.6 }}>
                  {String(p.justificativa ?? "")}
                </p>
                <ol style={{ paddingLeft: 18, display: "flex", flexDirection: "column", gap: 6 }}>
                  {Array.isArray(p.passos) && p.passos.map((step: unknown, j: number) => (
                    <li key={j} style={{ fontSize: 13, color: C.muted, lineHeight: 1.6 }}>{String(step)}</li>
                  ))}
                </ol>
                {typeof p.frequencia === "string" && (
                  <p style={{ fontSize: 12, color: C.accent, marginTop: 10 }}>
                    📅 {p.frequencia}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────
const TABS = [
  { key: "dashboard",    label: "Dashboard",    icon: BarChart2 },
  { key: "historico",    label: "Histórico",    icon: Clock },
  { key: "intervencoes", label: "Intervenções", icon: Layers },
  { key: "testar",       label: "Testar IA",    icon: FlaskConical },
] as const;

type TabKey = typeof TABS[number]["key"];

export default function App() {
  const [tab, setTab] = useState<TabKey>("dashboard");

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      {/* Sidebar */}
      <aside style={{
        width: 220, minHeight: "100vh",
        background: "#0A1310",
        borderRight: `1px solid ${C.border}`,
        display: "flex", flexDirection: "column",
        padding: "28px 0 24px", flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{ padding: "0 20px 24px", borderBottom: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10,
              background: C.primary,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16, fontWeight: 700, color: "#C8F0E0",
              fontFamily: "Georgia, serif", fontStyle: "italic",
            }}>M</div>
            <div>
              <p style={{ fontSize: 14, fontWeight: 700, color: C.text }}>MeuEu</p>
              <p style={{ fontSize: 10, color: C.muted, fontWeight: 600, textTransform: "uppercase", letterSpacing: ".08em" }}>Admin</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "16px 10px", display: "flex", flexDirection: "column", gap: 2 }}>
          {TABS.map(t => {
            const Icon = t.icon;
            const active = tab === t.key;
            return (
              <button key={t.key} onClick={() => setTab(t.key)} style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "9px 12px", borderRadius: 8, width: "100%",
                background: active ? "#1A2D27" : "transparent",
                border: "none", cursor: "pointer",
                color: active ? "#7DC4A8" : C.muted,
                fontSize: 13, fontWeight: 500, fontFamily: "Inter, sans-serif",
              }}>
                <Icon size={15} />
                {t.label}
              </button>
            );
          })}
        </nav>

        <div style={{ padding: "12px 20px", borderTop: `1px solid ${C.border}` }}>
          <p style={{ fontSize: 11, color: C.muted }}>api: /api/admin/*</p>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0, overflow: "auto" }}>
        <div style={{ padding: "28px 32px 0", borderBottom: `1px solid ${C.border}`, marginBottom: 28 }}>
          <h2 style={{
            fontFamily: "Georgia, serif", fontSize: 28, fontWeight: 400,
            color: C.text, paddingBottom: 20,
          }}>
            {TABS.find(t => t.key === tab)?.label}
          </h2>
        </div>

        <div style={{ padding: "0 32px 60px" }}>
          {tab === "dashboard"    && <TabDashboard />}
          {tab === "historico"    && <TabHistorico />}
          {tab === "intervencoes" && <TabIntervencoes />}
          {tab === "testar"       && <TabTestarIA />}
        </div>
      </main>
    </div>
  );
}
