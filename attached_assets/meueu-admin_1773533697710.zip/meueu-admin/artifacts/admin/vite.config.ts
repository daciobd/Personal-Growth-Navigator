import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// O api-server roda na porta definida pelo Replit.
// Ajuste API_SERVER_PORT se necessário.
const API_SERVER_PORT = process.env.API_SERVER_PORT || 3000;

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      "/api": {
        target: `http://localhost:${API_SERVER_PORT}`,
        changeOrigin: true,
      },
    },
  },
});
