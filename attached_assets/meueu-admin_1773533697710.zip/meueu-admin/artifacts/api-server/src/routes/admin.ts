// artifacts/api-server/src/routes/admin.ts
//
// Rotas do painel de administração.
// Prefixo: /api/admin
//
// GET  /api/admin/stats                    — estatísticas gerais
// GET  /api/admin/plan-logs                — histórico de planos gerados
// GET  /api/admin/interventions            — lista intervenções do app
// GET  /api/admin/adjectives               — lista adjetivos do app
// POST /api/admin/test-generate            — testa geração de plano (sem salvar)

import { Router } from "express";
import { db } from "@workspace/db";
import { planLogsTable } from "@workspace/db/schema";
import { desc, count, sql } from "drizzle-orm";
import { anthropic } from "@workspace/integrations-anthropic-ai";

// Import static data from meueu app
// Note: these are read-only via the admin API.
// To edit them, use the Replit editor directly on the .ts files.
import { INTERVENTIONS } from "../../meueu/data/interventions.js";
import { CURRENT_ADJECTIVES, FUTURE_ADJECTIVES, CATEGORIES } from "../../meueu/data/adjectives.js";

const router = Router();

// ── Stats ─────────────────────────────────────────────────
router.get("/stats", async (_req, res) => {
  try {
    const [totalPlans] = await db
      .select({ count: count() })
      .from(planLogsTable);

    const [plansToday] = await db
      .select({ count: count() })
      .from(planLogsTable)
      .where(sql`DATE(created_at) = CURRENT_DATE`);

    const [plansThisWeek] = await db
      .select({ count: count() })
      .from(planLogsTable)
      .where(sql`created_at >= NOW() - INTERVAL '7 days'`);

    // Top adjetivos atuais mais usados
    const recentLogs = await db
      .select({ currentAdjectives: planLogsTable.currentAdjectives })
      .from(planLogsTable)
      .orderBy(desc(planLogsTable.createdAt))
      .limit(200);

    const adjCount: Record<string, number> = {};
    for (const log of recentLogs) {
      for (const adj of log.currentAdjectives) {
        adjCount[adj] = (adjCount[adj] || 0) + 1;
      }
    }
    const topCurrentAdjectives = Object.entries(adjCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([label, count]) => ({ label, count }));

    const futureAdjCount: Record<string, number> = {};
    const recentFutureLogs = await db
      .select({ futureAdjectives: planLogsTable.futureAdjectives })
      .from(planLogsTable)
      .orderBy(desc(planLogsTable.createdAt))
      .limit(200);

    for (const log of recentFutureLogs) {
      for (const adj of log.futureAdjectives) {
        futureAdjCount[adj] = (futureAdjCount[adj] || 0) + 1;
      }
    }
    const topFutureAdjectives = Object.entries(futureAdjCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([label, count]) => ({ label, count }));

    res.json({
      totalPlans: totalPlans.count,
      plansToday: plansToday.count,
      plansThisWeek: plansThisWeek.count,
      interventionsCount: INTERVENTIONS.length,
      currentAdjectivesCount: CURRENT_ADJECTIVES.length,
      futureAdjectivesCount: FUTURE_ADJECTIVES.length,
      topCurrentAdjectives,
      topFutureAdjectives,
    });
  } catch (err) {
    console.error("Admin stats error:", err);
    res.status(500).json({ error: "Erro ao carregar estatísticas" });
  }
});

// ── Plan Logs ─────────────────────────────────────────────
router.get("/plan-logs", async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const offset = parseInt(req.query.offset as string) || 0;

    const logs = await db
      .select()
      .from(planLogsTable)
      .orderBy(desc(planLogsTable.createdAt))
      .limit(limit)
      .offset(offset);

    const [{ count: total }] = await db
      .select({ count: count() })
      .from(planLogsTable);

    res.json({ logs, total, limit, offset });
  } catch (err) {
    console.error("Admin plan-logs error:", err);
    res.status(500).json({ error: "Erro ao carregar logs" });
  }
});

// ── Interventions (read-only) ─────────────────────────────
router.get("/interventions", (_req, res) => {
  res.json({
    interventions: INTERVENTIONS,
    count: INTERVENTIONS.length,
    therapies: [...new Set(INTERVENTIONS.map(i => i.therapy))],
  });
});

// ── Adjectives (read-only) ────────────────────────────────
router.get("/adjectives", (_req, res) => {
  res.json({
    categories: CATEGORIES,
    currentAdjectives: CURRENT_ADJECTIVES,
    futureAdjectives: FUTURE_ADJECTIVES,
    currentCount: CURRENT_ADJECTIVES.length,
    futureCount: FUTURE_ADJECTIVES.length,
  });
});

// ── Test Generate (não salva no banco) ───────────────────
router.post("/test-generate", async (req, res) => {
  const { currentAdjectives, futureAdjectives } = req.body as {
    currentAdjectives: string[];
    futureAdjectives: string[];
  };

  if (!Array.isArray(currentAdjectives) || !Array.isArray(futureAdjectives)) {
    res.status(400).json({ error: "currentAdjectives e futureAdjectives são obrigatórios" });
    return;
  }

  const prompt = `Você é um psicólogo especializado em psicoterapias baseadas em evidências (TCC, ACT, Psicologia Positiva).

EU HOJE: ${currentAdjectives.join(", ")}
EU FUTURO: ${futureAdjectives.join(", ")}

Gere um plano em JSON:
{
  "sintese": "2-3 frases empáticas sobre a jornada",
  "fraseIntencao": "Frase começando com 'Eu escolho...'",
  "praticas": [
    { "abordagem": "TCC", "nome": "...", "justificativa": "...", "passos": ["...","...","...","..."], "frequencia": "..." },
    { "abordagem": "ACT", "nome": "...", "justificativa": "...", "passos": ["...","...","...","..."], "frequencia": "..." },
    { "abordagem": "Psicologia Positiva", "nome": "...", "justificativa": "...", "passos": ["...","...","...","..."], "frequencia": "..." }
  ]
}

Responda APENAS com o JSON válido.`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 2048,
      messages: [{ role: "user", content: prompt }],
    });

    const rawText = message.content[0].type === "text" ? message.content[0].text : "";
    const jsonMatch = rawText.match(/\{[\s\S]*\}/);
    const plan = jsonMatch ? JSON.parse(jsonMatch[0]) : { rawText, parseError: true };

    res.json({ success: true, plan, tokensUsed: message.usage });
  } catch (error) {
    console.error("Admin test-generate error:", error);
    res.status(500).json({ error: "Erro ao gerar plano de teste" });
  }
});

export default router;
