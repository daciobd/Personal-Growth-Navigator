// lib/db/src/schema/index.ts
// Exporta todos os schemas do banco de dados.

export * from "./plan-logs";

// Adicione novos schemas aqui à medida que o app crescer:
// export * from "./users";
// export * from "./interventions";
