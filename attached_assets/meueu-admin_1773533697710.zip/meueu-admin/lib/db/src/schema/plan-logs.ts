// lib/db/src/schema/plan-logs.ts
//
// Tabela para registrar cada plano gerado pela IA.
// Permite ao admin ver estatísticas de uso e os adjetivos mais selecionados.

import { pgTable, serial, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const planLogsTable = pgTable("plan_logs", {
  id: serial("id").primaryKey(),
  currentAdjectives: text("current_adjectives").array().notNull(),
  futureAdjectives:  text("future_adjectives").array().notNull(),
  plan:              jsonb("plan"),
  createdAt:         timestamp("created_at").defaultNow().notNull(),
});

export const insertPlanLogSchema = createInsertSchema(planLogsTable).omit({ id: true, createdAt: true });
export type InsertPlanLog = z.infer<typeof insertPlanLogSchema>;
export type PlanLog = typeof planLogsTable.$inferSelect;
