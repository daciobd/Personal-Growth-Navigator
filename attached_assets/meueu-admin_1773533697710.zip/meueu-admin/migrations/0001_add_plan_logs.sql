-- migrations/0001_add_plan_logs.sql
-- Execute no banco de dados PostgreSQL do Replit para criar a tabela de logs.
--
-- Método 1 (recomendado): rode no Shell do Replit:
--   pnpm --filter @workspace/db db:push
--
-- Método 2 (manual): abra a aba "Database" no Replit e cole este SQL:

CREATE TABLE IF NOT EXISTS plan_logs (
  id               SERIAL PRIMARY KEY,
  current_adjectives TEXT[]    NOT NULL,
  future_adjectives  TEXT[]    NOT NULL,
  plan             JSONB,
  created_at       TIMESTAMP  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS plan_logs_created_at_idx ON plan_logs (created_at DESC);
