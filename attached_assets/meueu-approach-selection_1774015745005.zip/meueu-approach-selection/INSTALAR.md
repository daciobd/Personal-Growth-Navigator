# Seleção de Abordagem pelo Usuário

## O que este pacote adiciona

Após ver o plano gerado, o usuário escolhe qual das 3 perspectivas fez mais sentido.
A escolha é salva e usada em todos os prompts futuros (coach, check-in, jornadas).
Após 30 dias, o app sugere reavaliação — mas não força.

## Fluxo

```
Plano gerado
     ↓
"Qual perspectiva fez mais sentido pra você?"
[TCC] [ACT] [Psicologia Positiva]
     ↓
Usuário escolhe → salva em @meueu_preferred_approach
     ↓
Coach, check-in e jornadas passam a usar essa abordagem
     ↓
(30 dias depois) → "Ainda faz sentido essa abordagem?"
```

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `components/ApproachSelector.tsx` | `artifacts/meueu/components/` | Criar |
| `hooks/usePreferredApproach.ts` | `artifacts/meueu/hooks/` | Criar |
| `routes/coach.ts` | `artifacts/api-server/src/routes/` | Substituir |

## Integração em `onboarding/plan.tsx`

Após exibir as 3 práticas, adicione o seletor:

```tsx
import ApproachSelector, { type ApproachOption } from '../../components/ApproachSelector';

// Converte as práticas do plano em opções
const approachOptions: ApproachOption[] = plan.praticas.map((p, i) => ({
  key: p.abordagem.toLowerCase().replace(/\s+/g, '-'),
  label: p.abordagem,
  emoji: ['🔵', '🟢', '🟡'][i] ?? '⚪',
  title: p.nome,
  description: p.justificativa.slice(0, 80) + '...',
  color: ['#3A5A8C', '#1B6B5A', '#E8A838'][i] ?? '#6B8F7E',
  bgColor: ['#EDF2FB', '#E8F5F1', '#FFF8EC'][i] ?? '#F5F8F6',
}));

// No JSX, após as práticas:
{!approachSelected && (
  <ApproachSelector
    options={approachOptions}
    onSelect={(key) => setApproachSelected(key)}
  />
)}
```

Adicione `const [approachSelected, setApproachSelected] = useState<string | null>(null)`.

## Integração no Coach

Em `artifacts/meueu/app/coach/index.tsx`, ao chamar a API:

```tsx
import { usePreferredApproach } from '../../hooks/usePreferredApproach';
const { preferred } = usePreferredApproach();

// Na chamada à API:
body: JSON.stringify({
  message,
  history,
  preferredApproach: preferred?.key,
  practiceName,
})
```

## Integração no daily challenge / check-in

Em `daily.ts` e `journeys.ts`, adicione ao body da requisição:
```typescript
preferredApproach: req.body.preferredApproach
```

E ao prompt do Claude:
```typescript
const approachInstruction = preferredApproach
  ? APPROACH_INSTRUCTIONS[preferredApproach] ?? ''
  : '';
// Adicione ao prompt antes do fechamento
```

## Mudança de abordagem pelo usuário

O usuário pode mudar dizendo ao coach:
- "Quero tentar uma abordagem diferente"
- "Isso não está funcionando pra mim"
- "Me fala de outro jeito"

O coach responde mudando a perspectiva e pode perguntar qual das abordagens quer tentar.
O frontend pode mostrar um botão "Mudar abordagem" na tab Perfil que chama `clearPreference()`.

## Reavaliação após 30 dias

`usePreferredApproach` retorna `shouldSuggestReview: true` após 30 dias.
Use para mostrar um card sutil: "Faz 30 dias que você está com a abordagem TCC. Ainda faz sentido?"
Com botão "Sim, continuar" e "Quero explorar outras".
