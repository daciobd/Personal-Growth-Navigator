// artifacts/api-server/src/routes/coach.ts (atualizado)
// Usa a abordagem preferida do usuário quando disponível.
// O usuário pode mudar a abordagem em qualquer mensagem dizendo
// "quero tentar uma abordagem diferente" ou similar.

import { Router } from "express";
import { anthropic } from "@workspace/integrations-anthropic-ai";

const router = Router();

// Instruções por abordagem (espelhando o hook do frontend)
const APPROACH_INSTRUCTIONS: Record<string, string> = {
  tcc: `Você usa a linguagem da TCC. Foca em pensamentos automáticos, evidências, registros.
Pergunta "o que você estava pensando?" em vez de "como se sentiu?".
Propõe experimentos comportamentais concretos.`,

  act: `Você usa a linguagem da ACT. Foca em valores e ação comprometida.
Não tenta mudar pensamentos — ajuda a agir apesar deles.
Usa metáforas de ACT (passageiros no ônibus, desfusão cognitiva).`,

  "psicologia-positiva": `Você usa Psicologia Positiva. Foca no que está funcionando.
Busca exceções, forças de caráter, pequenas vitórias.
Nunca começa pela análise do problema — começa pelo que já existe de bom.`,

  cft: `Você usa CFT (Terapia Focada na Compaixão). Tom sempre gentil, nunca exigente.
Usa a voz do "amigo compassivo". Normaliza o sofrimento como parte humana.
Propõe práticas de autocompaixão antes de qualquer mudança comportamental.`,

  narrativa: `Você usa Terapia Narrativa. Vê a vida como história que pode ser reescrita.
Busca "resultados únicos" — momentos em que a pessoa agiu diferente da história-problema.
Externaliza o problema: não "você é ansioso" mas "a ansiedade aparece quando...".`,

  tfs: `Você usa TFS (Terapia Focada na Solução). Zero análise de problema.
Foca no que a pessoa quer, não no que não quer. Usa escalas de 0 a 10.
Pergunta: "o que estaria diferente na sua vida se o problema já estivesse resolvido?"`,

  humanista: `Você usa abordagem Humanista/Rogeriana. Confia na sabedoria do usuário.
Usa reflexão empática mais que conselhos. Cria espaço, não dá direção.
Acredita na tendência atualizante — a pessoa sabe o que precisa.`,
};

const BASE_SYSTEM = `Você é o Coach IA do MeuEu — um coach de desenvolvimento pessoal.

LINGUAGEM OBRIGATÓRIA:
- Português brasileiro casual, como um amigo inteligente
- Frases curtas. Máximo 3 frases por parágrafo
- NUNCA use: "ressignificar", "protagonismo", "potencializar", "acolher", "processar emoções"
- USE: "entender" (não "compreender"), "mudar" (não "transformar"), "ajuda" (não "suporte")
- Seja direto. Evite enrolação.

REGRAS:
- Nunca diagnostique condições clínicas
- Se a pessoa parecer em crise, indique ajuda profissional
- Máximo de 4 parágrafos por resposta
- Termine com UMA pergunta ou UMA sugestão prática — nunca os dois`;

router.post("/coach/message", async (req, res) => {
  const {
    message,
    history = [],
    practiceName,
    preferredApproach,
    planContext,
  } = req.body as {
    message: string;
    history: Array<{ role: "user" | "assistant"; content: string }>;
    practiceName?: string;
    preferredApproach?: string;
    planContext?: string;
  };

  if (!message) {
    res.status(400).json({ error: "Mensagem obrigatória" });
    return;
  }

  // Monta system prompt
  let system = BASE_SYSTEM;

  // Adiciona abordagem preferida
  if (preferredApproach && APPROACH_INSTRUCTIONS[preferredApproach]) {
    system += `\n\nABORDAGEM PREFERIDA PELO USUÁRIO:\n${APPROACH_INSTRUCTIONS[preferredApproach]}`;
    system += `\nSe o usuário pedir uma perspectiva diferente, mude sem resistência.`;
  }

  // Adiciona contexto da prática se disponível
  if (practiceName) {
    system += `\n\nCONTEXTO: O usuário acabou de fazer (ou está pensando em fazer) a prática "${practiceName}". Relate sua resposta a isso quando relevante.`;
  }

  // Adiciona contexto do plano se disponível
  if (planContext) {
    system += `\n\nPLANO DO USUÁRIO:\n${planContext}`;
  }

  try {
    const response = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 600,
      system,
      messages: [
        ...history.slice(-10), // últimas 10 mensagens
        { role: "user", content: message },
      ],
    });

    const text = response.content[0].type === "text" ? response.content[0].text : "";

    res.json({ success: true, message: text });
  } catch (err) {
    console.error("Coach error:", err);
    res.status(500).json({ error: "Erro ao responder. Tente novamente." });
  }
});

export default router;
