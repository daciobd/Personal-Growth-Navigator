# MeuEu Auth + PDF — Guia de Instalação

## O que este pacote adiciona

### Autenticação
- Cadastro e login por e-mail + senha (bcrypt + JWT)
- Access token (15 min) + refresh token rotativo (30 dias)
- Tokens armazenados no `expo-secure-store` (criptografado)
- **Migração automática**: ao fazer login/cadastro, o `deviceId` anônimo é
  vinculado à conta e todos os dados (avaliações, check-ins, coach, progresso)
  são migrados automaticamente
- App continua funcionando sem login (modo anônimo por `deviceId`)

### PDF do paciente
- Gerado no browser do painel admin via `window.print()`
- Conteúdo: radar Big Five, 30 facetas, interpretação por IA,
  plano terapêutico, histórico de check-ins, intervenções do terapeuta
- Zero dependências extras — funciona em qualquer browser moderno

---

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `lib/db/src/schema/users.ts` | `lib/db/src/schema/users.ts` | Criar |
| `artifacts/api-server/src/routes/auth.ts` | `artifacts/api-server/src/routes/auth.ts` | Criar |
| `artifacts/api-server/src/routes/assessmentReport.ts` | `artifacts/api-server/src/routes/assessmentReport.ts` | Criar |
| `artifacts/api-server/src/routes/index.ts` | `artifacts/api-server/src/routes/index.ts` | **Substituir** |
| `artifacts/meueu/context/AuthContext.tsx` | `artifacts/meueu/context/AuthContext.tsx` | Criar |
| `artifacts/meueu/app/auth/login.tsx` | `artifacts/meueu/app/auth/login.tsx` | Criar |
| `artifacts/meueu/app/auth/register.tsx` | `artifacts/meueu/app/auth/register.tsx` | Criar |
| `artifacts/meueu/app/_layout.tsx` | `artifacts/meueu/app/_layout.tsx` | **Substituir** |
| `artifacts/admin/src/pages/TabRelatorio.tsx` | `artifacts/admin/src/pages/TabRelatorio.tsx` | Criar |
| `migrations/0004_auth.sql` | Executar no banco | SQL |

---

## Passo a passo

### 1. Instalar dependências
```bash
# No api-server
pnpm --filter @workspace/api-server add bcryptjs jsonwebtoken
pnpm --filter @workspace/api-server add -D @types/bcryptjs @types/jsonwebtoken

# No app Expo
pnpm --filter @workspace/meueu add expo-secure-store
```

### 2. Adicionar Secret no Replit
Na aba **Secrets** do Replit:
```
JWT_SECRET = uma-string-longa-e-aleatoria-aqui-minimo-32-chars
```

### 3. Criar tabelas no banco
```bash
pnpm --filter @workspace/db db:push
```
Ou cole o SQL de `migrations/0004_auth.sql`.

### 4. Atualizar lib/db/src/schema/index.ts
```typescript
export * from "./users";
```

### 5. Adicionar endpoint /report ao assessment.ts
No final de `artifacts/api-server/src/routes/assessment.ts`:
```typescript
import { reportRouter } from "./assessmentReport.js";
router.use(reportRouter);
```

### 6. Adicionar tab Relatório no admin
Em `artifacts/admin/src/App.tsx`:
```typescript
import TabRelatorio from "./pages/TabRelatorio";
// No array TABS:
{ key: "relatorio", label: "Relatório PDF", icon: FileText }
// No render:
{tab === "relatorio" && <TabRelatorio notify={notify} />}
```

### 7. Verificar _layout.tsx
O arquivo substitui o `_layout.tsx` existente. Confirme que o Replit Agent
preserva as telas de onboarding já existentes na configuração do Stack.

---

## Como funciona a migração do deviceId

1. Usuário usa o app com `deviceId` anônimo (ex: `dev_1234567_abc`)
2. Decide criar conta → tela `/auth/register`
3. App envia `deviceId` junto com o cadastro
4. Servidor vincula `deviceId` ao novo `user.id`
5. Todos os dados (avaliações, check-ins, coach, etc.) são atualizados
   para `deviceId = user_${userId}`
6. AsyncStorage `@meueu_device_id` também é atualizado localmente

Se o usuário já tinha conta e está fazendo login em um novo dispositivo,
o `deviceId` do novo dispositivo NÃO sobrescreve — só vincula se a conta
ainda não tiver um `deviceId` vinculado.

---

## Modo anônimo (sem login)

O app continua funcionando sem login. Na tela de login há o botão
"Continuar sem conta". `REQUIRE_AUTH = false` no `_layout.tsx`.

Para tornar login obrigatório, mude para `true` em:
```typescript
// artifacts/meueu/app/_layout.tsx
const REQUIRE_AUTH = true;
```

---

## Como gerar o PDF

1. No painel admin, acesse a tab **Relatório PDF**
2. Cole o `deviceId` do paciente (ex: `user_42` ou o código anônimo)
3. Clique em **Carregar** — o sistema carrega todos os dados + gera interpretação por IA
4. Visualize o preview em escala reduzida
5. Clique em **Exportar PDF** — abre a janela de impressão do browser
6. Selecione **"Salvar como PDF"** (disponível em Chrome, Firefox, Safari, Edge)

O layout de impressão é controlado por `@media print` — esconde toda a
interface do admin e imprime apenas o relatório clínico.

---

## Variáveis de ambiente necessárias

| Variável | Descrição |
|----------|-----------|
| `JWT_SECRET` | Segredo para assinar tokens JWT (mín. 32 chars) |
| `EXPO_PUBLIC_DOMAIN` | URL do api-server (já existia) |
| `DATABASE_URL` | PostgreSQL (já existia) |
