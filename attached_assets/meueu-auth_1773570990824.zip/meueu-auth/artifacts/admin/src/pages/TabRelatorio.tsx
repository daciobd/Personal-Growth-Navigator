// artifacts/admin/src/pages/TabRelatorio.tsx
//
// Geração de relatório PDF do paciente no browser.
// Estratégia: renderiza HTML completo e aciona window.print().
// Estilos @media print controlam o layout impresso.
// Zero dependências extras — funciona em qualquer browser moderno.

import React, { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";

type PatientFull = {
  patient: {
    linkCode: string; nickname: string; notes: string | null;
    deviceId: string;
  };
  assessments: Array<{
    id: number;
    scoreN: number; scoreE: number; scoreO: number;
    scoreA: number; scoreC: number;
    facetScores: Record<string, number>;
    periodLabel: string; createdAt: string;
    currentAdjectives: string[] | null;
    futureAdjectives:  string[] | null;
  }>;
  messages: Array<{
    id: number; type: string; content: string;
    readAt: string | null; createdAt: string;
  }>;
  checkins: Array<{
    id: number; practiceName: string; completed: boolean;
    note: number | null; comment: string | null; checkinDate: string;
  }>;
  plan: {
    sintese: string; fraseIntencao: string;
    praticas: Array<{ abordagem: string; nome: string; justificativa: string; passos: string[]; frequencia: string }>;
  } | null;
  interpretation: string | null;
};

const THERAPIST_ID = "admin-therapist-1";

const DIMS = [
  { key:"N", label:"Neuroticismo",      color:"#C4622D" },
  { key:"E", label:"Extroversão",       color:"#1B6B5A" },
  { key:"O", label:"Abertura",          color:"#3A5A8C" },
  { key:"A", label:"Amabilidade",       color:"#854F0B" },
  { key:"C", label:"Conscienciosidade", color:"#0F6E56" },
];

const FACET_NAMES: Record<string, string> = {
  N1:"Ansiedade",N2:"Hostilidade",N3:"Depressão",N4:"Autoconsciência",N5:"Impulsividade",N6:"Vulnerabilidade",
  E1:"Cordialidade",E2:"Gregarismo",E3:"Assertividade",E4:"Atividade",E5:"Busca de excitação",E6:"Emoções positivas",
  O1:"Fantasia",O2:"Estética",O3:"Sentimentos",O4:"Ações",O5:"Ideias",O6:"Valores",
  A1:"Confiança",A2:"Franqueza",A3:"Altruísmo",A4:"Complacência",A5:"Modéstia",A6:"Sensibilidade",
  C1:"Competência",C2:"Ordem",C3:"Senso de dever",C4:"Realização",C5:"Autodisciplina",C6:"Deliberação",
};

function levelLabel(p: number) {
  if (p < 20) return "Muito baixo";
  if (p < 35) return "Baixo";
  if (p < 50) return "Moderado-baixo";
  if (p < 65) return "Moderado";
  if (p < 80) return "Alto";
  return "Muito alto";
}

function score(a: PatientFull["assessments"][0], key: string): number {
  const m: Record<string, keyof typeof a> = {N:"scoreN",E:"scoreE",O:"scoreO",A:"scoreA",C:"scoreC"};
  return (a[m[key]] as number) ?? 0;
}

async function apiFetch<T>(path: string): Promise<T> {
  const res = await fetch(`/api${path}`);
  if (!res.ok) throw new Error("Erro ao carregar dados");
  return res.json() as Promise<T>;
}

// ── Radar chart SVG (pure SVG, no lib) ───────────────────
function RadarSVG({ scores, size = 200 }: { scores: Record<string,number>; size?: number }) {
  const cx = size/2, cy = size/2;
  const maxR = size * 0.38;
  const keys = ["N","E","O","A","C"];
  const angles = keys.map((_,i) => (i/5)*2*Math.PI - Math.PI/2);

  function pt(i: number, r: number) {
    return { x: cx + r*Math.cos(angles[i]), y: cy + r*Math.sin(angles[i]) };
  }

  const scorePoints = keys.map((k,i) => pt(i, (scores[k]??50)/100 * maxR));
  const scoreStr = scorePoints.map(p=>`${p.x},${p.y}`).join(" ");

  const grids = [20,40,60,80,100].map(g => {
    const pts = keys.map((_,i)=>{ const p=pt(i,(g/100)*maxR); return `${p.x},${p.y}`; });
    return <polygon key={g} points={pts.join(" ")} fill="none" stroke="#ddd" strokeWidth={0.8}/>;
  });

  const axes = keys.map((_,i)=>{
    const out = pt(i, maxR);
    return <line key={i} x1={cx} y1={cy} x2={out.x} y2={out.y} stroke="#ddd" strokeWidth={0.8}/>;
  });

  const labels = keys.map((k,i)=>{
    const p = pt(i, maxR + 18);
    const dim = DIMS.find(d=>d.key===k)!;
    return (
      <text key={k} x={p.x} y={p.y+4} textAnchor="middle"
        fontSize={9} fontWeight="700" fill={dim.color}>{k} {scores[k]}%</text>
    );
  });

  return (
    <svg width={size} height={size} style={{ display:"block" }}>
      {grids}{axes}
      <polygon points={scoreStr} fill="rgba(27,107,90,0.2)" stroke="#1B6B5A" strokeWidth={2}/>
      {scorePoints.map((p,i)=><circle key={i} cx={p.x} cy={p.y} r={4} fill={DIMS[i].color}/>)}
      {labels}
    </svg>
  );
}

// ── Report HTML renderer ──────────────────────────────────
function ReportContent({ data }: { data: PatientFull }) {
  const lastA = data.assessments[data.assessments.length-1];
  const firstA = data.assessments[0];
  const today = new Date().toLocaleDateString("pt-BR", {day:"numeric",month:"long",year:"numeric"});

  return (
    <div id="report-content" style={{ fontFamily:"Georgia, serif", color:"#0F1F1B", maxWidth:720, margin:"0 auto", padding:"32px 40px" }}>
      {/* Header */}
      <div style={{ borderBottom:"2px solid #1B6B5A", paddingBottom:16, marginBottom:24, display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
        <div>
          <div style={{ fontSize:24, fontWeight:700, color:"#1B6B5A", marginBottom:2 }}>MeuEu</div>
          <div style={{ fontSize:11, color:"#6B8F7E" }}>Relatório Clínico de Personalidade</div>
        </div>
        <div style={{ textAlign:"right", fontSize:11, color:"#6B8F7E" }}>
          <div>Emitido em {today}</div>
          <div style={{ marginTop:2 }}>Código do paciente: <strong>{data.patient.linkCode}</strong></div>
        </div>
      </div>

      {/* Patient */}
      <div style={{ marginBottom:28 }}>
        <h2 style={{ fontSize:18, fontWeight:700, color:"#0F1F1B", margin:"0 0 4px" }}>{data.patient.nickname}</h2>
        <div style={{ fontSize:12, color:"#6B8F7E" }}>
          {data.assessments.length} avaliação{data.assessments.length!==1?"ões":""} realizadas
          {lastA ? ` · Última: ${lastA.periodLabel}` : ""}
        </div>
      </div>

      {/* Big Five */}
      {lastA && (
        <section style={{ marginBottom:28 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#1B6B5A", borderBottom:"1px solid #E8F0ED", paddingBottom:6, marginBottom:16 }}>
            Perfil Big Five — {lastA.periodLabel}
          </h3>
          <div style={{ display:"flex", gap:24, alignItems:"flex-start" }}>
            <RadarSVG scores={{ N:lastA.scoreN,E:lastA.scoreE,O:lastA.scoreO,A:lastA.scoreA,C:lastA.scoreC }} />
            <div style={{ flex:1 }}>
              {DIMS.map(d=>{
                const pct = score(lastA, d.key);
                const delta = data.assessments.length>=2 ? pct - score(firstA, d.key) : null;
                return (
                  <div key={d.key} style={{ marginBottom:12 }}>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:3, fontSize:12 }}>
                      <span style={{ fontWeight:700, color:d.color }}>{d.label}</span>
                      <span style={{ color:"#666" }}>
                        {pct}% · {levelLabel(pct)}
                        {delta!==null && delta!==0 && (
                          <span style={{ color: delta>0?"#1B6B5A":"#C4622D", marginLeft:6 }}>
                            {delta>0?"↑":"↓"}{Math.abs(delta)}p
                          </span>
                        )}
                      </span>
                    </div>
                    <div style={{ height:5, background:"#F0FAF5", borderRadius:3, overflow:"hidden" }}>
                      <div style={{ height:"100%", width:`${pct}%`, background:d.color, borderRadius:3 }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* 30 Facets */}
      {lastA && Object.keys(lastA.facetScores).length > 0 && (
        <section style={{ marginBottom:28 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#1B6B5A", borderBottom:"1px solid #E8F0ED", paddingBottom:6, marginBottom:16 }}>
            30 Facetas
          </h3>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px 24px" }}>
            {Object.entries(lastA.facetScores).map(([key, pct]) => {
              const dim = DIMS.find(d=>key.startsWith(d.key));
              return (
                <div key={key} style={{ display:"flex", alignItems:"center", gap:8, fontSize:11 }}>
                  <span style={{ width:90, color:"#444", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>
                    {FACET_NAMES[key]??key}
                  </span>
                  <div style={{ flex:1, height:4, background:"#F0FAF5", borderRadius:2, overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${pct}%`, background:dim?.color??"#1B6B5A", borderRadius:2, opacity:0.75 }}/>
                  </div>
                  <span style={{ width:30, textAlign:"right", color:dim?.color??"#444", fontWeight:700 }}>{pct}%</span>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* AI Interpretation */}
      {data.interpretation && (
        <section style={{ marginBottom:28 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#1B6B5A", borderBottom:"1px solid #E8F0ED", paddingBottom:6, marginBottom:12 }}>
            Interpretação do Perfil
          </h3>
          <p style={{ fontSize:13, lineHeight:1.75, color:"#333", whiteSpace:"pre-wrap" }}>{data.interpretation}</p>
        </section>
      )}

      {/* Plan */}
      {data.plan && (
        <section style={{ marginBottom:28 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#1B6B5A", borderBottom:"1px solid #E8F0ED", paddingBottom:6, marginBottom:12 }}>
            Plano Terapêutico Personalizado
          </h3>
          <p style={{ fontSize:13, color:"#333", lineHeight:1.7, marginBottom:14, fontStyle:"italic" }}>
            {data.plan.sintese}
          </p>
          {data.plan.praticas.map((pr,i)=>(
            <div key={i} style={{ marginBottom:14, background:"#F8FCF9", borderRadius:8, padding:12 }}>
              <div style={{ fontSize:12, fontWeight:700, color:"#1B6B5A", marginBottom:4 }}>
                Prática {i+1} · {pr.abordagem} · {pr.nome}
              </div>
              <p style={{ fontSize:12, color:"#555", fontStyle:"italic", marginBottom:8 }}>{pr.justificativa}</p>
              <ol style={{ paddingLeft:16, margin:0 }}>
                {pr.passos.map((p,j)=>(
                  <li key={j} style={{ fontSize:12, color:"#444", lineHeight:1.65 }}>{p}</li>
                ))}
              </ol>
              <p style={{ fontSize:11, color:"#6B8F7E", marginTop:6 }}>Frequência: {pr.frequencia}</p>
            </div>
          ))}
        </section>
      )}

      {/* Check-in history */}
      {data.checkins.length > 0 && (
        <section style={{ marginBottom:28 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#1B6B5A", borderBottom:"1px solid #E8F0ED", paddingBottom:6, marginBottom:12 }}>
            Histórico de Check-ins ({data.checkins.length} registros)
          </h3>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:11 }}>
            <thead>
              <tr style={{ borderBottom:"1px solid #E8F0ED" }}>
                {["Data","Prática","Realizado","Nota","Observação"].map(h=>(
                  <th key={h} style={{ padding:"4px 8px", textAlign:"left", color:"#6B8F7E", fontWeight:600 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.checkins.slice(0,30).map(c=>(
                <tr key={c.id} style={{ borderBottom:"1px solid #F0FAF5" }}>
                  <td style={{ padding:"4px 8px", color:"#444" }}>{new Date(c.checkinDate).toLocaleDateString("pt-BR")}</td>
                  <td style={{ padding:"4px 8px", color:"#444" }}>{c.practiceName}</td>
                  <td style={{ padding:"4px 8px", color: c.completed?"#1B6B5A":"#C4622D" }}>{c.completed?"Sim":"Não"}</td>
                  <td style={{ padding:"4px 8px", color:"#444", fontWeight:600 }}>{c.note??"-"}</td>
                  <td style={{ padding:"4px 8px", color:"#666", fontStyle:"italic" }}>{c.comment??""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}

      {/* Therapist messages */}
      {data.messages.length > 0 && (
        <section style={{ marginBottom:28 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#1B6B5A", borderBottom:"1px solid #E8F0ED", paddingBottom:6, marginBottom:12 }}>
            Intervenções do Terapeuta
          </h3>
          {data.messages.map(m=>(
            <div key={m.id} style={{ marginBottom:8, padding:"8px 12px", background:"#F8FCF9", borderRadius:6 }}>
              <div style={{ display:"flex", gap:8, marginBottom:4 }}>
                <span style={{ fontSize:10, fontWeight:700, color:"#1B6B5A", textTransform:"uppercase" }}>{m.type}</span>
                <span style={{ fontSize:10, color:"#AAA" }}>{new Date(m.createdAt).toLocaleDateString("pt-BR")}</span>
              </div>
              <p style={{ fontSize:12, color:"#333", lineHeight:1.65, margin:0 }}>{m.content}</p>
            </div>
          ))}
        </section>
      )}

      {/* Footer */}
      <div style={{ borderTop:"1px solid #E8F0ED", paddingTop:12, marginTop:16, fontSize:10, color:"#AAA", display:"flex", justifyContent:"space-between" }}>
        <span>MeuEu — Relatório Clínico Confidencial</span>
        <span>Gerado em {today}</span>
      </div>
    </div>
  );
}

// ── Report API endpoint (GET /api/assessment/report/:deviceId) ──
// Adicionar no assessment.ts do servidor:
//   GET /api/assessment/report/:deviceId?therapistId=xxx
// Retorna: { patient, assessments, messages, checkins, plan, interpretation }

// ── Main component ────────────────────────────────────────
export default function TabRelatorio({ notify }: { notify: (msg: string, type?: "ok"|"error") => void }) {
  const [deviceId, setDeviceId] = useState("");
  const [loadedId, setLoadedId] = useState<string | null>(null);
  const [printing, setPrinting] = useState(false);

  const { data, isLoading, error } = useQuery<PatientFull>({
    queryKey: ["report", loadedId],
    queryFn: () => fetch(`/api/assessment/report/${loadedId}?therapistId=${THERAPIST_ID}`)
      .then(r => r.json() as Promise<PatientFull>),
    enabled: !!loadedId,
  });

  function load() {
    if (!deviceId.trim()) return;
    setLoadedId(deviceId.trim());
  }

  function printReport() {
    setPrinting(true);
    setTimeout(() => {
      window.print();
      setPrinting(false);
    }, 300);
  }

  return (
    <>
      {/* Print styles */}
      <style>{`
        @media print {
          body > *:not(#print-root) { display: none !important; }
          #print-root { display: block !important; }
          #report-content { padding: 0 !important; max-width: 100% !important; }
          @page { margin: 20mm; }
        }
        @media screen {
          #print-root { display: none; }
        }
      `}</style>

      {/* Hidden print target */}
      <div id="print-root">
        {data && <ReportContent data={data} />}
      </div>

      {/* Screen UI */}
      <div style={{ maxWidth:700 }}>
        <div style={{ background:"#161614", border:"1px solid #252520", borderRadius:12, padding:"20px", marginBottom:20 }}>
          <p style={{ fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:".08em", color:"#555", marginBottom:12 }}>
            Gerar relatório PDF
          </p>
          <p style={{ fontSize:12, color:"#666", marginBottom:14, lineHeight:1.6 }}>
            Informe o deviceId ou código do paciente para carregar os dados e gerar o PDF.
          </p>
          <div style={{ display:"flex", gap:8 }}>
            <input
              value={deviceId}
              onChange={e => setDeviceId(e.target.value)}
              placeholder="deviceId ou user_123"
              style={{ flex:1, background:"#0D0D0C", border:"1px solid #2A2A27", borderRadius:8, padding:"9px 12px", color:"#DDD", fontSize:13, fontFamily:"Inter, sans-serif", outline:"none" }}
              onKeyDown={e => e.key === "Enter" && load()}
            />
            <button
              onClick={load}
              style={{ background:"#1C2818", border:"1px solid #2D5016", borderRadius:8, padding:"9px 18px", color:"#7BAA6A", fontSize:13, fontWeight:700, cursor:"pointer" }}>
              Carregar
            </button>
          </div>
        </div>

        {isLoading && <p style={{ color:"#555", textAlign:"center", padding:32 }}>Carregando dados do paciente…</p>}
        {error && <p style={{ color:"#E87B7B", padding:16 }}>Erro ao carregar. Verifique o deviceId.</p>}

        {data && (
          <>
            {/* Preview */}
            <div style={{ background:"#fff", borderRadius:12, overflow:"hidden", marginBottom:16, border:"1px solid #252520" }}>
              <div style={{ background:"#161614", padding:"12px 16px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <p style={{ fontSize:13, fontWeight:700, color:"#E8E4DC" }}>
                  Preview — {data.patient.nickname}
                </p>
                <button
                  onClick={printReport}
                  disabled={printing}
                  style={{ background:"#1B6B5A", border:"none", borderRadius:8, padding:"8px 18px", color:"#fff", fontSize:13, fontWeight:700, cursor:"pointer", opacity: printing ? 0.7 : 1 }}>
                  {printing ? "Abrindo…" : "Exportar PDF"}
                </button>
              </div>
              <div style={{ transform:"scale(0.7)", transformOrigin:"top left", width:"143%", pointerEvents:"none" }}>
                <ReportContent data={data} />
              </div>
            </div>

            <p style={{ fontSize:12, color:"#555", textAlign:"center" }}>
              Clique em "Exportar PDF" — o browser abrirá a janela de impressão/save. Use "Salvar como PDF".
            </p>
          </>
        )}
      </div>
    </>
  );
}
