// Adicionar em artifacts/api-server/src/routes/assessment.ts
// GET /api/assessment/report/:deviceId?therapistId=xxx
//
// Agrega todos os dados do paciente para o relatório PDF:
// avaliações Big Five, check-ins, plano, interpretação e mensagens do terapeuta.

import { Router } from "express";
import { db } from "@workspace/db";
import {
  assessmentsTable,
  therapistLinksTable,
  therapistMessagesTable,
  dailyCheckinsTable,
  planLogsTable,
} from "@workspace/db/schema";
import { eq, desc } from "drizzle-orm";
import { anthropic } from "@workspace/integrations-anthropic-ai";

const reportRouter = Router();

const DIM_NAMES: Record<string, string> = {
  N:"Neuroticismo", E:"Extroversão", O:"Abertura",
  A:"Amabilidade",  C:"Conscienciosidade",
};

function levelLabel(p: number): string {
  if (p < 20) return "muito baixo";
  if (p < 35) return "baixo";
  if (p < 50) return "moderado-baixo";
  if (p < 65) return "moderado";
  if (p < 80) return "alto";
  return "muito alto";
}

reportRouter.get("/report/:deviceId", async (req, res) => {
  const { deviceId } = req.params;
  const { therapistId } = req.query as { therapistId?: string };

  // Verifica vínculo terapeuta-paciente
  if (therapistId) {
    const link = await db.select()
      .from(therapistLinksTable)
      .where(eq(therapistLinksTable.deviceId, deviceId))
      .limit(1);
    if (!link.length || link[0].therapistId !== therapistId) {
      res.status(403).json({ error: "Sem permissão para acessar este paciente" });
      return;
    }
  }

  // Carrega tudo em paralelo
  const [
    assessments,
    messages,
    checkins,
    planRows,
    link,
  ] = await Promise.all([
    db.select().from(assessmentsTable)
      .where(eq(assessmentsTable.deviceId, deviceId))
      .orderBy(assessmentsTable.createdAt),
    db.select().from(therapistMessagesTable)
      .where(eq(therapistMessagesTable.deviceId, deviceId))
      .orderBy(desc(therapistMessagesTable.createdAt))
      .limit(30),
    db.select().from(dailyCheckinsTable)
      .where(eq(dailyCheckinsTable.deviceId, deviceId))
      .orderBy(desc(dailyCheckinsTable.checkinDate))
      .limit(50),
    db.select().from(planLogsTable)
      .where(eq(planLogsTable.deviceId, deviceId))
      .orderBy(desc(planLogsTable.createdAt))
      .limit(1),
    db.select().from(therapistLinksTable)
      .where(eq(therapistLinksTable.deviceId, deviceId))
      .limit(1),
  ]);

  const lastAssessment = assessments[assessments.length - 1];
  const plan = planRows[0]?.plan as Record<string, unknown> | null;

  // Gera interpretação textual se tiver avaliação
  let interpretation: string | null = null;
  if (lastAssessment) {
    const dimLines = ["N","E","O","A","C"].map(d => {
      const pct = lastAssessment[`score${d}` as keyof typeof lastAssessment] as number;
      return `${DIM_NAMES[d]}: ${pct}% (${levelLabel(pct)})`;
    }).join(", ");

    try {
      const msg = await anthropic.messages.create({
        model: "claude-haiku-4-5",
        max_tokens: 500,
        messages: [{
          role: "user",
          content: `Você é um psicólogo clínico. Escreva um parágrafo clínico e acolhedor (máx 5 frases) interpretando este perfil Big Five para um relatório profissional: ${dimLines}. Responda apenas o parágrafo, sem título.`,
        }],
      });
      interpretation = msg.content[0].type === "text" ? msg.content[0].text : null;
    } catch { /* interpretation remains null */ }
  }

  res.json({
    patient: {
      deviceId,
      linkCode: link[0]?.linkCode ?? deviceId,
      nickname: link[0]?.nickname ?? "Paciente",
      notes: link[0]?.notes ?? null,
    },
    assessments,
    messages,
    checkins,
    plan: plan && !("parseError" in plan) ? plan : null,
    interpretation,
  });
});

export { reportRouter };

// ── INSTRUÇÃO DE INTEGRAÇÃO ───────────────────────────────
// Em artifacts/api-server/src/routes/assessment.ts, adicione no final:
//
//   import { reportRouter } from "./assessmentReport.js";
//   router.use(reportRouter);
//
// Ou cole diretamente o handler acima no arquivo existente.
