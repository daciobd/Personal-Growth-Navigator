// artifacts/api-server/src/routes/auth.ts
//
// POST /api/auth/register        — cadastro com e-mail e senha
// POST /api/auth/login           — login, retorna access + refresh tokens
// POST /api/auth/refresh         — renova access token com refresh token
// POST /api/auth/logout          — invalida refresh token
// GET  /api/auth/me              — dados do usuário autenticado
// POST /api/auth/migrate-device  — vincula deviceId anônimo à conta (migração)

import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "@workspace/db";
import { usersTable, refreshTokensTable } from "@workspace/db/schema";
import { eq, and, gt } from "drizzle-orm";
import {
  assessmentsTable,
  dailyCheckinsTable,
  userProgressTable,
  coachMessagesTable,
  therapistLinksTable,
} from "@workspace/db/schema";

const router = Router();

const JWT_SECRET         = process.env.JWT_SECRET ?? "change-me-in-production";
const ACCESS_EXPIRES_IN  = "15m";
const REFRESH_EXPIRES_IN = "30d";

// ── Helpers ───────────────────────────────────────────────
function signAccess(userId: number, email: string, isTherapist: boolean) {
  return jwt.sign({ sub: userId, email, isTherapist }, JWT_SECRET, {
    expiresIn: ACCESS_EXPIRES_IN,
  });
}

async function createRefreshToken(userId: number): Promise<string> {
  const token = jwt.sign({ sub: userId, type: "refresh" }, JWT_SECRET, {
    expiresIn: REFRESH_EXPIRES_IN,
  });
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await db.insert(refreshTokensTable).values({ userId, token, expiresAt });
  return token;
}

// ── POST /api/auth/register ───────────────────────────────
router.post("/register", async (req, res) => {
  const { email, password, name, deviceId } = req.body as {
    email: string; password: string; name: string; deviceId?: string;
  };

  if (!email || !password || !name) {
    res.status(400).json({ error: "email, password e name são obrigatórios" });
    return;
  }
  if (password.length < 8) {
    res.status(400).json({ error: "Senha deve ter ao menos 8 caracteres" });
    return;
  }

  const existing = await db.select({ id: usersTable.id })
    .from(usersTable).where(eq(usersTable.email, email.toLowerCase())).limit(1);
  if (existing.length) {
    res.status(409).json({ error: "Este e-mail já está cadastrado" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const [user] = await db.insert(usersTable).values({
    email: email.toLowerCase(), passwordHash, name,
    deviceId: deviceId ?? null,
  }).returning();

  // Se vier com deviceId, migra os dados anônimos
  if (deviceId) await migrateDeviceData(deviceId, user.id);

  const accessToken  = signAccess(user.id, user.email, user.isTherapist);
  const refreshToken = await createRefreshToken(user.id);

  res.status(201).json({
    accessToken, refreshToken,
    user: { id: user.id, email: user.email, name: user.name, isTherapist: user.isTherapist },
  });
});

// ── POST /api/auth/login ──────────────────────────────────
router.post("/login", async (req, res) => {
  const { email, password, deviceId } = req.body as {
    email: string; password: string; deviceId?: string;
  };

  if (!email || !password) {
    res.status(400).json({ error: "email e password são obrigatórios" });
    return;
  }

  const [user] = await db.select().from(usersTable)
    .where(eq(usersTable.email, email.toLowerCase())).limit(1);
  if (!user) {
    res.status(401).json({ error: "E-mail ou senha incorretos" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "E-mail ou senha incorretos" });
    return;
  }

  // Atualiza lastLoginAt e vincula deviceId se ainda não vinculado
  await db.update(usersTable)
    .set({
      lastLoginAt: new Date(),
      deviceId: user.deviceId ?? deviceId ?? null,
    })
    .where(eq(usersTable.id, user.id));

  // Migra dados anônimos se deviceId novo
  if (deviceId && !user.deviceId) await migrateDeviceData(deviceId, user.id);

  const accessToken  = signAccess(user.id, user.email, user.isTherapist);
  const refreshToken = await createRefreshToken(user.id);

  res.json({
    accessToken, refreshToken,
    user: { id: user.id, email: user.email, name: user.name, isTherapist: user.isTherapist },
  });
});

// ── POST /api/auth/refresh ────────────────────────────────
router.post("/refresh", async (req, res) => {
  const { refreshToken } = req.body as { refreshToken: string };
  if (!refreshToken) {
    res.status(401).json({ error: "refreshToken obrigatório" });
    return;
  }

  let payload: { sub: number };
  try {
    payload = jwt.verify(refreshToken, JWT_SECRET) as { sub: number };
  } catch {
    res.status(401).json({ error: "Token inválido ou expirado" });
    return;
  }

  const stored = await db.select()
    .from(refreshTokensTable)
    .where(
      and(
        eq(refreshTokensTable.token, refreshToken),
        gt(refreshTokensTable.expiresAt, new Date()),
      )
    ).limit(1);

  if (!stored.length) {
    res.status(401).json({ error: "Token revogado" });
    return;
  }

  const [user] = await db.select().from(usersTable)
    .where(eq(usersTable.id, payload.sub)).limit(1);
  if (!user) { res.status(401).json({ error: "Usuário não encontrado" }); return; }

  // Rotaciona o refresh token
  await db.delete(refreshTokensTable)
    .where(eq(refreshTokensTable.token, refreshToken));
  const newRefresh = await createRefreshToken(user.id);
  const newAccess  = signAccess(user.id, user.email, user.isTherapist);

  res.json({ accessToken: newAccess, refreshToken: newRefresh });
});

// ── POST /api/auth/logout ─────────────────────────────────
router.post("/logout", async (req, res) => {
  const { refreshToken } = req.body as { refreshToken: string };
  if (refreshToken) {
    await db.delete(refreshTokensTable)
      .where(eq(refreshTokensTable.token, refreshToken))
      .catch(() => {});
  }
  res.json({ success: true });
});

// ── GET /api/auth/me ──────────────────────────────────────
router.get("/me", requireAuth, async (req, res) => {
  const [user] = await db.select({
    id: usersTable.id, email: usersTable.email,
    name: usersTable.name, isTherapist: usersTable.isTherapist,
    isAdmin: usersTable.isAdmin, deviceId: usersTable.deviceId,
    createdAt: usersTable.createdAt,
  }).from(usersTable).where(eq(usersTable.id, (req as any).userId)).limit(1);

  if (!user) { res.status(404).json({ error: "Usuário não encontrado" }); return; }
  res.json(user);
});

// ── POST /api/auth/migrate-device ────────────────────────
// Pode ser chamado após login se o deviceId ainda não estava vinculado
router.post("/migrate-device", requireAuth, async (req, res) => {
  const { deviceId } = req.body as { deviceId: string };
  const userId = (req as any).userId as number;

  if (!deviceId) { res.status(400).json({ error: "deviceId obrigatório" }); return; }

  await db.update(usersTable)
    .set({ deviceId })
    .where(eq(usersTable.id, userId));

  const migrated = await migrateDeviceData(deviceId, userId);
  res.json({ success: true, migrated });
});

// ── Middleware ────────────────────────────────────────────
export function requireAuth(req: any, res: any, next: any) {
  const header = req.headers["authorization"] as string;
  if (!header?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Token de acesso obrigatório" });
    return;
  }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET) as { sub: number };
    req.userId = payload.sub;
    next();
  } catch {
    res.status(401).json({ error: "Token inválido ou expirado" });
  }
}

// ── Migration helper ──────────────────────────────────────
async function migrateDeviceData(deviceId: string, userId: number) {
  const results: Record<string, number> = {};

  // Vincula assessments
  const { rowCount: a } = await db
    .update(assessmentsTable)
    .set({ deviceId: `user_${userId}` })
    .where(eq(assessmentsTable.deviceId, deviceId))
    .catch(() => ({ rowCount: 0 })) as { rowCount: number };
  results.assessments = a ?? 0;

  // Vincula check-ins
  const { rowCount: c } = await db
    .update(dailyCheckinsTable)
    .set({ deviceId: `user_${userId}` })
    .where(eq(dailyCheckinsTable.deviceId, deviceId))
    .catch(() => ({ rowCount: 0 })) as { rowCount: number };
  results.checkins = c ?? 0;

  // Vincula progresso gamificado
  await db
    .update(userProgressTable)
    .set({ deviceId: `user_${userId}` })
    .where(eq(userProgressTable.deviceId, deviceId))
    .catch(() => {});

  // Vincula mensagens do coach
  await db
    .update(coachMessagesTable)
    .set({ deviceId: `user_${userId}` })
    .where(eq(coachMessagesTable.deviceId, deviceId))
    .catch(() => {});

  // Vincula código de terapeuta
  await db
    .update(therapistLinksTable)
    .set({ deviceId: `user_${userId}` })
    .where(eq(therapistLinksTable.deviceId, deviceId))
    .catch(() => {});

  return results;
}

export default router;
