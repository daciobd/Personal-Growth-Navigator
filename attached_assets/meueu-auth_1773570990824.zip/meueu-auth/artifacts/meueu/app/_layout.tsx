// artifacts/meueu/app/_layout.tsx
// Layout raiz — envolve tudo com AuthProvider.
// Redireciona para /auth/login se não autenticado (opcional — ver nota abaixo).
//
// NOTA: O app suporta uso sem conta (deviceId anônimo).
// O guard só redireciona se REQUIRE_AUTH = true.
// Para tornar login obrigatório, mude para true.

import React, { useEffect } from "react";
import { Stack } from "expo-router";
import { useFonts, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from "@expo-google-fonts/inter";
import * as SplashScreen from "expo-splash-screen";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { AuthProvider, useAuth } from "../context/AuthContext";
import { GamificationProvider } from "../context/GamificationContext";

SplashScreen.preventAutoHideAsync();

const REQUIRE_AUTH = false; // Mude para true para exigir login

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, loading } = useAuth();

  useEffect(() => {
    if (!loading && !isAuthenticated && REQUIRE_AUTH) {
      // Delay para o router estar pronto
      setTimeout(() => {
        const { router } = require("expo-router");
        router.replace("/auth/login");
      }, 100);
    }
  }, [isAuthenticated, loading]);

  return <>{children}</>;
}

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded) SplashScreen.hideAsync();
  }, [fontsLoaded]);

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AuthProvider>
          <GamificationProvider>
            <AuthGuard>
              <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="(tabs)"     options={{ headerShown: false }} />
                <Stack.Screen name="auth/login"    options={{ animation: "fade" }} />
                <Stack.Screen name="auth/register" options={{ animation: "slide_from_right" }} />
                <Stack.Screen name="assessment/index"  options={{ animation: "slide_from_bottom" }} />
                <Stack.Screen name="assessment/result" options={{ animation: "fade" }} />
                <Stack.Screen name="coach/index"   options={{ animation: "slide_from_right" }} />
              </Stack>
            </AuthGuard>
          </GamificationProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
