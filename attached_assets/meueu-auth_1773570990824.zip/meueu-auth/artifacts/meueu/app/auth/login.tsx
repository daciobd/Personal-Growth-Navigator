// artifacts/meueu/app/auth/login.tsx
import React, { useState } from "react";
import {
  View, Text, StyleSheet, TextInput, Pressable,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { useAuth } from "../../context/AuthContext";

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { login } = useAuth();
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading]   = useState(false);

  async function handleLogin() {
    if (!email.trim() || !password) {
      Alert.alert("Campos obrigatórios", "Preencha e-mail e senha.");
      return;
    }
    setLoading(true);
    try {
      await login(email.trim(), password);
      router.replace("/(tabs)");
    } catch (e) {
      Alert.alert("Erro ao entrar", (e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={[styles.inner, { paddingTop: insets.top + 48, paddingBottom: insets.bottom + 24 }]}>

        <View style={styles.logoWrap}>
          <View style={styles.logoMark}>
            <Text style={styles.logoLetter}>M</Text>
          </View>
          <Text style={styles.appName}>MeuEu</Text>
          <Text style={styles.tagline}>Sua jornada de transformação pessoal</Text>
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>E-mail</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="seu@email.com"
            placeholderTextColor="#A8C0B8"
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
          />

          <Text style={styles.label}>Senha</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder="Sua senha"
            placeholderTextColor="#A8C0B8"
            secureTextEntry
            autoComplete="current-password"
          />

          <Pressable
            style={[styles.btn, loading && { opacity: 0.6 }]}
            onPress={handleLogin}
            disabled={loading}>
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.btnText}>Entrar</Text>}
          </Pressable>

          <Pressable
            style={styles.linkBtn}
            onPress={() => router.push("/auth/register")}>
            <Text style={styles.linkText}>
              Não tem conta? <Text style={styles.linkBold}>Criar conta gratuita</Text>
            </Text>
          </Pressable>

          <Pressable
            style={styles.skipBtn}
            onPress={() => router.replace("/(tabs)")}>
            <Text style={styles.skipText}>Continuar sem conta</Text>
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F5F8F6" },
  inner: { flex: 1, paddingHorizontal: 24, justifyContent: "space-between" },
  logoWrap: { alignItems: "center", gap: 10 },
  logoMark: { width: 64, height: 64, borderRadius: 20, backgroundColor: "#1B6B5A", alignItems: "center", justifyContent: "center" },
  logoLetter: { fontFamily: "Inter_700Bold", fontSize: 32, color: "#C8F0E0" },
  appName: { fontSize: 28, fontWeight: "700", color: "#0F1F1B" },
  tagline: { fontSize: 14, color: "#6B8F7E", textAlign: "center" },
  form: { gap: 4 },
  label: { fontSize: 13, fontWeight: "600", color: "#3D5A52", marginBottom: 6, marginTop: 14 },
  input: {
    backgroundColor: "#fff", borderWidth: 1.5, borderColor: "#E8F0ED",
    borderRadius: 12, paddingHorizontal: 16, paddingVertical: 13,
    fontSize: 15, color: "#0F1F1B",
  },
  btn: {
    backgroundColor: "#1B6B5A", borderRadius: 14, paddingVertical: 15,
    alignItems: "center", marginTop: 24,
  },
  btnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  linkBtn: { alignItems: "center", paddingVertical: 14 },
  linkText: { fontSize: 14, color: "#6B8F7E" },
  linkBold: { color: "#1B6B5A", fontWeight: "700" },
  skipBtn: { alignItems: "center", paddingVertical: 8 },
  skipText: { fontSize: 13, color: "#A8C0B8" },
});
