// artifacts/meueu/app/auth/register.tsx
import React, { useState } from "react";
import {
  View, Text, StyleSheet, TextInput, Pressable,
  KeyboardAvoidingView, Platform, ActivityIndicator,
  ScrollView, Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { useAuth } from "../../context/AuthContext";

export default function RegisterScreen() {
  const insets = useSafeAreaInsets();
  const { register } = useAuth();
  const [name, setName]         = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm]   = useState("");
  const [loading, setLoading]   = useState(false);

  async function handleRegister() {
    if (!name.trim() || !email.trim() || !password) {
      Alert.alert("Campos obrigatórios", "Preencha nome, e-mail e senha.");
      return;
    }
    if (password.length < 8) {
      Alert.alert("Senha fraca", "A senha deve ter ao menos 8 caracteres.");
      return;
    }
    if (password !== confirm) {
      Alert.alert("Senhas diferentes", "As senhas não coincidem.");
      return;
    }
    setLoading(true);
    try {
      await register(email.trim(), password, name.trim());
      router.replace("/(tabs)");
    } catch (e) {
      Alert.alert("Erro ao criar conta", (e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView
        contentContainerStyle={[styles.inner, {
          paddingTop: insets.top + 16,
          paddingBottom: insets.bottom + 32,
        }]}
        keyboardShouldPersistTaps="handled">

        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Feather name="arrow-left" size={20} color="#0F1F1B" />
          </Pressable>
          <Text style={styles.title}>Criar conta</Text>
        </View>

        <Text style={styles.sub}>
          Seus dados ficam seguros. Apenas e-mail e nome são necessários.
        </Text>

        {[
          { label: "Nome", value: name, set: setName, placeholder: "Como prefere ser chamado", type: "default" as const, secure: false },
          { label: "E-mail", value: email, set: setEmail, placeholder: "seu@email.com", type: "email-address" as const, secure: false },
          { label: "Senha (mín. 8 caracteres)", value: password, set: setPassword, placeholder: "••••••••", type: "default" as const, secure: true },
          { label: "Confirmar senha", value: confirm, set: setConfirm, placeholder: "••••••••", type: "default" as const, secure: true },
        ].map(field => (
          <View key={field.label} style={{ marginBottom: 16 }}>
            <Text style={styles.label}>{field.label}</Text>
            <TextInput
              style={styles.input}
              value={field.value}
              onChangeText={field.set}
              placeholder={field.placeholder}
              placeholderTextColor="#A8C0B8"
              keyboardType={field.type}
              autoCapitalize={field.type === "email-address" ? "none" : field.label === "Nome" ? "words" : "none"}
              secureTextEntry={field.secure}
            />
          </View>
        ))}

        <View style={styles.privacyBox}>
          <Feather name="shield" size={14} color="#1B6B5A" />
          <Text style={styles.privacyText}>
            Seus dados de avaliação são anônimos e nunca vendidos. O e-mail é usado apenas para recuperação de conta.
          </Text>
        </View>

        <Pressable
          style={[styles.btn, loading && { opacity: 0.6 }]}
          onPress={handleRegister}
          disabled={loading}>
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.btnText}>Criar minha conta</Text>}
        </Pressable>

        <Pressable style={styles.linkBtn} onPress={() => router.back()}>
          <Text style={styles.linkText}>
            Já tem conta? <Text style={styles.linkBold}>Entrar</Text>
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F5F8F6" },
  inner: { paddingHorizontal: 24 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 22, fontWeight: "700", color: "#0F1F1B" },
  sub: { fontSize: 13, color: "#6B8F7E", lineHeight: 20, marginBottom: 24 },
  label: { fontSize: 13, fontWeight: "600", color: "#3D5A52", marginBottom: 6 },
  input: {
    backgroundColor: "#fff", borderWidth: 1.5, borderColor: "#E8F0ED",
    borderRadius: 12, paddingHorizontal: 16, paddingVertical: 13,
    fontSize: 15, color: "#0F1F1B",
  },
  privacyBox: {
    flexDirection: "row", alignItems: "flex-start", gap: 10,
    backgroundColor: "#E8F5F1", borderRadius: 10, padding: 12, marginBottom: 24,
  },
  privacyText: { flex: 1, fontSize: 12, color: "#3D5A52", lineHeight: 18 },
  btn: {
    backgroundColor: "#1B6B5A", borderRadius: 14, paddingVertical: 15,
    alignItems: "center", marginBottom: 16,
  },
  btnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  linkBtn: { alignItems: "center", paddingVertical: 8 },
  linkText: { fontSize: 14, color: "#6B8F7E" },
  linkBold: { color: "#1B6B5A", fontWeight: "700" },
});
