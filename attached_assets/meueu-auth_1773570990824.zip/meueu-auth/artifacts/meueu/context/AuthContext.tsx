// artifacts/meueu/context/AuthContext.tsx
//
// Contexto de autenticação do MeuEu.
// Tokens armazenados no expo-secure-store (criptografado no dispositivo).
// deviceId continua sendo usado para dados anônimos pré-login;
// após o login, torna-se `user_${userId}` em todo o sistema.

import React, {
  createContext, useContext, useState,
  useEffect, useCallback, useRef,
} from "react";
import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";

// ── Types ─────────────────────────────────────────────────
export type AuthUser = {
  id: number;
  email: string;
  name: string;
  isTherapist: boolean;
};

type AuthState = {
  user: AuthUser | null;
  accessToken: string | null;
  loading: boolean;
  isAuthenticated: boolean;
};

type AuthContextValue = AuthState & {
  login:    (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  logout:   () => Promise<void>;
  getValidToken: () => Promise<string | null>;
};

// ── Keys ──────────────────────────────────────────────────
const KEYS = {
  ACCESS:  "meueu_access_token",
  REFRESH: "meueu_refresh_token",
  USER:    "meueu_user",
};

const AuthContext = createContext<AuthContextValue | null>(null);

// ── Provider ──────────────────────────────────────────────
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null, accessToken: null, loading: true, isAuthenticated: false,
  });
  const refreshPromiseRef = useRef<Promise<string | null> | null>(null);

  const domain = process.env.EXPO_PUBLIC_DOMAIN ?? "";

  // ── Load persisted session on mount ───────────────────
  useEffect(() => {
    (async () => {
      try {
        const [access, userJson] = await Promise.all([
          SecureStore.getItemAsync(KEYS.ACCESS),
          SecureStore.getItemAsync(KEYS.USER),
        ]);
        if (access && userJson) {
          const user = JSON.parse(userJson) as AuthUser;
          setState({ user, accessToken: access, loading: false, isAuthenticated: true });
          return;
        }
      } catch {}
      setState(s => ({ ...s, loading: false }));
    })();
  }, []);

  // ── Refresh access token ───────────────────────────────
  const refreshAccessToken = useCallback(async (): Promise<string | null> => {
    // Deduplicate concurrent refresh calls
    if (refreshPromiseRef.current) return refreshPromiseRef.current;

    refreshPromiseRef.current = (async () => {
      try {
        const refresh = await SecureStore.getItemAsync(KEYS.REFRESH);
        if (!refresh) return null;

        const res = await fetch(`${domain}/api/auth/refresh`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refreshToken: refresh }),
        });
        if (!res.ok) throw new Error("Refresh failed");

        const { accessToken, refreshToken: newRefresh } = await res.json() as {
          accessToken: string; refreshToken: string;
        };

        await Promise.all([
          SecureStore.setItemAsync(KEYS.ACCESS,  accessToken),
          SecureStore.setItemAsync(KEYS.REFRESH, newRefresh),
        ]);
        setState(s => ({ ...s, accessToken }));
        return accessToken;
      } catch {
        // Session expired — force logout
        await clearSession();
        return null;
      } finally {
        refreshPromiseRef.current = null;
      }
    })();

    return refreshPromiseRef.current;
  }, [domain]);

  // ── Get valid token (refreshes if needed) ─────────────
  const getValidToken = useCallback(async (): Promise<string | null> => {
    const token = state.accessToken;
    if (!token) return refreshAccessToken();

    // Decode expiry without verifying signature (client-side check only)
    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      const expiresIn = (payload.exp * 1000) - Date.now();
      if (expiresIn < 60_000) return refreshAccessToken(); // refresh if < 1 min left
    } catch {}

    return token;
  }, [state.accessToken, refreshAccessToken]);

  // ── Login ─────────────────────────────────────────────
  const login = useCallback(async (email: string, password: string) => {
    const deviceId = await AsyncStorage.getItem("@meueu_device_id") ?? undefined;

    const res = await fetch(`${domain}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: email.toLowerCase(), password, deviceId }),
    });

    const data = await res.json() as {
      accessToken: string; refreshToken: string; user: AuthUser; error?: string;
    };
    if (!res.ok) throw new Error(data.error ?? "Erro ao fazer login");

    await saveSession(data.accessToken, data.refreshToken, data.user);
    // Update deviceId to use user-scoped ID going forward
    await AsyncStorage.setItem("@meueu_device_id", `user_${data.user.id}`);

    setState({ user: data.user, accessToken: data.accessToken, loading: false, isAuthenticated: true });
  }, [domain]);

  // ── Register ──────────────────────────────────────────
  const register = useCallback(async (email: string, password: string, name: string) => {
    const deviceId = await AsyncStorage.getItem("@meueu_device_id") ?? undefined;

    const res = await fetch(`${domain}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: email.toLowerCase(), password, name, deviceId }),
    });

    const data = await res.json() as {
      accessToken: string; refreshToken: string; user: AuthUser; error?: string;
    };
    if (!res.ok) throw new Error(data.error ?? "Erro ao criar conta");

    await saveSession(data.accessToken, data.refreshToken, data.user);
    await AsyncStorage.setItem("@meueu_device_id", `user_${data.user.id}`);

    setState({ user: data.user, accessToken: data.accessToken, loading: false, isAuthenticated: true });
  }, [domain]);

  // ── Logout ────────────────────────────────────────────
  const logout = useCallback(async () => {
    try {
      const refresh = await SecureStore.getItemAsync(KEYS.REFRESH);
      if (refresh) {
        await fetch(`${domain}/api/auth/logout`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refreshToken: refresh }),
        }).catch(() => {});
      }
    } catch {}
    await clearSession();
    setState({ user: null, accessToken: null, loading: false, isAuthenticated: false });
    router.replace("/auth/login");
  }, [domain]);

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout, getValidToken }}>
      {children}
    </AuthContext.Provider>
  );
}

// ── Hooks ─────────────────────────────────────────────────
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
}

// ── Authenticated fetch helper ────────────────────────────
// Use this instead of raw fetch for all authenticated API calls
export function useAuthFetch() {
  const { getValidToken, logout } = useAuth();

  return useCallback(async (url: string, opts: RequestInit = {}): Promise<Response> => {
    const token = await getValidToken();
    if (!token) { await logout(); throw new Error("Sessão expirada"); }

    const res = await fetch(url, {
      ...opts,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        ...opts.headers,
      },
    });

    if (res.status === 401) { await logout(); throw new Error("Sessão expirada"); }
    return res;
  }, [getValidToken, logout]);
}

// ── Helpers ───────────────────────────────────────────────
async function saveSession(access: string, refresh: string, user: AuthUser) {
  await Promise.all([
    SecureStore.setItemAsync(KEYS.ACCESS,  access),
    SecureStore.setItemAsync(KEYS.REFRESH, refresh),
    SecureStore.setItemAsync(KEYS.USER,    JSON.stringify(user)),
  ]);
}

async function clearSession() {
  await Promise.all([
    SecureStore.deleteItemAsync(KEYS.ACCESS).catch(() => {}),
    SecureStore.deleteItemAsync(KEYS.REFRESH).catch(() => {}),
    SecureStore.deleteItemAsync(KEYS.USER).catch(() => {}),
  ]);
}
