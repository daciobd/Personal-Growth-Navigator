// lib/db/src/schema/users.ts

import {
  pgTable, serial, text, boolean, timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id:           serial("id").primaryKey(),
  email:        text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name:         text("name").notNull(),
  // deviceId anônimo vinculado na migração
  deviceId:     text("device_id").unique(),
  isTherapist:  boolean("is_therapist").notNull().default(false),
  isAdmin:      boolean("is_admin").notNull().default(false),
  createdAt:    timestamp("created_at").defaultNow().notNull(),
  lastLoginAt:  timestamp("last_login_at"),
});

export const refreshTokensTable = pgTable("refresh_tokens", {
  id:        serial("id").primaryKey(),
  userId:    serial("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  token:     text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(usersTable)
  .omit({ id: true, createdAt: true, lastLoginAt: true });

export type User        = typeof usersTable.$inferSelect;
export type InsertUser  = z.infer<typeof insertUserSchema>;
