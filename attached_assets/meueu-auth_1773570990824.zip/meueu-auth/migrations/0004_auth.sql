-- migrations/0004_auth.sql
-- Execute: pnpm --filter @workspace/db db:push
-- Ou cole no SQL do Replit (aba Database)

CREATE TABLE IF NOT EXISTS users (
  id              SERIAL PRIMARY KEY,
  email           TEXT        NOT NULL UNIQUE,
  password_hash   TEXT        NOT NULL,
  name            TEXT        NOT NULL,
  device_id       TEXT        UNIQUE,
  is_therapist    BOOLEAN     NOT NULL DEFAULT false,
  is_admin        BOOLEAN     NOT NULL DEFAULT false,
  created_at      TIMESTAMP   NOT NULL DEFAULT NOW(),
  last_login_at   TIMESTAMP
);

CREATE INDEX IF NOT EXISTS users_email     ON users (email);
CREATE INDEX IF NOT EXISTS users_device_id ON users (device_id);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token       TEXT        NOT NULL UNIQUE,
  expires_at  TIMESTAMP   NOT NULL,
  created_at  TIMESTAMP   NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS refresh_tokens_token   ON refresh_tokens (token);
CREATE INDEX IF NOT EXISTS refresh_tokens_user_id ON refresh_tokens (user_id);

-- Adiciona JWT_SECRET ao ambiente se não existir (lembrete)
-- No Replit: adicione JWT_SECRET nos Secrets
