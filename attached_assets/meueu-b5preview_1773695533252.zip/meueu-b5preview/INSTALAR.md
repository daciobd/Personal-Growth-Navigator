# Big Five Live Preview — Guia de Instalação

## O que este pacote adiciona

Prévia em tempo real do perfil Big Five conforme o usuário seleciona adjetivos —
sem precisar responder ao questionário de 120 itens.

### Como funciona
1. Usuário seleciona adjetivos (eu hoje + eu futuro)
2. Cada adjetivo tem pesos de carga fatorial para facetas Big Five (Goldberg 1992)
3. O algoritmo soma e normaliza os pesos → score 0-100 por dimensão e faceta
4. O radar SVG atualiza em tempo real
5. Barra de confiança mostra a precisão da estimativa (aumenta com mais adjetivos)
6. CTA convida para o teste completo (120 itens) ao final

---

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `artifacts/meueu/data/adjectiveBig5Map.ts` | idem | Criar |
| `artifacts/meueu/data/big5Estimator.ts` | idem | Criar |
| `artifacts/meueu/components/Big5LivePreview.tsx` | idem | Criar |

---

## Integração nas telas de adjetivos

### Em `onboarding/current.tsx` (Eu Hoje)
```tsx
import Big5LivePreview from '../../components/Big5LivePreview';

// No final da tela, após a grade de adjetivos:
<Big5LivePreview
  currentAdjectives={selectedAdjectives}
  compact={selectedAdjectives.length < 5}
/>
```

### Em `onboarding/future.tsx` (Eu Futuro)
```tsx
import Big5LivePreview from '../../components/Big5LivePreview';

// Passa tanto os adjetivos atuais (do AsyncStorage) quanto os futuros:
<Big5LivePreview
  currentAdjectives={currentAdjectives}   // carregados do AsyncStorage
  futureAdjectives={selectedAdjectives}   // selecionados nesta tela
  compact={false}
/>
```

### Carregar adjetivos atuais no futuro:
```tsx
const [currentAdj, setCurrentAdj] = useState<string[]>([]);
useEffect(() => {
  AsyncStorage.getItem('@meueu_current_adjectives').then(raw => {
    if (raw) setCurrentAdj(JSON.parse(raw));
  });
}, []);
```

---

## Usar estimativa no plano (quando não há Big Five completo)

Em `hooks/usePlanGeneration.ts`, o hook já tenta carregar `@meueu_assessments`.
Se não encontrar, adicione o fallback com a estimativa:

```typescript
// Após tentar carregar Big Five completo:
if (!big5Scores) {
  const currentRaw = await AsyncStorage.getItem('@meueu_current_adjectives');
  const futureRaw  = await AsyncStorage.getItem('@meueu_future_adjectives');
  const current = currentRaw ? JSON.parse(currentRaw) : [];
  const future  = futureRaw  ? JSON.parse(futureRaw)  : [];

  const { estimateB5FromAdjectives } = await import('../data/big5Estimator');
  const estimate = estimateB5FromAdjectives(current, future);
  if (estimate && estimate.confidence >= 30) {
    big5Scores = { dims: estimate.dims, facets: estimate.facets };
  }
}
```

Isso garante que o plano já é personalizado mesmo sem o teste completo.

---

## Comportamento da barra de confiança

| Adjetivos mapeados | Confiança | Label |
|-------------------|-----------|-------|
| 3-4 | < 20% | muito baixa |
| 5-7 | 20-40% | baixa |
| 8-12 | 40-60% | moderada |
| 13-17 | 60-80% | boa |
| 18+ | > 80% | alta |

A confiança combina quantidade de adjetivos (60%) com cobertura de dimensões (40%).
Um usuário que seleciona adjetivos variados de categorias diferentes atinge
confiança "boa" com apenas 10-12 adjetivos.

---

## Adjetivos mapeados (80 total)

**Negativos (eu hoje):** ansioso, tenso, triste, irritável, vazio, inseguro,
culpado, ressentido, sobrecarregado, volátil, melancólico, frágil, pessimista,
autocrítico, perfeccionista, rígido, indeciso, catastrofizante, confuso,
comparativo, limitado, ruminante, impulsivo, tímido, solitário, fechado,
dependente, submisso, desconfiante, distante, controlador, ciumento, retraído,
agressivo, evitativo, procrastinador, agitado, passivo, conformado, desmotivado,
acelerado, desorganizado, negligente, reativo, perdido, sem propósito,
superficial, materialista, ingrato, egoísta, inflexível, desengajado,
desconectado, inauténtico, indiferente

**Positivos (eu futuro):** calmo, sereno, equilibrado, corajoso, resiliente,
inteiro, leve, grato, esperançoso, entusiasmado, focado, claro, inteligente,
criativo, curioso, sábio, reflexivo, realista, inovador, estratégico, empático,
caloroso, generoso, conectado, assertivo, comunicativo, colaborativo, inspirador,
confiável, presente, disciplinado, consistente, produtivo, proativo, organizado,
perseverante, coerente, determinado, ativo, livre, autêntico, íntegro,
propositado, pleno, compassivo, justo, espiritual, comprometido, confiante,
forte, expansivo, realizado, transformado
