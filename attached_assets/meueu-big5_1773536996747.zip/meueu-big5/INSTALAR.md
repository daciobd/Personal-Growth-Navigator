# MeuEu Big Five — Guia de Instalação

## O que este pacote adiciona

- **120 itens IPIP-NEO-120** em português clínico, paginados (12 páginas × 10 itens)
- **Scoring** das 5 dimensões + 30 facetas (percentuais 0–100)
- **Radar/spider chart** nativo (react-native-svg) com comparativo de avaliações
- **Tela de resultado** com radar + facetas + interpretação por IA
- **Reavaliação mensal** com indicador de quando está disponível
- **Big Five integrado ao plano** — prompt do Claude enriquecido com perfil completo
- **Hook `usePlanGeneration`** — passa Big Five automaticamente quando disponível

---

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `artifacts/meueu/data/big5.ts` | `artifacts/meueu/data/big5.ts` | Criar |
| `artifacts/meueu/components/RadarChart.tsx` | `artifacts/meueu/components/RadarChart.tsx` | Criar |
| `artifacts/meueu/components/AssessmentEntry.tsx` | `artifacts/meueu/components/AssessmentEntry.tsx` | Criar |
| `artifacts/meueu/app/assessment/result.tsx` | `artifacts/meueu/app/assessment/result.tsx` | Criar |
| `artifacts/meueu/hooks/usePlanGeneration.ts` | `artifacts/meueu/hooks/usePlanGeneration.ts` | Criar |
| `artifacts/api-server/src/routes/plan.ts` | `artifacts/api-server/src/routes/plan.ts` | **Substituir** |
| `artifacts/api-server/src/routes/assessment.ts` | Integrar ao existente | Adicionar endpoint `/interpret` |

> A tela `/assessment/index.tsx` (120 itens) foi entregue no `meueu-clinical.zip` anterior.
> Se ainda não instalou, crie `artifacts/meueu/app/assessment/index.tsx` com o conteúdo daquele pacote.

---

## Passo a passo

### 1. Instalar react-native-svg (se não tiver)
```bash
pnpm --filter @workspace/meueu add react-native-svg
```

### 2. Adicionar AssessmentEntry na tab Perfil
Em `artifacts/meueu/app/(tabs)/profile.tsx`:
```tsx
import AssessmentEntry from "../../components/AssessmentEntry";

// No ScrollView, logo após os cards de stats:
<AssessmentEntry />
```

### 3. Substituir o plan.ts no api-server
O novo `plan.ts` é totalmente retrocompatível. Se `big5Scores` não vier no body, gera o plano só com adjetivos (comportamento atual preservado).

### 4. Adicionar endpoint /interpret no assessment.ts
No arquivo `artifacts/api-server/src/routes/assessment.ts` existente, adicione o router `POST /interpret` do arquivo `assessment.ts` deste pacote.

Ou registre como rota separada em `routes/index.ts`:
```typescript
import assessmentRouter from "./assessment.js";
router.use("/assessment", assessmentRouter);
```

### 5. Usar o hook usePlanGeneration
Substitua as chamadas diretas a `fetch('/api/plan/generate')` pelo hook:

```tsx
import { usePlanGeneration } from "../../hooks/usePlanGeneration";

const { generate, loading, error } = usePlanGeneration();

// Na tela de onboarding/plan:
const plan = await generate(currentAdjectives, futureAdjectives);
// O hook carrega automaticamente os scores Big Five do AsyncStorage
```

---

## Fluxo completo

```
Tab Perfil
  └── AssessmentEntry (sem avaliação) → botão "Iniciar"
        └── /assessment (120 itens, 12 páginas)
              └── /assessment/result (radar + facetas + IA)
                    └── Salva em @meueu_assessments + banco
                          └── Na próxima geração de plano:
                                usePlanGeneration lê do AsyncStorage
                                e passa big5Scores para /api/plan/generate
                                → Claude recebe perfil Big Five completo

Tab Perfil (com avaliação)
  └── AssessmentEntry mostra mini radar
        └── "Ver detalhes" → /assessment/result
        └── "Reavaliar" (disponível após 28 dias)
```

---

## Formato dos scores em AsyncStorage

`@meueu_assessments` = array de objetos:
```json
[
  {
    "scores": {
      "dims": { "N": 72, "E": 45, "O": 68, "A": 55, "C": 40 },
      "facets": { "N1": 78, "N2": 65, "N3": 70, ... }
    },
    "date": "2025-01-15T10:30:00.000Z"
  }
]
```

Máximo de 12 avaliações armazenadas (1 por mês × 1 ano).
