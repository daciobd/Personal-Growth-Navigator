// artifacts/api-server/src/routes/assessment.ts
// Adicionar este endpoint ao arquivo assessment.ts existente (ou criar novo):
//
// POST /api/assessment/interpret — gera interpretação textual via IA
// (Os outros endpoints já foram entregues no pacote meueu-clinical.zip)

import { Router } from "express";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { db } from "@workspace/db";
import { assessmentsTable } from "@workspace/db/schema";
import { eq, desc, count } from "drizzle-orm";

const router = Router();

const DIM_NAMES: Record<string, string> = {
  N: "Neuroticismo", E: "Extroversão", O: "Abertura",
  A: "Amabilidade",  C: "Conscienciosidade",
};

function levelLabel(p: number): string {
  if (p < 20) return "muito baixo";
  if (p < 35) return "baixo";
  if (p < 50) return "moderado-baixo";
  if (p < 65) return "moderado";
  if (p < 80) return "alto";
  return "muito alto";
}

// ── POST /api/assessment/interpret ────────────────────────
router.post("/interpret", async (req, res) => {
  const { scores } = req.body as {
    scores: {
      dims: Record<string, number>;
      facets: Record<string, number>;
    };
  };

  if (!scores?.dims) {
    res.status(400).json({ error: "scores obrigatório" });
    return;
  }

  const dimLines = ["N","E","O","A","C"].map(d =>
    `${DIM_NAMES[d]}: ${scores.dims[d]}% (${levelLabel(scores.dims[d])})`
  ).join(", ");

  const prompt = `Você é um psicólogo clínico especializado em avaliação de personalidade pelo modelo Big Five.

Perfil Big Five de um cliente:
${dimLines}

Escreva uma interpretação personalizada em JSON:
{
  "geral": "2-3 frases descrevendo o estilo de funcionamento geral desta pessoa com base no perfil. Tom: profissional, acolhedor e sem julgamento.",
  "destaques": "1-2 frases sobre os pontos mais marcantes do perfil — quais dimensões são mais salientes e o que isso significa na prática.",
  "oportunidades": "1-2 frases sobre as áreas com maior potencial de desenvolvimento pessoal, baseadas nas dimensões mais baixas ou contrastes do perfil."
}

REGRAS:
- Use português brasileiro natural
- Evite linguagem técnica excessiva
- Seja específico sobre ESTE perfil, não genérico
- Responda APENAS com JSON válido`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 600,
      messages: [{ role: "user", content: prompt }],
    });

    const raw = message.content[0].type === "text" ? message.content[0].text : "";
    const match = raw.match(/\{[\s\S]*\}/);
    const interpretation = match ? JSON.parse(match[0]) : {
      geral: "Seu perfil revela um padrão único de personalidade.",
      destaques: "Cada dimensão contribui para a sua forma de ser no mundo.",
      oportunidades: "Todas as dimensões oferecem espaço para crescimento pessoal.",
    };

    res.json({ success: true, interpretation });
  } catch (err) {
    console.error("Interpret error:", err);
    res.status(500).json({ error: "Erro ao gerar interpretação" });
  }
});

// ── POST /api/assessment/save ─────────────────────────────
// (Mantido aqui para referência — o arquivo completo está no meueu-clinical.zip)
router.post("/save", async (req, res) => {
  const {
    deviceId, dims, facets, rawAnswers,
    currentAdjectives, futureAdjectives,
  } = req.body as {
    deviceId: string;
    dims: Record<string, number>;
    facets: Record<string, number>;
    rawAnswers?: Record<string, number>;
    currentAdjectives?: string[];
    futureAdjectives?: string[];
  };

  if (!deviceId || !dims) {
    res.status(400).json({ error: "deviceId e dims são obrigatórios" });
    return;
  }

  const [{ count: existing }] = await db
    .select({ count: count() })
    .from(assessmentsTable)
    .where(eq(assessmentsTable.deviceId, deviceId));

  const assessmentNumber = Number(existing) + 1;
  const monthLabel = new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  const [saved] = await db.insert(assessmentsTable).values({
    deviceId,
    scoreN: dims.N ?? 50,
    scoreE: dims.E ?? 50,
    scoreO: dims.O ?? 50,
    scoreA: dims.A ?? 50,
    scoreC: dims.C ?? 50,
    facetScores: facets ?? {},
    rawAnswers: rawAnswers ?? null,
    currentAdjectives: currentAdjectives ?? null,
    futureAdjectives: futureAdjectives ?? null,
    assessmentNumber,
    periodLabel: monthLabel,
  }).returning();

  res.json({ success: true, assessmentId: saved.id, assessmentNumber });
});

// ── GET /api/assessment/history/:deviceId ─────────────────
router.get("/history/:deviceId", async (req, res) => {
  const rows = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.deviceId, req.params.deviceId))
    .orderBy(assessmentsTable.createdAt);

  res.json({ assessments: rows });
});

export default router;
