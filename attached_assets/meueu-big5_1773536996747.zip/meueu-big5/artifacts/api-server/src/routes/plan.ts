// artifacts/api-server/src/routes/plan.ts
// Versão atualizada: aceita scores Big Five opcionais e os integra ao prompt.
// Se big5Scores não vier, gera o plano só com adjetivos (compatibilidade total).

import { Router, type IRouter } from "express";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { db } from "@workspace/db";
import { planLogsTable } from "@workspace/db/schema";

const router: IRouter = Router();

// ── Helpers ───────────────────────────────────────────────
type DimKey = "N" | "E" | "O" | "A" | "C";
const DIM_NAMES: Record<DimKey, string> = {
  N: "Neuroticismo", E: "Extroversão", O: "Abertura",
  A: "Amabilidade",  C: "Conscienciosidade",
};
const FACET_NAMES: Record<string, string> = {
  N1:"Ansiedade", N2:"Hostilidade", N3:"Depressão", N4:"Autoconsciência", N5:"Impulsividade", N6:"Vulnerabilidade",
  E1:"Cordialidade", E2:"Gregarismo", E3:"Assertividade", E4:"Atividade", E5:"Busca de excitação", E6:"Emoções positivas",
  O1:"Fantasia", O2:"Estética", O3:"Sentimentos", O4:"Ações", O5:"Ideias", O6:"Valores",
  A1:"Confiança", A2:"Franqueza", A3:"Altruísmo", A4:"Complacência", A5:"Modéstia", A6:"Sensibilidade",
  C1:"Competência", C2:"Ordem", C3:"Senso de dever", C4:"Realização", C5:"Autodisciplina", C6:"Deliberação",
};

function levelLabel(p: number): string {
  if (p < 20) return "muito baixo";
  if (p < 35) return "baixo";
  if (p < 50) return "moderado-baixo";
  if (p < 65) return "moderado";
  if (p < 80) return "alto";
  return "muito alto";
}

function buildBig5Block(
  dims: Record<string, number>,
  facets: Record<string, number>
): string {
  const lines = (["N","E","O","A","C"] as DimKey[]).map(d => {
    const pct = dims[d] ?? 50;
    // Top 2 facets for this dimension
    const dimFacets = Object.entries(facets)
      .filter(([k]) => k.startsWith(d))
      .sort((a, b) => b[1] - a[1])
      .slice(0, 2)
      .map(([k, v]) => `${FACET_NAMES[k] ?? k}:${v}%`)
      .join(", ");
    return `  ${DIM_NAMES[d]}: ${pct}% (${levelLabel(pct)}) | facetas elevadas: ${dimFacets}`;
  });

  return `PERFIL DE PERSONALIDADE Big Five (IPIP-NEO-120):
${lines.join("\n")}`;
}

// ── Route ─────────────────────────────────────────────────
router.post("/plan/generate", async (req, res) => {
  const { currentAdjectives, futureAdjectives, big5Scores } = req.body as {
    currentAdjectives: string[];
    futureAdjectives: string[];
    big5Scores?: {
      dims: Record<string, number>;
      facets: Record<string, number>;
    };
  };

  if (!Array.isArray(currentAdjectives) || !Array.isArray(futureAdjectives)) {
    res.status(400).json({ error: "currentAdjectives e futureAdjectives são obrigatórios" });
    return;
  }

  // ── Monta o bloco de perfil ──────────────────────────────
  const profileBlock = big5Scores
    ? buildBig5Block(big5Scores.dims, big5Scores.facets)
    : null;

  const prompt = `Você é um psicólogo especializado em psicoterapias baseadas em evidências (TCC, ACT, Psicologia Positiva, Mindfulness/DBT).

${profileBlock ? profileBlock + "\n\n" : ""}EU HOJE (adjetivos que descrevem o cliente atualmente):
${currentAdjectives.join(", ")}

EU FUTURO (adjetivos que descrevem quem o cliente quer se tornar):
${futureAdjectives.join(", ")}

Com base ${profileBlock ? "no perfil Big Five e " : ""}nessas informações, gere um plano personalizado em JSON:

{
  "sintese": "Síntese narrativa de 2-3 frases sobre a jornada de transformação${profileBlock ? ", conectando as dimensões do Big Five" : ""}. Empática, esperançosa e profissional.",
  "fraseIntencao": "Frase de intenção começando com 'Eu escolho...' ou 'Eu me comprometo...'",
  "praticas": [
    {
      "abordagem": "TCC",
      "nome": "Nome da técnica",
      "justificativa": "Por que esta técnica é relevante para ESTE perfil${profileBlock ? " (mencione dimensões ou facetas específicas)" : ""}.",
      "passos": ["Passo 1", "Passo 2", "Passo 3", "Passo 4"],
      "frequencia": "Sugestão prática"
    },
    { "abordagem": "ACT", "nome": "...", "justificativa": "...", "passos": ["..."], "frequencia": "..." },
    { "abordagem": "Psicologia Positiva", "nome": "...", "justificativa": "...", "passos": ["..."], "frequencia": "..." }
  ]
}

REGRAS:
- 3 práticas de abordagens DIFERENTES (TCC, ACT, Psicologia Positiva)
- Passos concretos e acionáveis
- Use a segunda pessoa ("você")
${profileBlock ? "- As práticas devem endereçar as dimensões mais elevadas/baixas do perfil Big Five\n" : ""}- Responda APENAS com JSON válido`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 2048,
      messages: [{ role: "user", content: prompt }],
    });

    const rawText = message.content[0].type === "text" ? message.content[0].text : "";
    let planData;
    try {
      const match = rawText.match(/\{[\s\S]*\}/);
      planData = match ? JSON.parse(match[0]) : { rawText, parseError: true };
    } catch {
      planData = { rawText, parseError: true };
    }

    // Log (non-blocking)
    db.insert(planLogsTable).values({
      currentAdjectives, futureAdjectives, plan: planData,
    }).catch(err => console.error("Log error:", err));

    res.json({ success: true, plan: planData, hasBig5: !!big5Scores });
  } catch (err) {
    console.error("Plan generation error:", err);
    res.status(500).json({ error: "Erro ao gerar plano. Tente novamente." });
  }
});

export default router;
