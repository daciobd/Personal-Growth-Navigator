// artifacts/meueu/app/assessment/result.tsx
// Tela de resultado do Big Five:
//   • Radar chart das 5 dimensões
//   • Barras das 30 facetas por dimensão
//   • Interpretação textual gerada pela IA
//
// Parâmetros recebidos via router.replace:
//   scores: JSON.stringify({ dims: {...}, facets: {...} })

import React, { useState, useEffect } from "react";
import {
  View, Text, StyleSheet, ScrollView,
  ActivityIndicator, Pressable,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import RadarChart from "../../components/RadarChart";
import {
  DIMENSIONS, FACETS, levelLabel,
  type B5Scores, type DimKey,
} from "../../data/big5";

type AIInterpretation = {
  geral: string;
  destaques: string;
  oportunidades: string;
};

export default function AssessmentResult() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ scores: string }>();
  const [scores, setScores] = useState<B5Scores | null>(null);
  const [previous, setPrevious] = useState<Record<DimKey, number> | undefined>();
  const [interpretation, setInterpretation] = useState<AIInterpretation | null>(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [activeTab, setActiveTab] = useState<"radar" | "facets">("radar");

  // Parse scores from params
  useEffect(() => {
    if (params.scores) {
      try {
        const parsed = JSON.parse(params.scores) as B5Scores;
        setScores(parsed);
        loadPreviousAndGenerateInterpretation(parsed);
      } catch {}
    }
  }, [params.scores]);

  async function loadPreviousAndGenerateInterpretation(current: B5Scores) {
    // Load previous assessment for comparison
    try {
      const raw = await AsyncStorage.getItem("@meueu_assessments");
      const all = raw ? JSON.parse(raw) as Array<{ scores: B5Scores; date: string }> : [];
      // Previous = second to last (last was just saved)
      if (all.length >= 2) {
        setPrevious(all[all.length - 2].scores.dims);
      }
    } catch {}

    // Generate AI interpretation
    setLoadingAI(true);
    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      if (!domain) return;
      const res = await fetch(`${domain}/api/assessment/interpret`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scores: current }),
      });
      const data = await res.json();
      if (data.interpretation) setInterpretation(data.interpretation);
    } catch {} finally {
      setLoadingAI(false);
    }
  }

  if (!scores) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top }]}>
        <ActivityIndicator color="#1B6B5A" style={{ flex: 1 }} />
      </View>
    );
  }

  const dims = (["N","E","O","A","C"] as DimKey[]);

  return (
    <View style={[styles.screen, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Seu perfil Big Five</Text>
          <Text style={styles.headerSub}>IPIP-NEO-120 · {new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</Text>
        </View>
        <Pressable
          style={styles.doneBtn}
          onPress={() => router.replace("/(tabs)")}>
          <Text style={styles.doneBtnText}>Concluir</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Tab switch */}
        <View style={styles.tabRow}>
          {(["radar", "facets"] as const).map(t => (
            <Pressable
              key={t}
              style={[styles.tab, activeTab === t && styles.tabActive]}
              onPress={() => setActiveTab(t)}>
              <Text style={[styles.tabText, activeTab === t && styles.tabTextActive]}>
                {t === "radar" ? "Visão geral" : "30 Facetas"}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* RADAR TAB */}
        {activeTab === "radar" && (
          <>
            <View style={styles.radarCard}>
              <View style={styles.radarWrap}>
                <RadarChart
                  scores={scores.dims}
                  previous={previous}
                  size={260}
                />
              </View>
              {previous && (
                <View style={styles.compareHint}>
                  <View style={styles.compareHintDash} />
                  <Text style={styles.compareHintText}>Linha tracejada = avaliação anterior</Text>
                </View>
              )}
            </View>

            {/* Dimension cards */}
            {dims.map(d => {
              const info = DIMENSIONS.find(x => x.key === d)!;
              const pct  = scores.dims[d];
              const isHigh = pct >= 65;
              return (
                <View key={d} style={styles.dimCard}>
                  <View style={styles.dimRow}>
                    <View style={[styles.dimDot, { backgroundColor: info.color }]} />
                    <Text style={styles.dimLabel}>{info.label}</Text>
                    <Text style={[styles.dimPct, { color: info.color }]}>
                      {pct}% · {levelLabel(pct)}
                    </Text>
                  </View>
                  <View style={styles.dimBarBg}>
                    <View style={[styles.dimBarFill, { width: `${pct}%` as `${number}%`, backgroundColor: info.color }]} />
                  </View>
                  <Text style={styles.dimDesc}>
                    {isHigh ? info.highDesc : info.lowDesc}
                  </Text>
                </View>
              );
            })}

            {/* AI Interpretation */}
            <View style={styles.aiCard}>
              <View style={styles.aiHeader}>
                <Feather name="cpu" size={14} color="#1B6B5A" />
                <Text style={styles.aiTitle}>Interpretação personalizada</Text>
              </View>
              {loadingAI ? (
                <View style={styles.aiLoading}>
                  <ActivityIndicator size="small" color="#1B6B5A" />
                  <Text style={styles.aiLoadingText}>Gerando análise do seu perfil…</Text>
                </View>
              ) : interpretation ? (
                <>
                  <Text style={styles.aiSection}>Visão geral</Text>
                  <Text style={styles.aiText}>{interpretation.geral}</Text>
                  <Text style={styles.aiSection}>Pontos de destaque</Text>
                  <Text style={styles.aiText}>{interpretation.destaques}</Text>
                  <Text style={styles.aiSection}>Oportunidades de crescimento</Text>
                  <Text style={styles.aiText}>{interpretation.oportunidades}</Text>
                </>
              ) : (
                <Text style={styles.aiText}>
                  Conecte ao servidor para gerar sua interpretação personalizada.
                </Text>
              )}
            </View>
          </>
        )}

        {/* FACETS TAB */}
        {activeTab === "facets" && dims.map(d => {
          const info = DIMENSIONS.find(x => x.key === d)!;
          const facets = FACETS.filter(f => f.dim === d);
          return (
            <View key={d} style={styles.facetSection}>
              <View style={styles.facetSectionHeader}>
                <View style={[styles.dimDot, { backgroundColor: info.color }]} />
                <Text style={styles.facetSectionTitle}>{info.label}</Text>
                <Text style={[styles.dimPct, { color: info.color }]}>{scores.dims[d]}%</Text>
              </View>
              {facets.map(fc => {
                const pct = scores.facets[fc.key] ?? 0;
                return (
                  <View key={fc.key} style={styles.facetRow}>
                    <Text style={styles.facetLabel}>{fc.label}</Text>
                    <View style={styles.facetBarBg}>
                      <View style={[styles.facetBarFill, {
                        width: `${pct}%` as `${number}%`,
                        backgroundColor: info.color,
                        opacity: 0.7 + pct / 333,
                      }]} />
                    </View>
                    <Text style={[styles.facetPct, { color: info.color }]}>{pct}%</Text>
                  </View>
                );
              })}
            </View>
          );
        })}

        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F5F8F6" },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: "#fff", borderBottomWidth: 1, borderBottomColor: "#E8F0ED", paddingHorizontal: 20, paddingVertical: 14 },
  headerTitle: { fontSize: 17, fontWeight: "700", color: "#0F1F1B" },
  headerSub: { fontSize: 12, color: "#6B8F7E", marginTop: 1 },
  doneBtn: { backgroundColor: "#1B6B5A", paddingHorizontal: 18, paddingVertical: 8, borderRadius: 20 },
  doneBtnText: { color: "#fff", fontSize: 13, fontWeight: "700" },
  content: { padding: 16 },
  tabRow: { flexDirection: "row", backgroundColor: "#E8F5F1", borderRadius: 12, padding: 3, marginBottom: 16 },
  tab: { flex: 1, paddingVertical: 8, alignItems: "center", borderRadius: 10 },
  tabActive: { backgroundColor: "#fff" },
  tabText: { fontSize: 13, fontWeight: "600", color: "#6B8F7E" },
  tabTextActive: { color: "#0F1F1B" },
  radarCard: { backgroundColor: "#fff", borderRadius: 16, padding: 16, alignItems: "center", borderWidth: 1, borderColor: "#E8F0ED", marginBottom: 12 },
  radarWrap: { alignItems: "center" },
  compareHint: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8 },
  compareHintDash: { width: 20, height: 1.5, backgroundColor: "#6B8F7E", borderStyle: "dashed" },
  compareHintText: { fontSize: 11, color: "#6B8F7E" },
  dimCard: { backgroundColor: "#fff", borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: "#E8F0ED" },
  dimRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 },
  dimDot: { width: 10, height: 10, borderRadius: 5 },
  dimLabel: { flex: 1, fontSize: 14, fontWeight: "700", color: "#0F1F1B" },
  dimPct: { fontSize: 12, fontWeight: "600" },
  dimBarBg: { height: 6, backgroundColor: "#F0FAF5", borderRadius: 3, overflow: "hidden", marginBottom: 8 },
  dimBarFill: { height: "100%", borderRadius: 3 },
  dimDesc: { fontSize: 12, color: "#6B8F7E", lineHeight: 18 },
  aiCard: { backgroundColor: "#fff", borderRadius: 14, padding: 18, borderWidth: 1, borderColor: "#E8F0ED", marginTop: 4 },
  aiHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 14 },
  aiTitle: { fontSize: 14, fontWeight: "700", color: "#0F1F1B" },
  aiLoading: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 16 },
  aiLoadingText: { fontSize: 13, color: "#6B8F7E" },
  aiSection: { fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8, color: "#1B6B5A", marginBottom: 6, marginTop: 12 },
  aiText: { fontSize: 13, color: "#3D5A52", lineHeight: 21 },
  facetSection: { backgroundColor: "#fff", borderRadius: 14, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: "#E8F0ED" },
  facetSectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 14 },
  facetSectionTitle: { flex: 1, fontSize: 15, fontWeight: "700", color: "#0F1F1B" },
  facetRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8 },
  facetLabel: { width: 120, fontSize: 12, color: "#3D5A52", fontWeight: "500" },
  facetBarBg: { flex: 1, height: 5, backgroundColor: "#E8F5F1", borderRadius: 3, overflow: "hidden" },
  facetBarFill: { height: "100%", borderRadius: 3 },
  facetPct: { width: 32, fontSize: 11, fontWeight: "700", textAlign: "right" },
});
