// artifacts/meueu/components/AssessmentEntry.tsx
// Card na tab de Perfil que mostra o status da avaliação Big Five
// e permite iniciar ou refazer.

import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import RadarChart from "./RadarChart";
import { type B5Scores, type DimKey } from "../data/big5";

export default function AssessmentEntry() {
  const [lastAssessment, setLastAssessment] = useState<{
    scores: B5Scores;
    date: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem("@meueu_assessments").then(raw => {
      if (raw) {
        const all = JSON.parse(raw) as Array<{ scores: B5Scores; date: string }>;
        if (all.length > 0) setLastAssessment(all[all.length - 1]);
      }
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return null;

  // Sem avaliação ainda
  if (!lastAssessment) {
    return (
      <View style={styles.card}>
        <View style={styles.iconRow}>
          <View style={styles.iconWrap}>
            <Feather name="bar-chart-2" size={20} color="#1B6B5A" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>Avaliação de Personalidade</Text>
            <Text style={styles.sub}>Big Five · IPIP-NEO-120 · ~15 min</Text>
          </View>
        </View>
        <Text style={styles.desc}>
          Descubra seu perfil em 5 dimensões e 30 facetas. Os resultados enriquecem seu plano personalizado.
        </Text>
        <View style={styles.pillRow}>
          {["Neuroticismo","Extroversão","Abertura","Amabilidade","Conscienciosidade"].map(d => (
            <View key={d} style={styles.pill}>
              <Text style={styles.pillText}>{d.slice(0,3)}</Text>
            </View>
          ))}
        </View>
        <Pressable
          style={styles.startBtn}
          onPress={() => router.push("/assessment")}>
          <Text style={styles.startBtnText}>Iniciar avaliação</Text>
          <Feather name="arrow-right" size={16} color="#fff" />
        </Pressable>
      </View>
    );
  }

  // Com avaliação — mostra mini radar + data + botão de reavaliação
  const daysSince = Math.floor(
    (Date.now() - new Date(lastAssessment.date).getTime()) / 86400000
  );
  const canRetake = daysSince >= 28;
  const dateLabel = new Date(lastAssessment.date).toLocaleDateString("pt-BR", {
    day: "numeric", month: "long", year: "numeric",
  });

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.title}>Perfil Big Five</Text>
          <Text style={styles.dateLabel}>{dateLabel}</Text>
        </View>
        <Pressable
          style={styles.viewBtn}
          onPress={() => router.push({
            pathname: "/assessment/result",
            params: { scores: JSON.stringify(lastAssessment.scores) },
          })}>
          <Text style={styles.viewBtnText}>Ver detalhes</Text>
          <Feather name="chevron-right" size={14} color="#1B6B5A" />
        </Pressable>
      </View>

      <View style={styles.radarRow}>
        <RadarChart
          scores={lastAssessment.scores.dims}
          size={180}
          showLabels
        />
      </View>

      {canRetake ? (
        <Pressable
          style={styles.retakeBtn}
          onPress={() => router.push("/assessment")}>
          <Feather name="refresh-cw" size={14} color="#1B6B5A" />
          <Text style={styles.retakeBtnText}>Reavaliar (30 dias se passaram)</Text>
        </Pressable>
      ) : (
        <View style={styles.nextRetakeRow}>
          <Feather name="clock" size={13} color="#6B8F7E" />
          <Text style={styles.nextRetakeText}>
            Próxima reavaliação em {28 - daysSince} dias
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: "#fff", borderRadius: 16, padding: 18, borderWidth: 1, borderColor: "#E8F0ED", marginBottom: 16 },
  iconRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 12 },
  iconWrap: { width: 40, height: 40, borderRadius: 20, backgroundColor: "#E8F5F1", alignItems: "center", justifyContent: "center" },
  title: { fontSize: 16, fontWeight: "700", color: "#0F1F1B" },
  sub: { fontSize: 12, color: "#6B8F7E", marginTop: 1 },
  desc: { fontSize: 13, color: "#6B8F7E", lineHeight: 20, marginBottom: 14 },
  pillRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 14 },
  pill: { backgroundColor: "#F0FAF5", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  pillText: { fontSize: 11, fontWeight: "600", color: "#1B6B5A" },
  startBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#1B6B5A", borderRadius: 12, paddingVertical: 13 },
  startBtnText: { color: "#fff", fontSize: 14, fontWeight: "700" },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 },
  dateLabel: { fontSize: 12, color: "#6B8F7E", marginTop: 2 },
  viewBtn: { flexDirection: "row", alignItems: "center", gap: 3 },
  viewBtnText: { fontSize: 13, color: "#1B6B5A", fontWeight: "600" },
  radarRow: { alignItems: "center", marginBottom: 14 },
  retakeBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, borderWidth: 1.5, borderColor: "#1B6B5A", borderRadius: 10, paddingVertical: 10 },
  retakeBtnText: { fontSize: 13, color: "#1B6B5A", fontWeight: "600" },
  nextRetakeRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  nextRetakeText: { fontSize: 12, color: "#6B8F7E" },
});
