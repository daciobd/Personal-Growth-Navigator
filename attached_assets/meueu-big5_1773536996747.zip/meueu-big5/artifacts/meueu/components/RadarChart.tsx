// artifacts/meueu/components/RadarChart.tsx
// Radar/spider chart das 5 dimensões Big Five.
// Usa react-native-svg nativo — sem WebView, funciona em iOS e Android.

import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Polygon, Line, Circle, Text as SvgText, G } from "react-native-svg";
import { DIMENSIONS, type DimKey } from "../data/big5";

type Props = {
  scores: Record<DimKey, number>; // 0-100 por dimensão
  size?: number;
  showLabels?: boolean;
  showGrid?: boolean;
  previous?: Record<DimKey, number>; // avaliação anterior (opcional)
};

const DIMS: DimKey[] = ["N", "E", "O", "A", "C"];
const ANGLES = DIMS.map((_, i) => (i / DIMS.length) * 2 * Math.PI - Math.PI / 2);

function polarToXY(angle: number, r: number, cx: number, cy: number) {
  return {
    x: cx + r * Math.cos(angle),
    y: cy + r * Math.sin(angle),
  };
}

export default function RadarChart({
  scores,
  size = 260,
  showLabels = true,
  showGrid = true,
  previous,
}: Props) {
  const cx = size / 2;
  const cy = size / 2;
  const maxR = size * 0.36;
  const labelR = size * 0.48;

  // Pontos do polígono principal
  const points = DIMS.map((d, i) => {
    const r = (scores[d] / 100) * maxR;
    return polarToXY(ANGLES[i], r, cx, cy);
  });
  const pointsStr = points.map(p => `${p.x},${p.y}`).join(" ");

  // Polígono da avaliação anterior (se houver)
  const prevPoints = previous
    ? DIMS.map((d, i) => {
        const r = (previous[d] / 100) * maxR;
        return polarToXY(ANGLES[i], r, cx, cy);
      })
    : null;
  const prevPointsStr = prevPoints?.map(p => `${p.x},${p.y}`).join(" ");

  // Grades concêntricas (20, 40, 60, 80, 100%)
  const gridLevels = [20, 40, 60, 80, 100];

  return (
    <View>
      <Svg width={size} height={size}>
        {/* Grid lines from center */}
        {showGrid && DIMS.map((_, i) => {
          const outer = polarToXY(ANGLES[i], maxR, cx, cy);
          return (
            <Line
              key={i}
              x1={cx} y1={cy}
              x2={outer.x} y2={outer.y}
              stroke="#E8F0ED" strokeWidth={1}
            />
          );
        })}

        {/* Concentric grid polygons */}
        {showGrid && gridLevels.map(level => {
          const pts = DIMS.map((_, i) => {
            const r = (level / 100) * maxR;
            const p = polarToXY(ANGLES[i], r, cx, cy);
            return `${p.x},${p.y}`;
          }).join(" ");
          return (
            <Polygon
              key={level}
              points={pts}
              fill="none"
              stroke="#E8F0ED"
              strokeWidth={1}
            />
          );
        })}

        {/* Previous assessment polygon */}
        {prevPointsStr && (
          <Polygon
            points={prevPointsStr}
            fill="rgba(107,143,126,0.1)"
            stroke="#6B8F7E"
            strokeWidth={1.5}
            strokeDasharray="4 3"
          />
        )}

        {/* Main score polygon */}
        <Polygon
          points={pointsStr}
          fill="rgba(27,107,90,0.18)"
          stroke="#1B6B5A"
          strokeWidth={2.5}
        />

        {/* Score dots */}
        {points.map((p, i) => {
          const dim = DIMENSIONS.find(d => d.key === DIMS[i])!;
          return (
            <Circle
              key={i}
              cx={p.x} cy={p.y}
              r={5}
              fill={dim.color}
              stroke="#fff"
              strokeWidth={1.5}
            />
          );
        })}

        {/* Labels */}
        {showLabels && DIMS.map((d, i) => {
          const pos = polarToXY(ANGLES[i], labelR, cx, cy);
          const dim = DIMENSIONS.find(x => x.key === d)!;
          const score = scores[d];

          // Anchor based on position
          let anchor: "start" | "middle" | "end" = "middle";
          const cos = Math.cos(ANGLES[i]);
          if (cos > 0.3) anchor = "start";
          else if (cos < -0.3) anchor = "end";

          return (
            <G key={d}>
              <SvgText
                x={pos.x} y={pos.y - 6}
                textAnchor={anchor}
                fontSize={10} fontWeight="700"
                fill={dim.color}>
                {d}
              </SvgText>
              <SvgText
                x={pos.x} y={pos.y + 8}
                textAnchor={anchor}
                fontSize={9}
                fill="#6B8F7E">
                {score}%
              </SvgText>
            </G>
          );
        })}
      </Svg>

      {/* Legend row */}
      <View style={styles.legend}>
        {DIMENSIONS.map(d => (
          <View key={d.key} style={styles.legendItem}>
            <View style={[styles.dot, { backgroundColor: d.color }]} />
            <Text style={styles.legendLabel}>{d.label.slice(0, 3)}</Text>
            <Text style={[styles.legendScore, { color: d.color }]}>
              {scores[d.key]}%
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  legend: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 8,
    paddingHorizontal: 8,
  },
  legendItem: { alignItems: "center", gap: 3 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  legendLabel: { fontSize: 10, color: "#6B8F7E", fontWeight: "600" },
  legendScore: { fontSize: 11, fontWeight: "700" },
});
