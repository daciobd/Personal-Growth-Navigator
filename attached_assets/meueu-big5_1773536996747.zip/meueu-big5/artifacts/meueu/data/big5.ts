// artifacts/meueu/data/big5.ts
// Motor completo de scoring do IPIP-NEO-120
// 120 itens → 5 dimensões + 30 facetas (percentuais 0–100)

export type DimKey = "N" | "E" | "O" | "A" | "C";

export type B5Item = {
  n: number;
  t: string;
  f: DimKey;
  r: boolean; // reversed
};

export type Facet = {
  key: string;        // ex: "N1"
  dim: DimKey;
  label: string;
  items: number[];    // item numbers (4 per facet)
};

export type DimInfo = {
  key: DimKey;
  label: string;
  color: string;
  lowDesc: string;
  highDesc: string;
};

// ── Dimensões ─────────────────────────────────────────────
export const DIMENSIONS: DimInfo[] = [
  {
    key: "N", label: "Neuroticismo", color: "#C4622D",
    lowDesc: "Emocionalmente estável, calmo e resiliente sob pressão.",
    highDesc: "Tende a experimentar emoções negativas com mais intensidade e frequência.",
  },
  {
    key: "E", label: "Extroversão", color: "#1B6B5A",
    lowDesc: "Reservado, independente e recarrega energia na solitude.",
    highDesc: "Sociável, energético e busca ativamente estimulação externa.",
  },
  {
    key: "O", label: "Abertura", color: "#3A5A8C",
    lowDesc: "Prefere o concreto, valoriza tradições e perspectivas estabelecidas.",
    highDesc: "Curioso, criativo e aberto a novas ideias e experiências.",
  },
  {
    key: "A", label: "Amabilidade", color: "#854F0B",
    lowDesc: "Direto, cético e orientado aos próprios objetivos.",
    highDesc: "Cooperativo, empático e orientado ao bem-estar dos outros.",
  },
  {
    key: "C", label: "Conscienciosidade", color: "#0F6E56",
    lowDesc: "Espontâneo e flexível, prefere não se prender a estruturas rígidas.",
    highDesc: "Organizado, disciplinado e comprometido com qualidade.",
  },
];

// ── 30 Facetas ────────────────────────────────────────────
export const FACETS: Facet[] = [
  // Neuroticismo
  { key:"N1", dim:"N", label:"Ansiedade",        items:[1,23,44,99] },
  { key:"N2", dim:"N", label:"Hostilidade",       items:[6,16,49,94] },
  { key:"N3", dim:"N", label:"Depressão",         items:[11,34,39,119] },
  { key:"N4", dim:"N", label:"Autoconsciência",   items:[28,64,74,104] },
  { key:"N5", dim:"N", label:"Impulsividade",     items:[59,69,79,84] },
  { key:"N6", dim:"N", label:"Vulnerabilidade",   items:[54,89,109,114] },
  // Extroversão
  { key:"E1", dim:"E", label:"Cordialidade",      items:[2,40,72,85] },
  { key:"E2", dim:"E", label:"Gregarismo",        items:[7,17,45,65] },
  { key:"E3", dim:"E", label:"Assertividade",     items:[12,50,55,120] },
  { key:"E4", dim:"E", label:"Atividade",         items:[24,70,80,95] },
  { key:"E5", dim:"E", label:"Busca de excitação",items:[29,75,90,105] },
  { key:"E6", dim:"E", label:"Emoções positivas", items:[35,60,100,115] },
  // Abertura
  { key:"O1", dim:"O", label:"Fantasia",          items:[3,46,86,91] },
  { key:"O2", dim:"O", label:"Estética",          items:[8,36,76,111] },
  { key:"O3", dim:"O", label:"Sentimentos",       items:[13,61,71,116] },
  { key:"O4", dim:"O", label:"Ações",             items:[18,31,56,66] },
  { key:"O5", dim:"O", label:"Ideias",            items:[25,41,51,96] },
  { key:"O6", dim:"O", label:"Valores",           items:[30,81,101,106] },
  // Amabilidade
  { key:"A1", dim:"A", label:"Confiança",         items:[4,14,32,77] },
  { key:"A2", dim:"A", label:"Franqueza",         items:[9,19,37,97] },
  { key:"A3", dim:"A", label:"Altruísmo",         items:[26,47,67,87] },
  { key:"A4", dim:"A", label:"Complacência",      items:[42,62,82,92] },
  { key:"A5", dim:"A", label:"Modéstia",          items:[21,102,110,117] },
  { key:"A6", dim:"A", label:"Sensibilidade",     items:[52,57,107,112] },
  // Conscienciosidade
  { key:"C1", dim:"C", label:"Competência",       items:[5,15,88,103] },
  { key:"C2", dim:"C", label:"Ordem",             items:[10,20,38,83] },
  { key:"C3", dim:"C", label:"Senso de dever",    items:[33,43,93,113] },
  { key:"C4", dim:"C", label:"Realização",        items:[22,48,58,118] },
  { key:"C5", dim:"C", label:"Autodisciplina",    items:[27,73,78,98] },
  { key:"C6", dim:"C", label:"Deliberação",       items:[53,63,68,108] },
];

// ── Itens ─────────────────────────────────────────────────
export const ITEMS: B5Item[] = [
  {n:1,t:"Preocupo-me com muitas coisas",f:"N",r:false},
  {n:2,t:"Faço amizades com facilidade",f:"E",r:false},
  {n:3,t:"Tenho uma imaginação muito vívida",f:"O",r:false},
  {n:4,t:"Confio nas outras pessoas",f:"A",r:false},
  {n:5,t:"Consigo concluir minhas tarefas com sucesso",f:"C",r:false},
  {n:6,t:"Fico com raiva facilmente",f:"N",r:false},
  {n:7,t:"Gosto de festas com muitas pessoas",f:"E",r:false},
  {n:8,t:"Acredito que a arte é importante",f:"O",r:false},
  {n:9,t:"Uso as pessoas para alcançar meus objetivos",f:"A",r:true},
  {n:10,t:"Gosto de manter as coisas organizadas",f:"C",r:false},
  {n:11,t:"Frequentemente me sinto triste",f:"N",r:false},
  {n:12,t:"Costumo assumir a liderança",f:"E",r:false},
  {n:13,t:"Sinto minhas emoções de forma intensa",f:"O",r:false},
  {n:14,t:"Acredito que as pessoas geralmente têm boas intenções",f:"A",r:false},
  {n:15,t:"Sei como fazer as coisas acontecerem",f:"C",r:false},
  {n:16,t:"Irrito-me com facilidade",f:"N",r:false},
  {n:17,t:"Gosto de fazer parte de grupos",f:"E",r:false},
  {n:18,t:"Gosto de ouvir ideias novas",f:"O",r:false},
  {n:19,t:"Manipulo pessoas para conseguir o que quero",f:"A",r:true},
  {n:20,t:"Mantenho as coisas limpas e organizadas",f:"C",r:false},
  {n:21,t:"Sinto-me à vontade perto de outras pessoas",f:"A",r:false},
  {n:22,t:"Sou exigente com a qualidade do meu trabalho",f:"C",r:false},
  {n:23,t:"Fico estressado facilmente",f:"N",r:false},
  {n:24,t:"Sei lidar bem com situações sociais",f:"E",r:false},
  {n:25,t:"Tenho dificuldade para entender ideias abstratas",f:"O",r:true},
  {n:26,t:"Sinto compaixão por quem está em situação pior que a minha",f:"A",r:false},
  {n:27,t:"Costumo desperdiçar meu tempo",f:"C",r:true},
  {n:28,t:"Na maior parte do tempo estou relaxado",f:"N",r:true},
  {n:29,t:"Prefiro ficar sozinho",f:"E",r:true},
  {n:30,t:"Tenho dificuldade para compreender certas coisas",f:"O",r:true},
  {n:31,t:"Não tenho interesse por ideias abstratas",f:"O",r:true},
  {n:32,t:"Demonstro pouca preocupação com os outros",f:"A",r:true},
  {n:33,t:"Evito minhas responsabilidades",f:"C",r:true},
  {n:34,t:"Raramente me sinto triste",f:"N",r:true},
  {n:35,t:"Sou o centro das atenções em festas",f:"E",r:false},
  {n:36,t:"Não gosto de arte",f:"O",r:true},
  {n:37,t:"Trapaceio para conseguir vantagem",f:"A",r:true},
  {n:38,t:"Frequentemente esqueço de guardar as coisas no lugar certo",f:"C",r:true},
  {n:39,t:"Muitas vezes me sinto deprimido",f:"N",r:false},
  {n:40,t:"Sinto-me confortável perto de outras pessoas",f:"E",r:false},
  {n:41,t:"Tenho um vocabulário amplo",f:"O",r:false},
  {n:42,t:"Compreendo os sentimentos dos outros",f:"A",r:false},
  {n:43,t:"Levo meus planos até o fim",f:"C",r:false},
  {n:44,t:"Entro em pânico facilmente",f:"N",r:false},
  {n:45,t:"Evito contato com outras pessoas",f:"E",r:true},
  {n:46,t:"Não tenho muita imaginação",f:"O",r:true},
  {n:47,t:"Dedico tempo para ajudar os outros",f:"A",r:false},
  {n:48,t:"Tenho dificuldade para começar tarefas",f:"C",r:true},
  {n:49,t:"Raramente fico irritado",f:"N",r:true},
  {n:50,t:"Prefiro ficar em segundo plano",f:"E",r:true},
  {n:51,t:"Uso palavras difíceis com frequência",f:"O",r:false},
  {n:52,t:"Consigo perceber as emoções das outras pessoas",f:"A",r:false},
  {n:53,t:"Faço planos e sigo esses planos",f:"C",r:false},
  {n:54,t:"Sinto-me sobrecarregado com facilidade",f:"N",r:false},
  {n:55,t:"Inicio conversas com facilidade",f:"E",r:false},
  {n:56,t:"Não me interesso por discussões teóricas",f:"O",r:true},
  {n:57,t:"Sinto intensamente as emoções dos outros",f:"A",r:false},
  {n:58,t:"Faço apenas o mínimo necessário no trabalho",f:"C",r:true},
  {n:59,t:"Raramente me irrito",f:"N",r:true},
  {n:60,t:"Não falo muito",f:"E",r:true},
  {n:61,t:"Gosto de refletir profundamente sobre as coisas",f:"O",r:false},
  {n:62,t:"Tenho interesse pelas pessoas",f:"A",r:false},
  {n:63,t:"Gosto de seguir uma rotina ou programação",f:"C",r:false},
  {n:64,t:"Perturbo-me com facilidade",f:"N",r:false},
  {n:65,t:"Converso com muitas pessoas em festas",f:"E",r:false},
  {n:66,t:"Evito discussões filosóficas",f:"O",r:true},
  {n:67,t:"Pergunto sobre o bem-estar das pessoas",f:"A",r:false},
  {n:68,t:"Deixo minhas coisas espalhadas",f:"C",r:true},
  {n:69,t:"Consigo controlar minhas emoções",f:"N",r:true},
  {n:70,t:"Não gosto de chamar atenção para mim",f:"E",r:true},
  {n:71,t:"Tenho muitas ideias",f:"O",r:false},
  {n:72,t:"Faço as pessoas se sentirem à vontade",f:"E",r:false},
  {n:73,t:"Realizo minhas tarefas imediatamente",f:"C",r:false},
  {n:74,t:"Fico chateado facilmente",f:"N",r:false},
  {n:75,t:"Prefiro tranquilidade a agitação",f:"E",r:true},
  {n:76,t:"Não gosto de poesia",f:"O",r:true},
  {n:77,t:"Não tenho muito interesse nas outras pessoas",f:"A",r:true},
  {n:78,t:"Costumo adiar tarefas",f:"C",r:true},
  {n:79,t:"Meu humor muda com frequência",f:"N",r:false},
  {n:80,t:"Não me incomodo de ser o centro das atenções",f:"E",r:false},
  {n:81,t:"Tenho dificuldade para imaginar coisas",f:"O",r:true},
  {n:82,t:"Interesso-me pela vida das outras pessoas",f:"A",r:false},
  {n:83,t:"Gosto de ordem e organização",f:"C",r:false},
  {n:84,t:"Tenho mudanças de humor frequentes",f:"N",r:false},
  {n:85,t:"Sou quieto perto de pessoas desconhecidas",f:"E",r:true},
  {n:86,t:"Tenho uma imaginação muito viva",f:"O",r:false},
  {n:87,t:"Demonstro pouca preocupação com os outros",f:"A",r:true},
  {n:88,t:"Bagunço as coisas com facilidade",f:"C",r:true},
  {n:89,t:"Permaneço calmo mesmo em situações tensas",f:"N",r:true},
  {n:90,t:"Sei lidar bem com situações sociais",f:"E",r:false},
  {n:91,t:"Gosto de imaginar coisas fantásticas",f:"O",r:false},
  {n:92,t:"Preocupo-me com os outros",f:"A",r:false},
  {n:93,t:"Cumpro meus planos",f:"C",r:false},
  {n:94,t:"Irrito-me facilmente",f:"N",r:false},
  {n:95,t:"Prefiro ficar em segundo plano",f:"E",r:true},
  {n:96,t:"Gosto de ler materiais desafiadores",f:"O",r:false},
  {n:97,t:"Sou indiferente aos sentimentos dos outros",f:"A",r:true},
  {n:98,t:"Deixo minhas coisas espalhadas",f:"C",r:true},
  {n:99,t:"Raramente sinto medo ou ansiedade",f:"N",r:true},
  {n:100,t:"Converso com muitas pessoas em festas",f:"E",r:false},
  {n:101,t:"Tenho ideias excelentes",f:"O",r:false},
  {n:102,t:"Compreendo os sentimentos dos outros",f:"A",r:false},
  {n:103,t:"Presto atenção aos detalhes",f:"C",r:false},
  {n:104,t:"Fico chateado facilmente",f:"N",r:false},
  {n:105,t:"Evito multidões",f:"E",r:true},
  {n:106,t:"Gosto de pensar profundamente sobre as coisas",f:"O",r:false},
  {n:107,t:"Sou prestativo e altruísta com os outros",f:"A",r:false},
  {n:108,t:"Sigo uma programação ou rotina",f:"C",r:false},
  {n:109,t:"Permaneço calmo sob pressão",f:"N",r:true},
  {n:110,t:"Sinto-me à vontade com outras pessoas",f:"A",r:false},
  {n:111,t:"Tenho uma imaginação rica",f:"O",r:false},
  {n:112,t:"Coloco as necessidades dos outros em primeiro lugar",f:"A",r:false},
  {n:113,t:"Gosto de terminar o que começo",f:"C",r:false},
  {n:114,t:"Fico estressado facilmente",f:"N",r:false},
  {n:115,t:"Prefiro ficar sozinho",f:"E",r:true},
  {n:116,t:"Compreendo coisas rapidamente",f:"O",r:false},
  {n:117,t:"Dedico tempo para ajudar os outros",f:"A",r:false},
  {n:118,t:"Trabalho com empenho",f:"C",r:false},
  {n:119,t:"Raramente me sinto deprimido",f:"N",r:true},
  {n:120,t:"Inicio conversas com facilidade",f:"E",r:false},
];

// ── Scoring ───────────────────────────────────────────────
export type B5Scores = {
  dims: Record<DimKey, number>;       // percentual 0–100
  facets: Record<string, number>;     // percentual 0–100
};

export function scoreAnswers(answers: Record<number, number>): B5Scores {
  // Dimensões: soma bruta dos 24 itens por dimensão
  const rawDims: Record<string, number> = { N:0, E:0, O:0, A:0, C:0 };
  ITEMS.forEach(it => {
    const v = answers[it.n];
    if (!v) return;
    rawDims[it.f] += it.r ? (6 - v) : v;
  });

  const dims = {} as Record<DimKey, number>;
  (["N","E","O","A","C"] as DimKey[]).forEach(d => {
    dims[d] = Math.max(0, Math.min(100, Math.round((rawDims[d] - 24) / 96 * 100)));
  });

  // Facetas: soma dos 4 itens por faceta
  const facets: Record<string, number> = {};
  FACETS.forEach(fc => {
    let sum = 0;
    fc.items.forEach(n => {
      const it = ITEMS.find(x => x.n === n)!;
      const v = answers[n];
      if (!v) return;
      sum += it.r ? (6 - v) : v;
    });
    facets[fc.key] = Math.max(0, Math.min(100, Math.round((sum - 4) / 16 * 100)));
  });

  return { dims, facets };
}

export function levelLabel(p: number): string {
  if (p < 20) return "Muito baixo";
  if (p < 35) return "Baixo";
  if (p < 50) return "Moderado-baixo";
  if (p < 65) return "Moderado";
  if (p < 80) return "Alto";
  return "Muito alto";
}

// Build prompt block for Claude
export function buildBig5PromptBlock(scores: B5Scores): string {
  const dimLines = (["N","E","O","A","C"] as DimKey[]).map(d => {
    const info = DIMENSIONS.find(x => x.key === d)!;
    const pct  = scores.dims[d];
    const top2 = FACETS
      .filter(f => f.dim === d)
      .map(f => ({ label: f.label, p: scores.facets[f.key] ?? 0 }))
      .sort((a,b) => b.p - a.p)
      .slice(0, 2)
      .map(x => `${x.label}(${x.p}%)`)
      .join(", ");
    return `${info.label}: ${pct}% [${levelLabel(pct)}] — facetas elevadas: ${top2}`;
  });
  return `PERFIL BIG FIVE (IPIP-NEO-120):\n${dimLines.join("\n")}`;
}
