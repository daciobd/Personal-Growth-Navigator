// artifacts/meueu/hooks/usePlanGeneration.ts
// Hook para gerar o plano personalizado.
// Passa automaticamente os scores Big Five se disponíveis no AsyncStorage.

import { useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { type B5Scores } from "../data/big5";

type GeneratedPlan = {
  sintese: string;
  fraseIntencao: string;
  praticas: Array<{
    abordagem: string;
    nome: string;
    justificativa: string;
    passos: string[];
    frequencia: string;
  }>;
};

export function usePlanGeneration() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generate = useCallback(async (
    currentAdjectives: string[],
    futureAdjectives: string[]
  ): Promise<GeneratedPlan | null> => {
    setLoading(true);
    setError(null);

    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      if (!domain) throw new Error("EXPO_PUBLIC_DOMAIN não configurado");

      // Carrega scores Big Five se disponíveis
      let big5Scores: B5Scores | undefined;
      try {
        const raw = await AsyncStorage.getItem("@meueu_assessments");
        if (raw) {
          const all = JSON.parse(raw) as Array<{ scores: B5Scores }>;
          if (all.length > 0) big5Scores = all[all.length - 1].scores;
        }
      } catch { /* Big Five opcional — continua sem ele */ }

      const res = await fetch(`${domain}/api/plan/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentAdjectives,
          futureAdjectives,
          ...(big5Scores ? { big5Scores } : {}),
        }),
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error ?? "Erro desconhecido");

      return data.plan as GeneratedPlan;
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erro ao gerar plano";
      setError(msg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  return { generate, loading, error };
}
