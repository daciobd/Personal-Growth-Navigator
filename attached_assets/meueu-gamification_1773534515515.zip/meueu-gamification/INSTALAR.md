# MeuEu Gamificação — Guia de Instalação para o Replit Agent

## O que este pacote adiciona

Sistema completo de gamificação + interação diária + coach IA:

- **Desafio diário** com proposição de ação gerada por IA (baseada na prática + histórico)
- **Check-in rápido** (1 min): fez? + nota 1-5 + comentário
- **Chat livre com o Coach IA** após cada prática — conversa com Claude Haiku
- **XP e níveis** (10 níveis com títulos)
- **Streaks diários** com bônus de XP
- **Badges desbloqueáveis** (15 conquistas)
- **Ranking anônimo** (leaderboard top 10)
- **Push notifications** diárias agendadas

---

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `lib/db/src/schema/gamification.ts` | `lib/db/src/schema/gamification.ts` | Criar |
| `artifacts/api-server/src/routes/daily.ts` | `artifacts/api-server/src/routes/daily.ts` | Criar |
| `artifacts/api-server/src/routes/coach.ts` | `artifacts/api-server/src/routes/coach.ts` | Criar |
| `artifacts/api-server/src/routes/index.ts` | `artifacts/api-server/src/routes/index.ts` | **Substituir** |
| `artifacts/meueu/data/gamification.ts` | `artifacts/meueu/data/gamification.ts` | Criar |
| `artifacts/meueu/context/GamificationContext.tsx` | `artifacts/meueu/context/GamificationContext.tsx` | Criar |
| `artifacts/meueu/hooks/useNotifications.ts` | `artifacts/meueu/hooks/useNotifications.ts` | Criar |
| `artifacts/meueu/components/DailyChallenge.tsx` | `artifacts/meueu/components/DailyChallenge.tsx` | Criar |
| `artifacts/meueu/components/XPBar.tsx` | `artifacts/meueu/components/XPBar.tsx` | Criar |
| `artifacts/meueu/components/BadgeGrid.tsx` | `artifacts/meueu/components/BadgeGrid.tsx` | Criar |
| `artifacts/meueu/app/coach/index.tsx` | `artifacts/meueu/app/coach/index.tsx` | Criar |
| `migrations/0002_gamification.sql` | Executar no banco | SQL |

---

## Passo a passo

### 1. Criar tabelas no banco
```bash
pnpm --filter @workspace/db db:push
```
Ou cole o SQL de `migrations/0002_gamification.sql` na aba Database do Replit.

### 2. Instalar dependências no app Expo
```bash
pnpm --filter @workspace/meueu add expo-notifications expo-device
```

### 3. Atualizar lib/db/src/schema/index.ts
Adicione no final do arquivo:
```typescript
export * from "./gamification";
```

### 4. Envolver o app com GamificationProvider
Em `artifacts/meueu/app/_layout.tsx`, envolva com:
```tsx
import { GamificationProvider } from "../context/GamificationContext";

// Dentro do return:
<GamificationProvider>
  {/* resto do layout */}
</GamificationProvider>
```

### 5. Adicionar DailyChallenge na tab Hoje
Em `artifacts/meueu/app/(tabs)/index.tsx` (ou a tab principal), importe e adicione:
```tsx
import DailyChallenge from "../../components/DailyChallenge";
import XPBar from "../../components/XPBar";

// Dentro do ScrollView, no topo:
<XPBar />
<DailyChallenge onCheckinComplete={(xp) => console.log(`+${xp} XP`)} />
```

### 6. Adicionar BadgeGrid no perfil
Em `artifacts/meueu/app/(tabs)/profile.tsx`:
```tsx
import BadgeGrid from "../../components/BadgeGrid";

// No ScrollView:
<BadgeGrid />
```

### 7. Configurar notificações (opcional)
Em algum ponto de inicialização do app (ex: AppContext ou _layout.tsx):
```typescript
import { requestNotificationPermission, scheduleDailyReminder } from "../hooks/useNotifications";

// Após onboarding completo:
const granted = await requestNotificationPermission();
if (granted) await scheduleDailyReminder(9, 0); // 9h da manhã
```

---

## Expo Router — nova rota /coach
O arquivo `artifacts/meueu/app/coach/index.tsx` cria automaticamente a rota
`/coach` no Expo Router (file-based routing). Nenhuma configuração adicional necessária.

Você pode navegar para ela com:
```typescript
router.push("/coach");
// Ou com contexto:
router.push({ pathname: "/coach", params: { practiceName: "...", prefillMessage: "..." } });
```

---

## Como funciona o desafio diário

O sistema rotaciona as 3 práticas do plano gerado pela IA:
- Dias 0/3/6 (dom/qua/sab) → Prática 1 (TCC)
- Dias 1/4 (seg/qui) → Prática 2 (ACT)  
- Dias 2/5 (ter/sex) → Prática 3 (Psicologia Positiva)

Para cada prática, a IA gera uma proposição de ação personalizada baseada:
- Nos passos da prática
- Nos adjetivos de futuro do usuário
- No histórico de check-ins recentes

---

## Sistema de XP

| Ação | XP |
|------|----|
| Check-in completado | +10 |
| Nota 5 | +5 |
| Nota 4 | +3 |
| 7 dias de streak | +25 |
| 14 dias | +50 |
| 30 dias | +100 |
| Mensagem ao coach | +2 |

---

## Dependências novas necessárias no Expo
```
expo-notifications
expo-device
```
