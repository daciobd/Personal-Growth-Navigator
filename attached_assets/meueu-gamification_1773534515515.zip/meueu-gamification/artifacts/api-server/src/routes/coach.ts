// artifacts/api-server/src/routes/coach.ts
//
// POST /api/coach/message — envia mensagem ao coach IA
// GET  /api/coach/history/:deviceId — histórico de conversa

import { Router } from "express";
import { db } from "@workspace/db";
import { coachMessagesTable, userProgressTable, dailyCheckinsTable } from "@workspace/db/schema";
import { eq, desc } from "drizzle-orm";
import { anthropic } from "@workspace/integrations-anthropic-ai";

const router = Router();

const SYSTEM_PROMPT = `Você é um coach terapêutico chamado MeuEu Coach, especializado em apoiar pessoas em sua jornada de transformação pessoal.

Suas características:
- Abordagem integrativa: TCC, ACT, Psicologia Positiva, Mindfulness
- Tom: acolhedor, gentil, direto, sem julgamentos
- Foco: prático e concreto — sempre termina com uma ação ou reflexão tangível
- Linguagem: português brasileiro, informal mas respeitoso, sem emojis
- Limite: não faz diagnósticos, não substitui terapeuta. Se perceber sofrimento intenso, orienta a buscar apoio profissional

Quando o usuário relata dificuldade com uma prática:
1. Valida o esforço e a dificuldade sem minimizar
2. Investiga o que especificamente foi difícil
3. Propõe uma adaptação concreta ou estratégia alternativa baseada nas abordagens terapêuticas
4. Termina com uma ação para o próximo dia

Quando o usuário relata sucesso:
1. Celebra genuinamente (sem exagero)
2. Explora o que funcionou
3. Sugere como aprofundar ou expandir a prática

Mantenha respostas curtas (máx 4 parágrafos) para uso mobile.`;

router.post("/message", async (req, res) => {
  const { deviceId, userMessage, context } = req.body as {
    deviceId: string;
    userMessage: string;
    context?: {
      practiceName?: string;
      practiceAbordagem?: string;
      checkinNote?: number;
      checkinCompleted?: boolean;
      currentStreak?: number;
      futureAdjectives?: string[];
    };
  };

  if (!deviceId || !userMessage?.trim()) {
    res.status(400).json({ error: "deviceId e userMessage são obrigatórios" });
    return;
  }

  // Busca histórico recente (últimas 10 trocas = 20 mensagens)
  const history = await db.select()
    .from(coachMessagesTable)
    .where(eq(coachMessagesTable.deviceId, deviceId))
    .orderBy(desc(coachMessagesTable.createdAt))
    .limit(20);

  const historyMessages = history.reverse().map(m => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  // Monta contexto da sessão
  let sessionContext = "";
  if (context) {
    const parts: string[] = [];
    if (context.practiceName) parts.push(`Prática atual: "${context.practiceName}" (${context.practiceAbordagem ?? ""})`);
    if (context.checkinCompleted !== undefined) {
      parts.push(`Check-in de hoje: ${context.checkinCompleted ? "realizado" : "não realizado"}${context.checkinNote ? `, nota ${context.checkinNote}/5` : ""}`);
    }
    if (context.currentStreak) parts.push(`Streak atual: ${context.currentStreak} dias`);
    if (context.futureAdjectives?.length) parts.push(`Eu futuro desejado: ${context.futureAdjectives.join(", ")}`);
    if (parts.length) sessionContext = `\n\nCONTEXTO DA SESSÃO:\n${parts.join("\n")}`;
  }

  // Salva mensagem do usuário
  await db.insert(coachMessagesTable).values({
    deviceId,
    role: "user",
    content: userMessage,
    context: context ?? null,
  });

  // Atualiza contador de mensagens no progresso
  await db
    .update(userProgressTable)
    .set({
      totalChatMsgs: db
        .select({ v: userProgressTable.totalChatMsgs })
        .from(userProgressTable)
        .where(eq(userProgressTable.deviceId, deviceId))
        .then(r => (r[0]?.v ?? 0) + 1) as unknown as number,
    })
    .where(eq(userProgressTable.deviceId, deviceId))
    .catch(() => {/* Silently ignore if progress row doesn't exist yet */});

  // Chama a API Anthropic
  try {
    const response = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 1024,
      system: SYSTEM_PROMPT + sessionContext,
      messages: [
        ...historyMessages,
        { role: "user", content: userMessage },
      ],
    });

    const assistantMessage = response.content[0].type === "text"
      ? response.content[0].text
      : "Não consegui processar sua mensagem. Tente novamente.";

    // Salva resposta do coach
    await db.insert(coachMessagesTable).values({
      deviceId,
      role: "assistant",
      content: assistantMessage,
      context: null,
    });

    // +2 XP por mensagem enviada
    await db
      .update(userProgressTable)
      .set({ totalXP: db
        .select({ v: userProgressTable.totalXP })
        .from(userProgressTable)
        .where(eq(userProgressTable.deviceId, deviceId))
        .then(r => (r[0]?.v ?? 0) + 2) as unknown as number,
        totalChatMsgs: db
          .select({ v: userProgressTable.totalChatMsgs })
          .from(userProgressTable)
          .where(eq(userProgressTable.deviceId, deviceId))
          .then(r => (r[0]?.v ?? 0) + 1) as unknown as number,
      })
      .where(eq(userProgressTable.deviceId, deviceId))
      .catch(() => {});

    res.json({ success: true, message: assistantMessage, xpGained: 2 });
  } catch (err) {
    console.error("Coach error:", err);
    res.status(500).json({ error: "Erro ao processar mensagem" });
  }
});

// ── GET /api/coach/history/:deviceId ─────────────────────
router.get("/history/:deviceId", async (req, res) => {
  const { deviceId } = req.params;
  const limit = Math.min(parseInt(req.query.limit as string) || 30, 100);

  const messages = await db.select()
    .from(coachMessagesTable)
    .where(eq(coachMessagesTable.deviceId, deviceId))
    .orderBy(desc(coachMessagesTable.createdAt))
    .limit(limit);

  res.json({ messages: messages.reverse() });
});

export default router;
