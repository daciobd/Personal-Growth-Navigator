// artifacts/api-server/src/routes/daily.ts
//
// POST /api/daily/challenge   — gera desafio do dia com IA
// POST /api/daily/checkin     — registra check-in + atualiza XP
// GET  /api/daily/progress/:deviceId — progresso gamificado
// GET  /api/daily/leaderboard — ranking anônimo top 10

import { Router } from "express";
import { db } from "@workspace/db";
import {
  dailyCheckinsTable,
  userProgressTable,
  coachMessagesTable,
} from "@workspace/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { anthropic } from "@workspace/integrations-anthropic-ai";

const router = Router();

// ── Helpers ───────────────────────────────────────────────
function todayStr(): string {
  return new Date().toISOString().split("T")[0];
}

function calcStreak(lastDate: string | null, current: number): number {
  if (!lastDate) return 1;
  const today = new Date(todayStr());
  const last = new Date(lastDate);
  const diffDays = Math.round((today.getTime() - last.getTime()) / 86400000);
  if (diffDays === 0) return current;       // já fez hoje
  if (diffDays === 1) return current + 1;   // dia seguinte
  return 1;                                 // quebrou o streak
}

async function getOrCreateProgress(deviceId: string) {
  const rows = await db.select().from(userProgressTable)
    .where(eq(userProgressTable.deviceId, deviceId)).limit(1);

  if (rows.length > 0) return rows[0];

  const [created] = await db.insert(userProgressTable)
    .values({ deviceId }).returning();
  return created;
}

// ── POST /api/daily/challenge ─────────────────────────────
// Gera a proposição de ação do dia com IA
router.post("/challenge", async (req, res) => {
  const { deviceId, practiceIdx, practiceName, practiceSteps, futureAdjectives, recentCheckins } = req.body as {
    deviceId: string;
    practiceIdx: number;
    practiceName: string;
    practiceSteps: string[];
    futureAdjectives: string[];
    recentCheckins: Array<{ note: number; completed: boolean; date: string }>;
  };

  if (!deviceId || !practiceName || !practiceSteps?.length) {
    res.status(400).json({ error: "deviceId, practiceName e practiceSteps são obrigatórios" });
    return;
  }

  const recentSummary = recentCheckins?.length
    ? `Nos últimos dias: ${recentCheckins.map(c => `${c.date} (nota: ${c.note ?? "—"}, feito: ${c.completed ? "sim" : "não"})`).join("; ")}`
    : "Início da jornada — primeiros dias de prática.";

  const prompt = `Você é um coach terapêutico gentil e prático, especializado em ajudar pessoas a manterem práticas de transformação pessoal.

PRÁTICA DE HOJE: "${practiceName}"
PASSOS DA PRÁTICA:
${practiceSteps.map((s, i) => `${i + 1}. ${s}`).join("\n")}

EU FUTURO (visão do cliente):
${futureAdjectives?.join(", ") ?? "não informado"}

HISTÓRICO RECENTE:
${recentSummary}

Gere uma proposição de ação para hoje em JSON:
{
  "titulo": "Uma frase curta e motivadora (máx 8 palavras) que capture a ação de hoje",
  "acao": "O que exatamente o usuário deve fazer hoje — concreto, específico, com tempo estimado (máx 2 frases)",
  "dica": "Uma dica rápida de como tornar isso mais fácil hoje (máx 1 frase)",
  "tempo": "Ex: 10 minutos"
}

REGRAS:
- Seja específico com base nos passos da prática
- Se o histórico mostra dificuldade (notas baixas), simplifique a ação
- Se o histórico mostra sucesso (notas altas), adicione um pequeno desafio extra
- Responda APENAS com o JSON válido`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 512,
      messages: [{ role: "user", content: prompt }],
    });

    const raw = message.content[0].type === "text" ? message.content[0].text : "";
    const match = raw.match(/\{[\s\S]*\}/);
    const challenge = match ? JSON.parse(match[0]) : { titulo: practiceName, acao: practiceSteps[0] ?? "", dica: "", tempo: "10 min" };

    res.json({ success: true, challenge, practiceIdx });
  } catch (err) {
    console.error("Daily challenge error:", err);
    res.status(500).json({ error: "Erro ao gerar desafio" });
  }
});

// ── POST /api/daily/checkin ───────────────────────────────
router.post("/checkin", async (req, res) => {
  const { deviceId, practiceIdx, practiceName, completed, note, comment } = req.body as {
    deviceId: string;
    practiceIdx: number;
    practiceName: string;
    completed: boolean;
    note?: number;
    comment?: string;
  };

  if (!deviceId || typeof practiceIdx !== "number") {
    res.status(400).json({ error: "deviceId e practiceIdx são obrigatórios" });
    return;
  }

  const today = todayStr();

  // Verifica se já fez check-in hoje
  const existing = await db.select().from(dailyCheckinsTable)
    .where(eq(dailyCheckinsTable.deviceId, deviceId))
    .where(eq(dailyCheckinsTable.checkinDate, today))
    .limit(1);

  if (existing.length > 0) {
    res.json({ success: true, message: "Check-in já realizado hoje", alreadyDone: true });
    return;
  }

  // Salva check-in
  await db.insert(dailyCheckinsTable).values({
    deviceId, practiceIdx, practiceName,
    completed, note: note ?? null,
    comment: comment ?? null,
    checkinDate: today,
  });

  // Atualiza progresso gamificado
  const progress = await getOrCreateProgress(deviceId);

  const newStreak = completed ? calcStreak(progress.lastCheckinDate, progress.currentStreak) : progress.currentStreak;
  const maxStreak = Math.max(newStreak, progress.maxStreak);

  // Calcula XP ganho
  let xpGained = 0;
  if (completed) xpGained += 10;
  if (note === 5) xpGained += 5;
  else if (note === 4) xpGained += 3;
  if (newStreak === 7)  xpGained += 25;
  if (newStreak === 14) xpGained += 50;
  if (newStreak === 30) xpGained += 100;

  const newTotalXP = progress.totalXP + xpGained;
  const newCheckins = progress.totalCheckins + (completed ? 1 : 0);
  const newNote5 = progress.note5Count + (note === 5 ? 1 : 0);

  await db.update(userProgressTable)
    .set({
      totalXP: newTotalXP,
      currentStreak: completed ? newStreak : progress.currentStreak,
      maxStreak,
      lastCheckinDate: completed ? today : progress.lastCheckinDate,
      totalCheckins: newCheckins,
      note5Count: newNote5,
      updatedAt: new Date(),
    })
    .where(eq(userProgressTable.deviceId, deviceId));

  res.json({
    success: true,
    xpGained,
    newTotalXP,
    newStreak: completed ? newStreak : progress.currentStreak,
    streakBonus: newStreak === 7 || newStreak === 14 || newStreak === 30,
  });
});

// ── GET /api/daily/progress/:deviceId ────────────────────
router.get("/progress/:deviceId", async (req, res) => {
  const { deviceId } = req.params;
  const progress = await getOrCreateProgress(deviceId);

  const checkins = await db.select().from(dailyCheckinsTable)
    .where(eq(dailyCheckinsTable.deviceId, deviceId))
    .orderBy(desc(dailyCheckinsTable.checkinDate))
    .limit(7);

  res.json({ progress, recentCheckins: checkins });
});

// ── GET /api/daily/leaderboard ────────────────────────────
router.get("/leaderboard", async (_req, res) => {
  const top = await db.select({
    rank: sql<number>`ROW_NUMBER() OVER (ORDER BY total_xp DESC)`,
    deviceId: userProgressTable.deviceId,
    totalXP: userProgressTable.totalXP,
    currentStreak: userProgressTable.currentStreak,
    totalCheckins: userProgressTable.totalCheckins,
  })
  .from(userProgressTable)
  .orderBy(desc(userProgressTable.totalXP))
  .limit(10);

  // Anonimiza deviceId → "Viajante #N"
  const anonymous = top.map((row, i) => ({
    rank: i + 1,
    name: `Viajante #${(row.totalXP % 997) + 1}`,
    totalXP: row.totalXP,
    currentStreak: row.currentStreak,
    totalCheckins: row.totalCheckins,
  }));

  res.json({ leaderboard: anonymous });
});

export default router;
