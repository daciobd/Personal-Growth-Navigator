// artifacts/api-server/src/routes/index.ts
import { Router } from "express";
import healthRouter from "./health.js";
import planRouter   from "./plan.js";
import adminRouter  from "./admin.js";
import dailyRouter  from "./daily.js";
import coachRouter  from "./coach.js";

const router = Router();

router.use(healthRouter);
router.use(planRouter);
router.use("/admin", adminRouter);
router.use("/daily", dailyRouter);
router.use("/coach", coachRouter);

export default router;
