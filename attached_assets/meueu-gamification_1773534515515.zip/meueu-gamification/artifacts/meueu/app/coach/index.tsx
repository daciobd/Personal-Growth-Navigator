// artifacts/meueu/app/coach/index.tsx
// Tela de chat com o Coach IA
// Acessível via router.push("/coach") com params opcionais

import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View, Text, StyleSheet, TextInput, Pressable, FlatList,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useGamification } from "../../context/GamificationContext";
import { useAppContext } from "../../context/AppContext";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
};

const WELCOME_MSG: Message = {
  id: "welcome",
  role: "assistant",
  content: "Olá! Estou aqui para te apoiar na sua jornada. Pode compartilhar como está sendo a prática, o que está sendo difícil, ou qualquer dúvida que tiver.",
  timestamp: new Date(),
};

export default function CoachScreen() {
  const insets = useSafeAreaInsets();
  const { gam, recordChatMessage } = useGamification();
  const { profile } = useAppContext();
  const params = useLocalSearchParams<{
    practiceName?: string;
    practiceAbordagem?: string;
    prefillMessage?: string;
    context?: string;
  }>();

  const [messages, setMessages] = useState<Message[]>([WELCOME_MSG]);
  const [input, setInput] = useState(params.prefillMessage ?? "");
  const [sending, setSending] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const flatListRef = useRef<FlatList>(null);

  // Load history
  useEffect(() => {
    const domain = process.env.EXPO_PUBLIC_DOMAIN;
    if (!domain) { setLoadingHistory(false); return; }

    fetch(`${domain}/api/coach/history/${gam.deviceId}?limit=30`)
      .then(r => r.json())
      .then(data => {
        if (data.messages?.length > 0) {
          const loaded: Message[] = data.messages.map((m: { id: number; role: string; content: string; createdAt: string }) => ({
            id: String(m.id),
            role: m.role as "user" | "assistant",
            content: m.content,
            timestamp: new Date(m.createdAt),
          }));
          setMessages(loaded);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingHistory(false));
  }, [gam.deviceId]);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || sending) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: text,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setSending(true);

    const domain = process.env.EXPO_PUBLIC_DOMAIN;
    if (!domain) {
      setSending(false);
      return;
    }

    try {
      const res = await fetch(`${domain}/api/coach/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deviceId: gam.deviceId,
          userMessage: text,
          context: {
            practiceName: params.practiceName,
            practiceAbordagem: params.practiceAbordagem,
            currentStreak: gam.currentStreak,
            futureAdjectives: profile.futureAdjectives,
          },
        }),
      });

      const data = await res.json();
      if (data.success) {
        const assistantMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: data.message,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMsg]);
        await recordChatMessage();
      }
    } catch {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Não consegui responder agora. Tente novamente.",
        timestamp: new Date(),
      }]);
    } finally {
      setSending(false);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [input, sending, gam.deviceId, params, profile.futureAdjectives, recordChatMessage]);

  const renderMessage = ({ item }: { item: Message }) => {
    const isUser = item.role === "user";
    return (
      <View style={[styles.msgRow, isUser && styles.msgRowUser]}>
        {!isUser && (
          <View style={styles.avatar}>
            <Feather name="user" size={14} color="#1B6B5A" />
          </View>
        )}
        <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAssistant]}>
          <Text style={[styles.bubbleText, isUser && styles.bubbleTextUser]}>
            {item.content}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={0}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={20} color="#0F1F1B" />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>Coach</Text>
          {params.practiceName && (
            <Text style={styles.headerSub}>{params.practiceName}</Text>
          )}
        </View>
        <View style={styles.xpPill}>
          <Feather name="zap" size={11} color="#E8A838" />
          <Text style={styles.xpPillText}>{gam.totalXP} XP</Text>
        </View>
      </View>

      {/* Messages */}
      {loadingHistory ? (
        <View style={styles.loadingCenter}>
          <ActivityIndicator color="#1B6B5A" />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={m => m.id}
          renderItem={renderMessage}
          contentContainerStyle={styles.listContent}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
        />
      )}

      {/* Sending indicator */}
      {sending && (
        <View style={styles.typingRow}>
          <View style={styles.typingBubble}>
            <ActivityIndicator size="small" color="#6B8F7E" />
            <Text style={styles.typingText}>Coach escrevendo…</Text>
          </View>
        </View>
      )}

      {/* Input bar */}
      <View style={[styles.inputBar, { paddingBottom: insets.bottom + 8 }]}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Escreva para o coach…"
          placeholderTextColor="#A8C0B8"
          multiline
          returnKeyType="send"
          onSubmitEditing={sendMessage}
          editable={!sending}
        />
        <Pressable
          style={[styles.sendBtn, (!input.trim() || sending) && styles.sendBtnDisabled]}
          onPress={sendMessage}
          disabled={!input.trim() || sending}>
          <Feather name="send" size={18} color="#fff" />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F5F8F6" },
  header: { backgroundColor: "#fff", borderBottomWidth: 1, borderBottomColor: "#E8F0ED", paddingHorizontal: 20, paddingBottom: 12, flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  headerCenter: { flex: 1 },
  headerTitle: { fontSize: 16, fontWeight: "700", color: "#0F1F1B" },
  headerSub: { fontSize: 12, color: "#6B8F7E", marginTop: 1 },
  xpPill: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "#FFF8EC", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  xpPillText: { fontSize: 12, fontWeight: "700", color: "#E8A838" },
  loadingCenter: { flex: 1, alignItems: "center", justifyContent: "center" },
  listContent: { padding: 16, gap: 12 },
  msgRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  msgRowUser: { flexDirection: "row-reverse" },
  avatar: { width: 30, height: 30, borderRadius: 15, backgroundColor: "#E8F5F1", alignItems: "center", justifyContent: "center" },
  bubble: { maxWidth: "78%", borderRadius: 16, padding: 12 },
  bubbleUser: { backgroundColor: "#1B6B5A", borderBottomRightRadius: 4 },
  bubbleAssistant: { backgroundColor: "#fff", borderBottomLeftRadius: 4, borderWidth: 1, borderColor: "#E8F0ED" },
  bubbleText: { fontSize: 14, color: "#0F1F1B", lineHeight: 21 },
  bubbleTextUser: { color: "#fff" },
  typingRow: { paddingHorizontal: 16, paddingBottom: 4 },
  typingBubble: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#fff", borderWidth: 1, borderColor: "#E8F0ED", borderRadius: 16, paddingHorizontal: 12, paddingVertical: 8, alignSelf: "flex-start" },
  typingText: { fontSize: 12, color: "#6B8F7E" },
  inputBar: { backgroundColor: "#fff", borderTopWidth: 1, borderTopColor: "#E8F0ED", paddingHorizontal: 16, paddingTop: 10, flexDirection: "row", alignItems: "flex-end", gap: 10 },
  input: { flex: 1, backgroundColor: "#F5F8F6", borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 14, color: "#0F1F1B", maxHeight: 100, fontFamily: "Inter_400Regular" },
  sendBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: "#1B6B5A", alignItems: "center", justifyContent: "center" },
  sendBtnDisabled: { opacity: 0.4 },
});
