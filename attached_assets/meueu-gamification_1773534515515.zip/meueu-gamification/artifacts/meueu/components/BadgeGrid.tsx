// artifacts/meueu/components/BadgeGrid.tsx
// Exibe todos os badges (conquistados e bloqueados)
import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { Feather } from "@expo/vector-icons";
import { BADGES, TIER_COLORS, type UserStats } from "../data/gamification";
import { useGamification } from "../context/GamificationContext";

export default function BadgeGrid() {
  const { gam } = useGamification();

  const stats: UserStats = {
    totalCheckins:    gam.totalCheckins,
    currentStreak:    gam.currentStreak,
    maxStreak:        gam.maxStreak,
    totalXP:          gam.totalXP,
    totalChatMessages:gam.totalChatMsgs,
    note5Count:       gam.note5Count,
    practicesCompleted: gam.totalCheckins,
    daysActive:       gam.totalCheckins,
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Conquistas</Text>
      <Text style={styles.sub}>{gam.earnedBadgeIds.length} de {BADGES.length} desbloqueadas</Text>
      <View style={styles.grid}>
        {BADGES.map(badge => {
          const earned = gam.earnedBadgeIds.includes(badge.id);
          const tier = TIER_COLORS[badge.tier];
          return (
            <View
              key={badge.id}
              style={[
                styles.badge,
                earned
                  ? { backgroundColor: tier.bg, borderColor: tier.border }
                  : styles.badgeLocked,
              ]}>
              <View style={[styles.iconWrap, earned ? { backgroundColor: tier.border + "44" } : styles.iconWrapLocked]}>
                <Feather
                  name={badge.icon as keyof typeof Feather.glyphMap}
                  size={18}
                  color={earned ? tier.text : "#4A6A5A"}
                />
              </View>
              <Text style={[styles.badgeTitle, { color: earned ? tier.text : "#4A6A5A" }]}>
                {badge.title}
              </Text>
              {earned && (
                <Text style={[styles.badgeDesc, { color: tier.text + "AA" }]}>
                  {badge.description}
                </Text>
              )}
              {!earned && (
                <Text style={styles.lockedLabel}>Bloqueado</Text>
              )}
              <View style={[styles.tierPill, { backgroundColor: earned ? tier.border + "44" : "#1A2E24" }]}>
                <Text style={[styles.tierText, { color: earned ? tier.text : "#4A6A5A" }]}>
                  {badge.tier}
                </Text>
              </View>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 24 },
  title: { fontSize: 17, fontWeight: "700", color: "#0F1F1B", marginBottom: 2 },
  sub: { fontSize: 13, color: "#6B8F7E", marginBottom: 16 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  badge: { width: "47%", borderRadius: 12, padding: 14, borderWidth: 1, gap: 6 },
  badgeLocked: { backgroundColor: "#1A2E24", borderColor: "#2A4A38" },
  iconWrap: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  iconWrapLocked: { backgroundColor: "#2A4A38" },
  badgeTitle: { fontSize: 13, fontWeight: "700" },
  badgeDesc: { fontSize: 11, lineHeight: 16 },
  lockedLabel: { fontSize: 11, color: "#4A6A5A" },
  tierPill: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  tierText: { fontSize: 10, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
});
