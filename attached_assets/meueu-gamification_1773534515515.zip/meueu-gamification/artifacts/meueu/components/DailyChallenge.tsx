// artifacts/meueu/components/DailyChallenge.tsx
import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, Pressable, ActivityIndicator, TextInput, Alert } from "react-native";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { useGamification } from "../context/GamificationContext";
import { useAppContext } from "../context/AppContext";

type Challenge = {
  titulo: string;
  acao: string;
  dica: string;
  tempo: string;
};

type Props = {
  onCheckinComplete?: (xpGained: number) => void;
};

const NOTE_LABELS = ["", "Muito difícil", "Difícil", "Mais ou menos", "Boa", "Excelente"];

export default function DailyChallenge({ onCheckinComplete }: Props) {
  const { gam, recordCheckin } = useGamification();
  const { profile } = useAppContext();

  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [loadingChallenge, setLoadingChallenge] = useState(true);
  const [step, setStep] = useState<"challenge" | "checkin" | "done">(
    gam.todayCheckinDone ? "done" : "challenge"
  );
  const [completed, setCompleted] = useState<boolean | null>(null);
  const [note, setNote] = useState(0);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);
  const [xpGained, setXpGained] = useState(0);

  // Qual prática mostrar hoje (rota entre as 3 práticas por dia da semana)
  const praticas = profile.generatedPlan?.praticas ?? [];
  const dayIdx = new Date().getDay(); // 0=dom ... 6=sab
  const practiceIdx = praticas.length > 0 ? dayIdx % praticas.length : 0;
  const pratica = praticas[practiceIdx];

  useEffect(() => {
    if (!pratica || step === "done") { setLoadingChallenge(false); return; }
    const domain = process.env.EXPO_PUBLIC_DOMAIN;
    if (!domain) { setLoadingChallenge(false); return; }

    (async () => {
      setLoadingChallenge(true);
      try {
        const res = await fetch(`${domain}/api/daily/challenge`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            deviceId: gam.deviceId,
            practiceIdx,
            practiceName: pratica.nome,
            practiceSteps: pratica.passos,
            futureAdjectives: profile.futureAdjectives,
            recentCheckins: [],
          }),
        });
        const data = await res.json();
        if (data.success) setChallenge(data.challenge);
      } catch { /* Use fallback */ } finally {
        setLoadingChallenge(false);
      }
    })();
  }, [pratica?.nome]);

  async function handleCheckin() {
    if (completed === null || (completed && note === 0)) {
      Alert.alert("Avalie sua prática", "Selecione uma nota antes de continuar.");
      return;
    }
    setSaving(true);
    try {
      const { newBadges } = await recordCheckin(completed, completed ? note : undefined);
      const gained = completed ? (10 + (note === 5 ? 5 : note === 4 ? 3 : 0)) : 0;
      setXpGained(gained);
      setStep("done");
      onCheckinComplete?.(gained);

      if (newBadges.length > 0) {
        Alert.alert(
          "Nova conquista!",
          newBadges.map(b => `${b.title}: ${b.description}`).join("\n")
        );
      }
    } finally {
      setSaving(false);
    }
  }

  if (!pratica) return null;

  // Done state
  if (step === "done") {
    return (
      <View style={styles.card}>
        <View style={styles.doneRow}>
          <View style={styles.doneIcon}>
            <Feather name="check-circle" size={22} color="#1B6B5A" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.doneTitle}>Check-in do dia concluído</Text>
            <Text style={styles.doneSub}>
              {xpGained > 0 ? `+${xpGained} XP ganhos` : "Continue amanhã!"}
            </Text>
          </View>
          <Pressable
            onPress={() => router.push({ pathname: "/coach", params: { context: "checkin_done" } })}
            style={styles.chatBtn}>
            <Feather name="message-circle" size={16} color="#fff" />
            <Text style={styles.chatBtnText}>Coach</Text>
          </Pressable>
        </View>
        <View style={styles.streakRow}>
          <Feather name="zap" size={14} color="#E8A838" />
          <Text style={styles.streakText}>{gam.currentStreak} dias seguidos</Text>
        </View>
      </View>
    );
  }

  // Challenge state
  if (step === "challenge") {
    return (
      <View style={styles.card}>
        <View style={styles.headerRow}>
          <View style={styles.dayBadge}>
            <Text style={styles.dayBadgeText}>Hoje</Text>
          </View>
          <Text style={styles.therapyBadge}>{pratica.abordagem}</Text>
        </View>

        {loadingChallenge ? (
          <View style={styles.loadingRow}>
            <ActivityIndicator size="small" color="#1B6B5A" />
            <Text style={styles.loadingText}>Preparando seu desafio…</Text>
          </View>
        ) : (
          <>
            <Text style={styles.challengeTitle}>
              {challenge?.titulo ?? pratica.nome}
            </Text>
            <Text style={styles.challengeAction}>
              {challenge?.acao ?? pratica.passos[0]}
            </Text>
            {(challenge?.dica ?? "") !== "" && (
              <View style={styles.tipRow}>
                <Feather name="info" size={13} color="#6B8F7E" />
                <Text style={styles.tipText}>{challenge!.dica}</Text>
              </View>
            )}
            <View style={styles.metaRow}>
              <Feather name="clock" size={12} color="#6B8F7E" />
              <Text style={styles.metaText}>{challenge?.tempo ?? "10 min"}</Text>
            </View>
          </>
        )}

        <View style={styles.actions}>
          <Pressable
            style={styles.startBtn}
            onPress={() => setStep("checkin")}>
            <Text style={styles.startBtnText}>Vou fazer agora</Text>
            <Feather name="arrow-right" size={16} color="#fff" />
          </Pressable>
          <Pressable
            onPress={() => router.push({
              pathname: "/coach",
              params: {
                practiceName: pratica.nome,
                practiceAbordagem: pratica.abordagem,
                prefillMessage: `Tenho dúvida sobre como fazer a prática "${pratica.nome}" hoje`,
              }
            })}
            style={styles.helpBtn}>
            <Feather name="help-circle" size={14} color="#1B6B5A" />
            <Text style={styles.helpBtnText}>Tenho dúvida</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  // Checkin state
  return (
    <View style={styles.card}>
      <Text style={styles.checkinTitle}>Como foi hoje?</Text>
      <Text style={styles.checkinSub}>{pratica.nome}</Text>

      <Text style={styles.questionText}>Você conseguiu fazer a prática?</Text>
      <View style={styles.yesNoRow}>
        {[true, false].map(v => (
          <Pressable
            key={String(v)}
            style={[styles.yesNoBtn, completed === v && styles.yesNoBtnActive]}
            onPress={() => setCompleted(v)}>
            <Feather
              name={v ? "check" : "x"}
              size={16}
              color={completed === v ? "#fff" : "#6B8F7E"}
            />
            <Text style={[styles.yesNoBtnText, completed === v && { color: "#fff" }]}>
              {v ? "Sim" : "Não consegui"}
            </Text>
          </Pressable>
        ))}
      </View>

      {completed && (
        <>
          <Text style={styles.questionText}>Como foi a experiência?</Text>
          <View style={styles.noteRow}>
            {[1, 2, 3, 4, 5].map(n => (
              <Pressable
                key={n}
                style={[styles.noteBtn, note === n && styles.noteBtnActive]}
                onPress={() => setNote(n)}>
                <Text style={[styles.noteBtnNum, note === n && { color: "#fff" }]}>{n}</Text>
              </Pressable>
            ))}
          </View>
          {note > 0 && (
            <Text style={styles.noteLabel}>{NOTE_LABELS[note]}</Text>
          )}
        </>
      )}

      <TextInput
        style={styles.commentInput}
        placeholder="Comentário opcional…"
        placeholderTextColor="#A8C0B8"
        value={comment}
        onChangeText={setComment}
        multiline
        numberOfLines={2}
      />

      <View style={styles.actions}>
        <Pressable
          style={[styles.startBtn, saving && { opacity: 0.6 }]}
          onPress={handleCheckin}
          disabled={saving}>
          {saving
            ? <ActivityIndicator size="small" color="#fff" />
            : <Text style={styles.startBtnText}>Registrar</Text>
          }
        </Pressable>
        <Pressable
          onPress={() => router.push({
            pathname: "/coach",
            params: {
              practiceName: pratica.nome,
              practiceAbordagem: pratica.abordagem,
              prefillMessage: completed === false
                ? `Não consegui fazer a prática "${pratica.nome}" hoje. O que posso fazer diferente?`
                : `Fiz a prática "${pratica.nome}" hoje com nota ${note}. Quero conversar sobre isso.`,
            }
          })}
          style={styles.helpBtn}>
          <Feather name="message-circle" size={14} color="#1B6B5A" />
          <Text style={styles.helpBtnText}>Falar com o coach</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: "#E8F0ED",
    marginBottom: 16,
  },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  dayBadge: { backgroundColor: "#E8F5F1", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  dayBadgeText: { fontSize: 11, fontWeight: "700", color: "#1B6B5A" },
  therapyBadge: { fontSize: 11, fontWeight: "700", color: "#E8A838" },
  loadingRow: { flexDirection: "row", alignItems: "center", gap: 10, marginVertical: 12 },
  loadingText: { fontSize: 13, color: "#6B8F7E" },
  challengeTitle: { fontSize: 18, fontWeight: "700", color: "#0F1F1B", marginBottom: 8, lineHeight: 24 },
  challengeAction: { fontSize: 14, color: "#3D5A52", lineHeight: 22, marginBottom: 10 },
  tipRow: { flexDirection: "row", alignItems: "flex-start", gap: 6, backgroundColor: "#F5F8F6", borderRadius: 8, padding: 10, marginBottom: 10 },
  tipText: { fontSize: 12, color: "#6B8F7E", flex: 1, lineHeight: 18 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 5, marginBottom: 16 },
  metaText: { fontSize: 12, color: "#6B8F7E" },
  actions: { gap: 10 },
  startBtn: { backgroundColor: "#1B6B5A", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 13, borderRadius: 12 },
  startBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" },
  helpBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 10 },
  helpBtnText: { fontSize: 13, color: "#1B6B5A", fontWeight: "500" },
  checkinTitle: { fontSize: 18, fontWeight: "700", color: "#0F1F1B", marginBottom: 2 },
  checkinSub: { fontSize: 13, color: "#6B8F7E", marginBottom: 18 },
  questionText: { fontSize: 14, fontWeight: "600", color: "#0F1F1B", marginBottom: 10 },
  yesNoRow: { flexDirection: "row", gap: 10, marginBottom: 18 },
  yesNoBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingVertical: 11, borderRadius: 10, borderWidth: 1.5, borderColor: "#E8F0ED" },
  yesNoBtnActive: { backgroundColor: "#1B6B5A", borderColor: "#1B6B5A" },
  yesNoBtnText: { fontSize: 13, fontWeight: "600", color: "#6B8F7E" },
  noteRow: { flexDirection: "row", gap: 8, marginBottom: 6 },
  noteBtn: { flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, borderColor: "#E8F0ED" },
  noteBtnActive: { backgroundColor: "#1B6B5A", borderColor: "#1B6B5A" },
  noteBtnNum: { fontSize: 16, fontWeight: "700", color: "#3D5A52" },
  noteLabel: { fontSize: 12, color: "#6B8F7E", textAlign: "center", marginBottom: 12 },
  commentInput: { borderWidth: 1, borderColor: "#E8F0ED", borderRadius: 10, padding: 12, fontSize: 14, color: "#0F1F1B", minHeight: 60, marginBottom: 14, fontFamily: "Inter_400Regular" },
  doneRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 12 },
  doneIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: "#E8F5F1", alignItems: "center", justifyContent: "center" },
  doneTitle: { fontSize: 15, fontWeight: "700", color: "#0F1F1B" },
  doneSub: { fontSize: 13, color: "#6B8F7E", marginTop: 2 },
  chatBtn: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "#1B6B5A", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  chatBtnText: { fontSize: 12, fontWeight: "700", color: "#fff" },
  streakRow: { flexDirection: "row", alignItems: "center", gap: 6, paddingTop: 12, borderTopWidth: 1, borderTopColor: "#E8F0ED" },
  streakText: { fontSize: 13, color: "#E8A838", fontWeight: "600" },
});
