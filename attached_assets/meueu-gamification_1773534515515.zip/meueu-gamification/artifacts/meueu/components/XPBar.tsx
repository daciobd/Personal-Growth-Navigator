// artifacts/meueu/components/XPBar.tsx
import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { useGamification } from "../context/GamificationContext";

export default function XPBar() {
  const { gam } = useGamification();
  const { level, xpProgress, totalXP } = gam;

  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <View style={[styles.levelBadge, { backgroundColor: level.color + "22", borderColor: level.color + "55" }]}>
          <Text style={[styles.levelText, { color: level.color }]}>Nível {level.level}</Text>
          <Text style={[styles.levelTitle, { color: level.color }]}>{level.title}</Text>
        </View>
        <Text style={styles.xpCount}>{totalXP} XP</Text>
      </View>
      <View style={styles.barBg}>
        <View style={[styles.barFill, { width: `${xpProgress}%` as `${number}%`, backgroundColor: level.color }]} />
      </View>
      <Text style={styles.barLabel}>{xpProgress}% para o próximo nível</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 4 },
  row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  levelBadge: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, borderWidth: 1 },
  levelText: { fontSize: 11, fontWeight: "700" },
  levelTitle: { fontSize: 12, fontWeight: "500" },
  xpCount: { fontSize: 13, fontWeight: "600", color: "#6B8F7E" },
  barBg: { height: 6, backgroundColor: "#E8F0ED", borderRadius: 3, overflow: "hidden", marginBottom: 4 },
  barFill: { height: "100%", borderRadius: 3 },
  barLabel: { fontSize: 11, color: "#6B8F7E", textAlign: "right" },
});
