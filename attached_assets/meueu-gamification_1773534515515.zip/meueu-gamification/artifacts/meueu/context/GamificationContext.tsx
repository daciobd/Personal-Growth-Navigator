// artifacts/meueu/context/GamificationContext.tsx
import React, {
  createContext, useContext, useState,
  useEffect, useCallback, useRef,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  getLevelForXP, getXPProgress, checkNewBadges,
  XP_REWARDS, type UserStats, type Badge,
} from "../data/gamification";
import { sendLocalNotification } from "../hooks/useNotifications";

// ── Types ─────────────────────────────────────────────────
export type GamificationState = {
  deviceId: string;
  totalXP: number;
  currentStreak: number;
  maxStreak: number;
  lastCheckinDate: string | null;
  earnedBadgeIds: string[];
  totalCheckins: number;
  note5Count: number;
  totalChatMsgs: number;
  todayCheckinDone: boolean;
  // Derived
  level: ReturnType<typeof getLevelForXP>;
  xpProgress: number;
};

type GamificationContextValue = {
  gam: GamificationState;
  loading: boolean;
  addXP: (amount: number) => Promise<void>;
  recordCheckin: (completed: boolean, note?: number) => Promise<{ newBadges: Badge[] }>;
  recordChatMessage: () => Promise<void>;
  syncWithServer: () => Promise<void>;
  newBadgesQueue: Badge[];
  dismissBadge: (id: string) => void;
};

// ── Default state ─────────────────────────────────────────
function defaultState(deviceId: string): GamificationState {
  const totalXP = 0;
  return {
    deviceId,
    totalXP,
    currentStreak: 0,
    maxStreak: 0,
    lastCheckinDate: null,
    earnedBadgeIds: [],
    totalCheckins: 0,
    note5Count: 0,
    totalChatMsgs: 0,
    todayCheckinDone: false,
    level: getLevelForXP(totalXP),
    xpProgress: getXPProgress(totalXP),
  };
}

const STORAGE_KEY = "@meueu_gamification_v1";

async function getDeviceId(): Promise<string> {
  const stored = await AsyncStorage.getItem("@meueu_device_id");
  if (stored) return stored;
  const id = `dev_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
  await AsyncStorage.setItem("@meueu_device_id", id);
  return id;
}

function todayStr(): string {
  return new Date().toISOString().split("T")[0];
}

// ── Context ───────────────────────────────────────────────
const GamificationContext = createContext<GamificationContextValue | null>(null);

export function GamificationProvider({ children }: { children: React.ReactNode }) {
  const [gam, setGam] = useState<GamificationState | null>(null);
  const [loading, setLoading] = useState(true);
  const [newBadgesQueue, setNewBadgesQueue] = useState<Badge[]>([]);
  const deviceIdRef = useRef<string>("");

  // Load from AsyncStorage on mount
  useEffect(() => {
    (async () => {
      const deviceId = await getDeviceId();
      deviceIdRef.current = deviceId;

      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Omit<GamificationState, "level" | "xpProgress">;
        setGam({
          ...saved,
          deviceId,
          todayCheckinDone: saved.lastCheckinDate === todayStr(),
          level: getLevelForXP(saved.totalXP),
          xpProgress: getXPProgress(saved.totalXP),
        });
      } else {
        setGam(defaultState(deviceId));
      }
      setLoading(false);
    })();
  }, []);

  const save = useCallback(async (state: GamificationState) => {
    const { level: _l, xpProgress: _xp, ...toSave } = state;
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
  }, []);

  const addXP = useCallback(async (amount: number) => {
    if (!gam) return;
    const newXP = gam.totalXP + amount;
    const updated = {
      ...gam,
      totalXP: newXP,
      level: getLevelForXP(newXP),
      xpProgress: getXPProgress(newXP),
    };
    setGam(updated);
    await save(updated);
  }, [gam, save]);

  const recordCheckin = useCallback(async (completed: boolean, note?: number): Promise<{ newBadges: Badge[] }> => {
    if (!gam) return { newBadges: [] };

    const today = todayStr();
    if (gam.todayCheckinDone) return { newBadges: [] };

    // Streak logic
    let newStreak = gam.currentStreak;
    if (completed) {
      if (!gam.lastCheckinDate) {
        newStreak = 1;
      } else {
        const last = new Date(gam.lastCheckinDate);
        const now = new Date(today);
        const diff = Math.round((now.getTime() - last.getTime()) / 86400000);
        newStreak = diff === 1 ? gam.currentStreak + 1 : 1;
      }
    }

    const maxStreak = Math.max(newStreak, gam.maxStreak);

    // XP
    let xpGained = completed ? XP_REWARDS.checkin_completed : 0;
    if (note === 5) xpGained += XP_REWARDS.checkin_note_5;
    else if (note === 4) xpGained += XP_REWARDS.checkin_note_4;
    if (newStreak === 7)  xpGained += XP_REWARDS.streak_7_days;
    if (newStreak === 14) xpGained += XP_REWARDS.streak_14_days;
    if (newStreak === 30) xpGained += XP_REWARDS.streak_30_days;

    const newTotalXP = gam.totalXP + xpGained;
    const newCheckins = gam.totalCheckins + (completed ? 1 : 0);
    const newNote5 = gam.note5Count + (note === 5 ? 1 : 0);

    const updated: GamificationState = {
      ...gam,
      totalXP: newTotalXP,
      currentStreak: completed ? newStreak : gam.currentStreak,
      maxStreak,
      lastCheckinDate: completed ? today : gam.lastCheckinDate,
      totalCheckins: newCheckins,
      note5Count: newNote5,
      todayCheckinDone: true,
      level: getLevelForXP(newTotalXP),
      xpProgress: getXPProgress(newTotalXP),
    };

    // Check badges
    const stats: UserStats = {
      totalCheckins: newCheckins,
      currentStreak: updated.currentStreak,
      maxStreak,
      totalXP: newTotalXP,
      totalChatMessages: gam.totalChatMsgs,
      note5Count: newNote5,
      practicesCompleted: newCheckins,
      daysActive: newCheckins,
    };

    const newBadges = checkNewBadges(stats, gam.earnedBadgeIds);
    if (newBadges.length > 0) {
      const newBadgeXP = newBadges.reduce((s, b) => s + b.xpReward, 0);
      updated.earnedBadgeIds = [...gam.earnedBadgeIds, ...newBadges.map(b => b.id)];
      updated.totalXP = newTotalXP + newBadgeXP;
      updated.level = getLevelForXP(updated.totalXP);
      updated.xpProgress = getXPProgress(updated.totalXP);
      setNewBadgesQueue(q => [...q, ...newBadges]);
      for (const badge of newBadges) {
        await sendLocalNotification("Nova conquista!", `${badge.title} — ${badge.description}`);
      }
    }

    setGam(updated);
    await save(updated);
    return { newBadges };
  }, [gam, save]);

  const recordChatMessage = useCallback(async () => {
    if (!gam) return;
    const newXP = gam.totalXP + XP_REWARDS.chat_message_sent;
    const newMsgs = gam.totalChatMsgs + 1;
    const updated = {
      ...gam,
      totalXP: newXP,
      totalChatMsgs: newMsgs,
      level: getLevelForXP(newXP),
      xpProgress: getXPProgress(newXP),
    };

    // Check chat badges
    const stats: UserStats = {
      totalCheckins: gam.totalCheckins,
      currentStreak: gam.currentStreak,
      maxStreak: gam.maxStreak,
      totalXP: newXP,
      totalChatMessages: newMsgs,
      note5Count: gam.note5Count,
      practicesCompleted: gam.totalCheckins,
      daysActive: gam.totalCheckins,
    };
    const newBadges = checkNewBadges(stats, gam.earnedBadgeIds);
    if (newBadges.length > 0) {
      updated.earnedBadgeIds = [...gam.earnedBadgeIds, ...newBadges.map(b => b.id)];
      setNewBadgesQueue(q => [...q, ...newBadges]);
    }

    setGam(updated);
    await save(updated);
  }, [gam, save]);

  const syncWithServer = useCallback(async () => {
    // Sync local XP/streaks with server (for leaderboard)
    if (!gam) return;
    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      if (!domain) return;
      await fetch(`${domain}/api/daily/checkin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId: gam.deviceId, sync: true }),
      });
    } catch { /* fail silently */ }
  }, [gam]);

  const dismissBadge = useCallback((id: string) => {
    setNewBadgesQueue(q => q.filter(b => b.id !== id));
  }, []);

  if (!gam) return null;

  return (
    <GamificationContext.Provider value={{
      gam, loading,
      addXP, recordCheckin, recordChatMessage, syncWithServer,
      newBadgesQueue, dismissBadge,
    }}>
      {children}
    </GamificationContext.Provider>
  );
}

export function useGamification() {
  const ctx = useContext(GamificationContext);
  if (!ctx) throw new Error("useGamification must be inside GamificationProvider");
  return ctx;
}
