// artifacts/meueu/data/gamification.ts
// Definições do sistema de gamificação do MeuEu

// ── Níveis ────────────────────────────────────────────────
export type Level = {
  level: number;
  title: string;
  minXP: number;
  maxXP: number;
  color: string;
};

export const LEVELS: Level[] = [
  { level: 1,  title: "Iniciando",       minXP: 0,    maxXP: 99,   color: "#6B8F7E" },
  { level: 2,  title: "Explorando",      minXP: 100,  maxXP: 249,  color: "#1B6B5A" },
  { level: 3,  title: "Praticando",      minXP: 250,  maxXP: 499,  color: "#1B6B5A" },
  { level: 4,  title: "Avançando",       minXP: 500,  maxXP: 899,  color: "#E8A838" },
  { level: 5,  title: "Comprometido",    minXP: 900,  maxXP: 1399, color: "#E8A838" },
  { level: 6,  title: "Consistente",     minXP: 1400, maxXP: 1999, color: "#E8A838" },
  { level: 7,  title: "Transformando",   minXP: 2000, maxXP: 2799, color: "#C47B1A" },
  { level: 8,  title: "Integrado",       minXP: 2800, maxXP: 3799, color: "#C47B1A" },
  { level: 9,  title: "Mestre",          minXP: 3800, maxXP: 4999, color: "#9B5E10" },
  { level: 10, title: "Realizado",       minXP: 5000, maxXP: 99999, color: "#9B5E10" },
];

export function getLevelForXP(xp: number): Level {
  return LEVELS.slice().reverse().find(l => xp >= l.minXP) ?? LEVELS[0];
}

export function getXPProgress(xp: number): number {
  const level = getLevelForXP(xp);
  const range = level.maxXP - level.minXP;
  const progress = xp - level.minXP;
  return Math.min(Math.round((progress / range) * 100), 100);
}

// ── XP por ação ───────────────────────────────────────────
export const XP_REWARDS = {
  checkin_completed:    10,   // check-in diário feito
  checkin_note_5:       5,    // nota 5 no check-in
  checkin_note_4:       3,    // nota 4 no check-in
  streak_7_days:        25,   // 7 dias consecutivos
  streak_14_days:       50,   // 14 dias consecutivos
  streak_30_days:       100,  // 30 dias consecutivos
  chat_message_sent:    2,    // mensagem enviada ao coach
  practice_completed:   15,   // prática marcada como concluída
  onboarding_complete:  20,   // onboarding finalizado
};

// ── Badges ────────────────────────────────────────────────
export type Badge = {
  id: string;
  title: string;
  description: string;
  icon: string;        // Feather icon name
  condition: (stats: UserStats) => boolean;
  xpReward: number;
  tier: "bronze" | "prata" | "ouro";
};

export type UserStats = {
  totalCheckins: number;
  currentStreak: number;
  maxStreak: number;
  totalXP: number;
  totalChatMessages: number;
  note5Count: number;
  practicesCompleted: number;
  daysActive: number;
};

export const BADGES: Badge[] = [
  // Primeiros passos
  {
    id: "first_checkin",
    title: "Primeiro passo",
    description: "Fez o primeiro check-in diário",
    icon: "star",
    condition: s => s.totalCheckins >= 1,
    xpReward: 10,
    tier: "bronze",
  },
  {
    id: "first_chat",
    title: "Conversando",
    description: "Enviou a primeira mensagem ao coach",
    icon: "message-circle",
    condition: s => s.totalChatMessages >= 1,
    xpReward: 10,
    tier: "bronze",
  },
  // Streaks
  {
    id: "streak_3",
    title: "3 dias seguidos",
    description: "Manteve 3 dias consecutivos",
    icon: "zap",
    condition: s => s.maxStreak >= 3,
    xpReward: 15,
    tier: "bronze",
  },
  {
    id: "streak_7",
    title: "Uma semana",
    description: "7 dias consecutivos — uma semana completa",
    icon: "zap",
    condition: s => s.maxStreak >= 7,
    xpReward: 40,
    tier: "prata",
  },
  {
    id: "streak_21",
    title: "Hábito formado",
    description: "21 dias — o hábito já é seu",
    icon: "zap",
    condition: s => s.maxStreak >= 21,
    xpReward: 75,
    tier: "prata",
  },
  {
    id: "streak_30",
    title: "Um mês inteiro",
    description: "30 dias sem parar — extraordinário",
    icon: "award",
    condition: s => s.maxStreak >= 30,
    xpReward: 150,
    tier: "ouro",
  },
  // Qualidade
  {
    id: "note5_first",
    title: "Excelência",
    description: "Avaliou uma prática com nota 5",
    icon: "heart",
    condition: s => s.note5Count >= 1,
    xpReward: 15,
    tier: "bronze",
  },
  {
    id: "note5_x5",
    title: "Consistência",
    description: "5 avaliações com nota máxima",
    icon: "heart",
    condition: s => s.note5Count >= 5,
    xpReward: 30,
    tier: "prata",
  },
  // Volume
  {
    id: "checkins_10",
    title: "10 check-ins",
    description: "Completou 10 check-ins",
    icon: "check-circle",
    condition: s => s.totalCheckins >= 10,
    xpReward: 20,
    tier: "bronze",
  },
  {
    id: "checkins_30",
    title: "30 check-ins",
    description: "Comprometido com 30 check-ins",
    icon: "check-circle",
    condition: s => s.totalCheckins >= 30,
    xpReward: 50,
    tier: "prata",
  },
  {
    id: "checkins_100",
    title: "100 check-ins",
    description: "Um marco extraordinário",
    icon: "award",
    condition: s => s.totalCheckins >= 100,
    xpReward: 200,
    tier: "ouro",
  },
  // Chat
  {
    id: "chat_10",
    title: "Diálogo interno",
    description: "10 trocas com o coach",
    icon: "message-circle",
    condition: s => s.totalChatMessages >= 10,
    xpReward: 20,
    tier: "bronze",
  },
  {
    id: "chat_50",
    title: "Explorador",
    description: "50 mensagens ao coach",
    icon: "message-circle",
    condition: s => s.totalChatMessages >= 50,
    xpReward: 60,
    tier: "prata",
  },
];

export function checkNewBadges(
  stats: UserStats,
  earnedBadgeIds: string[]
): Badge[] {
  return BADGES.filter(
    b => !earnedBadgeIds.includes(b.id) && b.condition(stats)
  );
}

// ── Tier colors ───────────────────────────────────────────
export const TIER_COLORS = {
  bronze: { bg: "#2A1A0A", text: "#C4874A", border: "#7A4A1A" },
  prata:  { bg: "#1A1A2A", text: "#A0A8C0", border: "#4A4A7A" },
  ouro:   { bg: "#2A1A00", text: "#E8A838", border: "#8A5A00" },
};
