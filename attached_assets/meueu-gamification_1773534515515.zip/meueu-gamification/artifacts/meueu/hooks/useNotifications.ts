// artifacts/meueu/hooks/useNotifications.ts
import { useEffect, useRef } from "react";
import * as Notifications from "expo-notifications";
import * as Device from "expo-device";
import { Platform } from "react-native";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  if (!Device.isDevice) return false;

  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === "granted") return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

export async function scheduleDailyReminder(hour = 9, minute = 0): Promise<void> {
  // Cancela notificações anteriores
  await Notifications.cancelAllScheduledNotificationsAsync();

  const messages = [
    "Sua prática de hoje está esperando por você",
    "Um passo por dia transforma quem você é",
    "Reserva 10 minutos para você hoje?",
    "Sua jornada continua — check-in rápido te espera",
    "Cada dia conta. Você está no caminho certo",
  ];

  const randomMsg = messages[Math.floor(Math.random() * messages.length)];

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "MeuEu",
      body: randomMsg,
      sound: true,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DAILY,
      hour,
      minute,
    },
  });
}

export async function sendLocalNotification(title: string, body: string): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: { title, body, sound: true },
    trigger: null,
  });
}

export function useNotificationListener(onReceive?: (n: Notifications.Notification) => void) {
  const listenerRef = useRef<Notifications.EventSubscription | null>(null);

  useEffect(() => {
    listenerRef.current = Notifications.addNotificationReceivedListener(n => {
      onReceive?.(n);
    });
    return () => listenerRef.current?.remove();
  }, [onReceive]);
}
