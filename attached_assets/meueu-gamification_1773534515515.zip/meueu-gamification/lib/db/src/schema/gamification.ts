// lib/db/src/schema/gamification.ts
import { pgTable, serial, text, integer, boolean, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// ── Check-ins diários ─────────────────────────────────────
export const dailyCheckinsTable = pgTable("daily_checkins", {
  id:           serial("id").primaryKey(),
  deviceId:     text("device_id").notNull(),        // AsyncStorage device identifier
  practiceIdx:  integer("practice_idx").notNull(),   // 0, 1 ou 2 (qual das 3 práticas)
  practiceName: text("practice_name").notNull(),
  completed:    boolean("completed").notNull(),
  note:         integer("note"),                     // 1-5
  comment:      text("comment"),
  checkinDate:  date("checkin_date").notNull(),
  createdAt:    timestamp("created_at").defaultNow().notNull(),
});

// ── Progresso do usuário ──────────────────────────────────
export const userProgressTable = pgTable("user_progress", {
  id:              serial("id").primaryKey(),
  deviceId:        text("device_id").notNull().unique(),
  totalXP:         integer("total_xp").notNull().default(0),
  currentStreak:   integer("current_streak").notNull().default(0),
  maxStreak:       integer("max_streak").notNull().default(0),
  lastCheckinDate: date("last_checkin_date"),
  earnedBadges:    text("earned_badges").array().notNull().default([]),
  totalCheckins:   integer("total_checkins").notNull().default(0),
  note5Count:      integer("note5_count").notNull().default(0),
  totalChatMsgs:   integer("total_chat_msgs").notNull().default(0),
  updatedAt:       timestamp("updated_at").defaultNow().notNull(),
});

// ── Mensagens do coach ────────────────────────────────────
export const coachMessagesTable = pgTable("coach_messages", {
  id:          serial("id").primaryKey(),
  deviceId:    text("device_id").notNull(),
  role:        text("role").notNull(),              // "user" | "assistant"
  content:     text("content").notNull(),
  context:     jsonb("context"),                    // { practiceIdx, checkinNote, practiceStep }
  createdAt:   timestamp("created_at").defaultNow().notNull(),
});

// ── Zod schemas ───────────────────────────────────────────
export const insertCheckinSchema = createInsertSchema(dailyCheckinsTable).omit({ id: true, createdAt: true });
export const insertProgressSchema = createInsertSchema(userProgressTable).omit({ id: true, updatedAt: true });
export const insertCoachMsgSchema = createInsertSchema(coachMessagesTable).omit({ id: true, createdAt: true });

export type DailyCheckin   = typeof dailyCheckinsTable.$inferSelect;
export type UserProgress   = typeof userProgressTable.$inferSelect;
export type CoachMessage   = typeof coachMessagesTable.$inferSelect;
export type InsertCheckin  = z.infer<typeof insertCheckinSchema>;
export type InsertProgress = z.infer<typeof insertProgressSchema>;
