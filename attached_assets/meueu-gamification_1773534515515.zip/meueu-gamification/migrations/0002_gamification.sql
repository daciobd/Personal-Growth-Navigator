-- migrations/0002_gamification.sql
-- Execute no banco de dados para criar as tabelas de gamificação
-- Método: pnpm --filter @workspace/db db:push
-- ou cole no terminal SQL do Replit (aba Database)

CREATE TABLE IF NOT EXISTS daily_checkins (
  id            SERIAL PRIMARY KEY,
  device_id     TEXT        NOT NULL,
  practice_idx  INTEGER     NOT NULL,
  practice_name TEXT        NOT NULL,
  completed     BOOLEAN     NOT NULL,
  note          INTEGER     CHECK (note >= 1 AND note <= 5),
  comment       TEXT,
  checkin_date  DATE        NOT NULL,
  created_at    TIMESTAMP   NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS daily_checkins_device_date ON daily_checkins (device_id, checkin_date DESC);

CREATE TABLE IF NOT EXISTS user_progress (
  id                SERIAL PRIMARY KEY,
  device_id         TEXT        NOT NULL UNIQUE,
  total_xp          INTEGER     NOT NULL DEFAULT 0,
  current_streak    INTEGER     NOT NULL DEFAULT 0,
  max_streak        INTEGER     NOT NULL DEFAULT 0,
  last_checkin_date DATE,
  earned_badges     TEXT[]      NOT NULL DEFAULT '{}',
  total_checkins    INTEGER     NOT NULL DEFAULT 0,
  note5_count       INTEGER     NOT NULL DEFAULT 0,
  total_chat_msgs   INTEGER     NOT NULL DEFAULT 0,
  updated_at        TIMESTAMP   NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coach_messages (
  id          SERIAL PRIMARY KEY,
  device_id   TEXT      NOT NULL,
  role        TEXT      NOT NULL CHECK (role IN ('user', 'assistant')),
  content     TEXT      NOT NULL,
  context     JSONB,
  created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS coach_messages_device ON coach_messages (device_id, created_at DESC);
