# Onboarding v2 — Traço + Estado Separados

## O que muda

O onboarding passa de 2 telas para 3:

| Tela | Pergunta | Dados | Uso |
|------|----------|-------|-----|
| **Traços** (`traits.tsx`) | "Como você tende a ser?" | `@meueu_trait_adjectives` | Estima Big Five |
| **Estado** (`state.tsx`) | "Como está se sentindo?" | `@meueu_state_adjectives` | Contexto do plano |
| **Eu Futuro** (`future.tsx`) | "Quem quer se tornar?" | `@meueu_future_adjectives` | Direção do plano |

### Por que isso melhora o Big Five estimado

Adjetivos de traço (estáveis) têm correlação r=0.70-0.85 com IPIP-NEO.
Adjetivos de estado (voláteis) distorciam o N artificialmente.
Separados, o Big Five estimado reflete personalidade real — não o humor da semana.

### O que o Claude recebe de diferente

```
TRAÇOS (estáveis): organizado, empático, criativo, ansioso...
ESTADO ATUAL (volátil): esgotado, desmotivado, desconectado...
EU FUTURO: disciplinado, pleno, autêntico...
```

O Claude diferencia na síntese:
> "Seu traço central é alta Amabilidade (empático, caloroso), mas o estado atual mostra 
> esgotamento e desconexão — provavelmente um padrão de cuidar dos outros sem se cuidar. 
> O plano foca em recuperar energia como pré-condição para os valores de generosidade que 
> já são naturais em você."

---

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `data/traitAdjectives.ts` | `artifacts/meueu/data/` | Criar |
| `app/onboarding/traits.tsx` | `artifacts/meueu/app/onboarding/` | Criar |
| `app/onboarding/state.tsx` | `artifacts/meueu/app/onboarding/` | Criar |
| `routes/plan.ts` | `artifacts/api-server/src/routes/` | Substituir |
| `hooks/usePlanGeneration.ts` | `artifacts/meueu/hooks/` | Substituir |

---

## Passos de instalação

### 1. Registrar novas rotas no _layout.tsx
```tsx
<Stack.Screen name="onboarding/traits" options={{ headerShown: false }} />
<Stack.Screen name="onboarding/state"  options={{ headerShown: false }} />
```

### 2. Atualizar o fluxo de navegação
Em `onboarding/welcome.tsx`, o botão "Começar" deve navegar para `/onboarding/traits`
em vez de `/onboarding/current`.

Em `onboarding/traits.tsx` → navega para `/onboarding/state`
Em `onboarding/state.tsx`  → navega para `/onboarding/future`
Em `onboarding/future.tsx` → navega para `/onboarding/plan` (sem mudança)

### 3. Compatibilidade com telas antigas
O `state.tsx` salva também em `@meueu_current_adjectives` para manter
compatibilidade com `UnifiedCheckin` e outros componentes que usam a chave antiga.

### 4. Atualizar `future.tsx` para carregar traços
Em `future.tsx`, substituir o carregamento de `@meueu_current_adjectives` por:
```tsx
const traitsRaw = await AsyncStorage.getItem("@meueu_trait_adjectives");
const currentRaw = await AsyncStorage.getItem("@meueu_current_adjectives");
const currentAdj = traitsRaw
  ? JSON.parse(traitsRaw)
  : currentRaw ? JSON.parse(currentRaw) : [];
```

### 5. Manter telas antigas (current.tsx)
Não remova `current.tsx` ainda — mantenha como fallback.
O novo fluxo usa `traits.tsx` → `state.tsx` → `future.tsx`.

---

## Adjetivos de traço (60 total)
Distribuídos por dimensão Big Five, com exemplos contextuais.
Incluem polo alto E polo baixo de cada dimensão — fundamental para 
evitar viés para N alto.

## Adjetivos de estado (42 total)
5 domínios: emocional, energia, relações, propósito, corpo.
Separados em desafios atuais (vermelho) e o que está fluindo (verde).
Podem ser pulados — são contextuais, não obrigatórios.
