// artifacts/api-server/src/routes/plan.ts (atualizado)
// Integra traços + estado + Big Five ao prompt do Claude.
// Traços → estimativa Big Five (estável)
// Estado → contexto emocional atual (volátil)
// O Claude recebe os dois separados e gera síntese diferenciada.

import { Router, type IRouter } from "express";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { db } from "@workspace/db";
import { planLogsTable } from "@workspace/db/schema";
import { selectFutureApproach } from "../data/futureApproaches.js";

const router: IRouter = Router();

type DimKey = "N" | "E" | "O" | "A" | "C";

const DIM_NAMES: Record<DimKey, string> = {
  N: "Neuroticismo", E: "Extroversão", O: "Abertura",
  A: "Amabilidade",  C: "Conscienciosidade",
};

function levelLabel(p: number): string {
  if (p < 20) return "muito baixo";
  if (p < 35) return "baixo";
  if (p < 50) return "moderado-baixo";
  if (p < 65) return "moderado";
  if (p < 80) return "alto";
  return "muito alto";
}

router.post("/plan/generate", async (req, res) => {
  const {
    // Novos campos v2
    traitAdjectives,     // traços estáveis → Big Five
    stateAdjectives,     // estado atual → contexto
    // Legados (compatibilidade)
    currentAdjectives,
    futureAdjectives,
    // Big Five (opcional, de avaliação completa ou estimativa)
    big5Scores,
    assessmentNumber = 1,
  } = req.body as {
    traitAdjectives?: string[];
    stateAdjectives?: string[];
    currentAdjectives?: string[];
    futureAdjectives?: string[];
    big5Scores?: { dims: Record<string, number>; facets: Record<string, number> };
    assessmentNumber?: number;
  };

  // Normaliza: usa novos campos se disponíveis, senão legados
  const traits  = traitAdjectives  ?? currentAdjectives ?? [];
  const states  = stateAdjectives  ?? [];
  const future  = futureAdjectives ?? [];

  if (traits.length === 0 && future.length === 0) {
    res.status(400).json({ error: "Adjetivos são obrigatórios" });
    return;
  }

  // Seleciona abordagem do eu futuro
  const approach = selectFutureApproach(big5Scores?.dims, assessmentNumber);

  // Bloco Big Five
  let big5Block = "";
  if (big5Scores?.dims) {
    const dimLines = (["N","E","O","A","C"] as DimKey[]).map(d => {
      const pct = big5Scores.dims[d] ?? 50;
      return `  ${DIM_NAMES[d]}: ${pct}% (${levelLabel(pct)})`;
    });
    const source = assessmentNumber > 1 || big5Scores.dims.N !== undefined
      ? "avaliação IPIP-NEO-120"
      : "estimativa por adjetivos";
    big5Block = `PERFIL BIG FIVE (${source}):\n${dimLines.join("\n")}\n\n`;
  }

  // Bloco de estado atual
  const stateBlock = states.length > 0
    ? `ESTADO EMOCIONAL ATUAL (última semana — VOLÁTIL, não confunda com traço):\n  ${states.join(", ")}\n\n`
    : "";

  const prompt = `Você é um psicólogo clínico especialista em psicoterapia integrativa.

${big5Block}${stateBlock}TRAÇOS DE PERSONALIDADE (estáveis — base para o Big Five):
${traits.join(", ")}

EU FUTURO DESEJADO:
${future.join(", ")}

=== PERSPECTIVA TERAPÊUTICA DESTA SESSÃO ===
Abordagem: ${approach.name}
${approach.systemInstruction}
SÍNTESE: ${approach.synthesisLens}
FRASE DE INTENÇÃO: ${approach.intentionFrame}
PRÁTICAS: ${approach.practiceFrame}
===========================================

${stateBlock ? `IMPORTANTE: O estado atual (${states.slice(0, 3).join(", ")}...) representa o contexto emocional presente, não a personalidade permanente. O plano deve reconhecer esse estado E trabalhar com os traços estáveis como base de mudança.` : ""}

Gere o plano em JSON com esta estrutura:

{
  "sintese": "2-3 frases. ${approach.synthesisLens}${states.length > 0 ? " Reconheça o estado atual e conecte com os traços estáveis." : ""}",
  "estadoAtual": "${states.length > 0 ? "1 frase reconhecendo o contexto emocional presente com compaixão (não patologizando)" : ""}",
  "fraseIntencao": "${approach.intentionFrame}",
  "praticas": [
    {
      "abordagem": "TCC",
      "nome": "Nome",
      "justificativa": "Por que para ESTE perfil específico",
      "passos": ["Passo 1", "Passo 2", "Passo 3", "Passo 4"],
      "frequencia": "Sugestão"
    },
    { "abordagem": "ACT", "nome": "...", "justificativa": "...", "passos": ["...","...","...","..."], "frequencia": "..." },
    { "abordagem": "Psicologia Positiva", "nome": "...", "justificativa": "...", "passos": ["...","...","...","..."], "frequencia": "..." }
  ],
  "perguntaReflexao": "${approach.anchorQuestion}"
}

REGRAS:
- Diferencia traço (permanente) de estado (temporário) na síntese
- 3 práticas de abordagens DIFERENTES
- Use segunda pessoa ("você")
- Responda APENAS com JSON válido`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 2048,
      messages: [{ role: "user", content: prompt }],
    });

    const rawText = message.content[0].type === "text" ? message.content[0].text : "";
    let planData: Record<string, unknown>;
    try {
      const match = rawText.match(/\{[\s\S]*\}/);
      planData = match ? JSON.parse(match[0]) : { rawText, parseError: true };
    } catch {
      planData = { rawText, parseError: true };
    }

    db.insert(planLogsTable).values({
      currentAdjectives: traits,
      futureAdjectives: future,
      plan: planData,
    }).catch(err => console.error("Plan log error:", err));

    res.json({
      success: true,
      plan: planData,
      approach: {
        key:            approach.key,
        name:           approach.name,
        anchorQuestion: approach.anchorQuestion,
      },
      hasBig5:  !!big5Scores,
      hasState: states.length > 0,
    });

  } catch (err) {
    console.error("Plan generation error:", err);
    res.status(500).json({ error: "Erro ao gerar plano. Tente novamente." });
  }
});

export default router;
