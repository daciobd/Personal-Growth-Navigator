# MeuEu — Abordagens do Eu Futuro + Jornadas de 30 Dias

## O que este pacote adiciona

### 1. Abordagens do Eu Futuro (integração ao plano)
- 8 abordagens terapêuticas com seleção automática pelo Big Five
- Prompt do Claude enriquecido com perspectiva específica por sessão
- `ApproachBadge` — componente que exibe a perspectiva + pergunta âncora
- Campo `perguntaReflexao` no JSON do plano

### 2. Jornadas Temáticas de 30 dias
- 6 jornadas completas com 30 práticas cada
- 3 fases × 10 dias, técnica específica por dia
- IA gera proposição de ação personalizada por dia (baseada nos adjetivos futuros)
- Check-in avança automaticamente para o próximo dia
- Integrado ao sistema de gamificação (XP, streaks)
- Chat com coach disponível a partir de cada prática

---

## Arquivos e destinos

| Arquivo | Destino | Ação |
|---------|---------|------|
| `artifacts/api-server/src/data/futureApproaches.ts` | idem | Criar |
| `artifacts/api-server/src/data/journeyCatalog.ts` | idem | Criar |
| `artifacts/api-server/src/routes/plan.ts` | idem | **Substituir** |
| `artifacts/api-server/src/routes/journeys.ts` | idem | Criar |
| `artifacts/api-server/src/routes/index.ts` | idem | **Substituir** |
| `artifacts/meueu/hooks/usePlanGeneration.ts` | idem | **Substituir** |
| `artifacts/meueu/components/ApproachBadge.tsx` | idem | Criar |
| `artifacts/meueu/app/journeys/index.tsx` | idem | Criar |
| `artifacts/meueu/app/journeys/[id].tsx` | idem | Criar |
| `lib/db/src/schema/journeys.ts` | idem | Criar |
| `migrations/0005_journeys.sql` | Executar no banco | SQL |

---

## Passo a passo

### 1. Criar tabelas
```bash
pnpm --filter @workspace/db db:push
```

### 2. Atualizar lib/db/src/schema/index.ts
```typescript
export * from "./journeys";
```

### 3. Criar diretório de dados
```bash
mkdir -p artifacts/api-server/src/data
```

### 4. Adicionar ApproachBadge na tela do plano
```tsx
import ApproachBadge from "../../components/ApproachBadge";

// Após o cabeçalho do plano:
{approach && (
  <ApproachBadge
    approachName={approach.name}
    anchorQuestion={approach.anchorQuestion}
  />
)}
```

### 5. Adicionar acesso às jornadas na navegação
Em algum lugar acessível (tab de perfil, botão na home):
```tsx
<Pressable onPress={() => router.push("/journeys")}>
  <Text>Jornadas de 30 dias</Text>
</Pressable>
```

### 6. Adicionar rota ao Stack no _layout.tsx
```tsx
<Stack.Screen name="journeys/index" options={{ headerShown: false }} />
<Stack.Screen name="journeys/[id]"  options={{ headerShown: false }} />
```

---

## As 6 jornadas

| ID | Título | Dimensão Big Five |
|----|--------|-------------------|
| `anxiety-30` | Navegando a Ansiedade | Neuroticismo |
| `discipline-30` | Construindo Disciplina | Conscienciosidade |
| `selfesteem-30` | Cultivando Autoestima | Neuroticismo |
| `relationships-30` | Conexões Verdadeiras | Amabilidade |
| `purpose-30` | Encontrando Propósito | Abertura |
| `procrastination-30` | Além da Procrastinação | Conscienciosidade |

---

## Lógica de progressão

- Check-in `completed: true` → `currentDay + 1`
- Dia 10 → entra na Fase 2; Dia 20 → entra na Fase 3
- Dia 30 completo → `status: "completed"`
- Check-in `completed: false` → dia não avança (usuário tenta novamente amanhã)
- Múltiplas jornadas: apenas 1 ativa por vez; as outras ficam `paused`
