// artifacts/api-server/src/routes/journeys.ts
//
// GET  /api/journeys                          — catálogo completo
// POST /api/journeys/start                    — inicia uma jornada
// GET  /api/journeys/active/:deviceId         — jornada ativa do usuário
// POST /api/journeys/checkin                  — check-in do dia da jornada
// POST /api/journeys/day-challenge            — IA gera proposição de ação do dia
// GET  /api/journeys/progress/:deviceId/:id   — progresso detalhado

import { Router } from "express";
import { db } from "@workspace/db";
import {
  userJourneysTable,
  journeyCheckinsTable,
} from "@workspace/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import {
  JOURNEY_CATALOG, getJourney, getJourneyDay,
} from "../data/journeyCatalog.js";

const router = Router();

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

// ── GET /api/journeys ─────────────────────────────────────
router.get("/", (_req, res) => {
  const catalog = JOURNEY_CATALOG.map(j => ({
    id: j.id, title: j.title, subtitle: j.subtitle,
    description: j.description, color: j.color, icon: j.icon,
    targetDimension: j.targetDimension,
    totalDays: j.days.length,
    phases: j.phases.map(p => ({ number: p.number, title: p.title, description: p.description })),
  }));
  res.json({ journeys: catalog });
});

// ── POST /api/journeys/start ──────────────────────────────
router.post("/start", async (req, res) => {
  const { deviceId, journeyId } = req.body as {
    deviceId: string; journeyId: string;
  };

  if (!deviceId || !journeyId) {
    res.status(400).json({ error: "deviceId e journeyId são obrigatórios" });
    return;
  }

  const journey = getJourney(journeyId);
  if (!journey) { res.status(404).json({ error: "Jornada não encontrada" }); return; }

  // Pausa jornadas ativas anteriores
  await db.update(userJourneysTable)
    .set({ status: "paused" })
    .where(and(
      eq(userJourneysTable.deviceId, deviceId),
      eq(userJourneysTable.status, "active")
    ));

  // Verifica se já iniciou esta jornada antes
  const existing = await db.select()
    .from(userJourneysTable)
    .where(and(
      eq(userJourneysTable.deviceId, deviceId),
      eq(userJourneysTable.journeyId, journeyId)
    )).limit(1);

  let userJourney;
  if (existing.length > 0) {
    // Retoma do ponto onde parou
    [userJourney] = await db.update(userJourneysTable)
      .set({ status: "active" })
      .where(eq(userJourneysTable.id, existing[0].id))
      .returning();
  } else {
    [userJourney] = await db.insert(userJourneysTable)
      .values({ deviceId, journeyId, phase: 1, currentDay: 1, status: "active" })
      .returning();
  }

  const firstDay = getJourneyDay(journeyId, userJourney.currentDay);
  res.json({ success: true, userJourney, currentDayPractice: firstDay });
});

// ── GET /api/journeys/active/:deviceId ───────────────────
router.get("/active/:deviceId", async (req, res) => {
  const active = await db.select()
    .from(userJourneysTable)
    .where(and(
      eq(userJourneysTable.deviceId, req.params.deviceId),
      eq(userJourneysTable.status, "active")
    )).limit(1);

  if (!active.length) { res.json({ active: null }); return; }

  const uj = active[0];
  const journey = getJourney(uj.journeyId);
  const todayPractice = getJourneyDay(uj.journeyId, uj.currentDay);

  // Verifica se já fez check-in hoje
  const todayCheckin = await db.select()
    .from(journeyCheckinsTable)
    .where(and(
      eq(journeyCheckinsTable.deviceId, req.params.deviceId),
      eq(journeyCheckinsTable.journeyId, uj.journeyId),
      eq(journeyCheckinsTable.checkinDate, todayStr())
    )).limit(1);

  res.json({
    active: uj,
    journey: journey ? {
      id: journey.id, title: journey.title, color: journey.color,
      phases: journey.phases,
    } : null,
    todayPractice,
    checkinDoneToday: todayCheckin.length > 0,
    completionPct: Math.round(((uj.currentDay - 1) / 30) * 100),
  });
});

// ── POST /api/journeys/day-challenge ─────────────────────
// IA gera proposição de ação personalizada para o dia
router.post("/day-challenge", async (req, res) => {
  const { deviceId, journeyId, day, futureAdjectives, recentNotes } = req.body as {
    deviceId: string;
    journeyId: string;
    day: number;
    futureAdjectives?: string[];
    recentNotes?: number[];  // notas dos últimos 3 dias
  };

  const dayData = getJourneyDay(journeyId, day);
  if (!dayData) { res.status(404).json({ error: "Dia não encontrado" }); return; }

  const journey = getJourney(journeyId);
  const avgNote = recentNotes?.length
    ? recentNotes.reduce((a, b) => a + b, 0) / recentNotes.length
    : null;

  const difficulty = avgNote !== null
    ? avgNote < 3 ? "O usuário tem tido dificuldade (notas baixas). Simplifique a ação e ofereça uma alternativa mais acessível."
    : avgNote >= 4 ? "O usuário está indo bem (notas altas). Adicione um pequeno desafio extra para aprofundar a prática."
    : ""
    : "";

  const prompt = `Você é um coach terapêutico especializado em ${journey?.title ?? "transformação pessoal"}.

JORNADA: ${journey?.title}
DIA: ${day}/30 | FASE: ${dayData.phase}/3
PRÁTICA DO DIA: "${dayData.title}"
DESCRIÇÃO BASE: ${dayData.description}
TÉCNICA: ${dayData.technique} (${dayData.approach})
TEMPO ESTIMADO: ${dayData.duration}
${futureAdjectives?.length ? `EU FUTURO DO USUÁRIO: ${futureAdjectives.join(", ")}` : ""}
${difficulty}

Gere uma proposição de ação em JSON:
{
  "titulo": "Uma frase curta e motivadora (máx 8 palavras)",
  "acao": "O que exatamente fazer hoje — concreto, específico, com detalhe suficiente para agir sem precisar pensar. Máx 3 frases.",
  "dica": "Uma dica prática para tornar mais fácil hoje. Máx 1 frase.",
  "tempo": "${dayData.duration}",
  "perguntaReflexao": "Uma pergunta para reflexão após a prática. Específica para este dia."
}

Responda APENAS com JSON válido.`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 512,
      messages: [{ role: "user", content: prompt }],
    });

    const raw = message.content[0].type === "text" ? message.content[0].text : "";
    const match = raw.match(/\{[\s\S]*\}/);
    const challenge = match ? JSON.parse(match[0]) : {
      titulo: dayData.title,
      acao: dayData.description,
      dica: "",
      tempo: dayData.duration,
      perguntaReflexao: "",
    };

    res.json({ success: true, challenge, dayData });
  } catch (err) {
    console.error("Journey challenge error:", err);
    res.status(500).json({ error: "Erro ao gerar desafio" });
  }
});

// ── POST /api/journeys/checkin ────────────────────────────
router.post("/checkin", async (req, res) => {
  const { deviceId, journeyId, day, completed, note, comment } = req.body as {
    deviceId: string; journeyId: string;
    day: number; completed: boolean;
    note?: number; comment?: string;
  };

  const today = todayStr();
  const dayData = getJourneyDay(journeyId, day);
  if (!dayData) { res.status(404).json({ error: "Dia não encontrado" }); return; }

  // Evita duplicatas
  const existing = await db.select()
    .from(journeyCheckinsTable)
    .where(and(
      eq(journeyCheckinsTable.deviceId, deviceId),
      eq(journeyCheckinsTable.journeyId, journeyId),
      eq(journeyCheckinsTable.checkinDate, today)
    )).limit(1);

  if (existing.length > 0) {
    res.json({ success: true, alreadyDone: true }); return;
  }

  // Salva check-in
  await db.insert(journeyCheckinsTable).values({
    deviceId, journeyId, day, phase: dayData.phase,
    practiceKey: dayData.practiceKey,
    completed, note: note ?? null,
    comment: comment ?? null,
    checkinDate: today,
  });

  // Avança o dia se completou
  let nextDay = day;
  let status = "active";
  if (completed) {
    nextDay = Math.min(day + 1, 30);
    if (day >= 30) status = "completed";
  }

  const newPhase = nextDay <= 10 ? 1 : nextDay <= 20 ? 2 : 3;

  await db.update(userJourneysTable)
    .set({
      currentDay: nextDay,
      phase: newPhase,
      status,
      completedDays: completed ? day : undefined,
      lastPracticeDate: today,
      completedAt: status === "completed" ? new Date() : undefined,
    })
    .where(and(
      eq(userJourneysTable.deviceId, deviceId),
      eq(userJourneysTable.journeyId, journeyId)
    ));

  res.json({
    success: true,
    nextDay,
    journeyCompleted: status === "completed",
    phaseAdvanced: newPhase !== dayData.phase,
  });
});

// ── GET /api/journeys/progress/:deviceId/:journeyId ───────
router.get("/progress/:deviceId/:journeyId", async (req, res) => {
  const { deviceId, journeyId } = req.params;

  const [uj] = await db.select()
    .from(userJourneysTable)
    .where(and(
      eq(userJourneysTable.deviceId, deviceId),
      eq(userJourneysTable.journeyId, journeyId)
    )).limit(1);

  if (!uj) { res.status(404).json({ error: "Jornada não iniciada" }); return; }

  const checkins = await db.select()
    .from(journeyCheckinsTable)
    .where(and(
      eq(journeyCheckinsTable.deviceId, deviceId),
      eq(journeyCheckinsTable.journeyId, journeyId)
    )).orderBy(journeyCheckinsTable.day);

  const completedDays = checkins.filter(c => c.completed).length;
  const avgNote = checkins.filter(c => c.note).length > 0
    ? checkins.filter(c => c.note).reduce((s, c) => s + (c.note ?? 0), 0) / checkins.filter(c => c.note).length
    : null;

  res.json({
    userJourney: uj,
    checkins,
    stats: {
      completedDays,
      totalDays: uj.currentDay - 1,
      completionPct: Math.round((completedDays / 30) * 100),
      avgNote: avgNote ? Math.round(avgNote * 10) / 10 : null,
      currentPhase: uj.phase,
      streak: calculateStreak(checkins),
    },
  });
});

function calculateStreak(checkins: Array<{ checkinDate: string; completed: boolean }>) {
  const sorted = checkins
    .filter(c => c.completed)
    .map(c => c.checkinDate)
    .sort()
    .reverse();

  if (!sorted.length) return 0;
  let streak = 1;
  for (let i = 0; i < sorted.length - 1; i++) {
    const a = new Date(sorted[i]);
    const b = new Date(sorted[i + 1]);
    const diff = Math.round((a.getTime() - b.getTime()) / 86400000);
    if (diff === 1) streak++;
    else break;
  }
  return streak;
}

export default router;
